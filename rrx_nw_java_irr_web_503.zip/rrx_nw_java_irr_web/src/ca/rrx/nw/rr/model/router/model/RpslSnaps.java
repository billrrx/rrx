
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.RpslSnap;
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

public class RpslSnaps implements Serializable{
    
    private Map rpslSnaps;
    private Map rpslSnapIds;
    private List rpslSnapTimeStamps;

    {
        rpslSnaps = new HashMap();
        rpslSnapIds = new HashMap();
        rpslSnapTimeStamps = new LinkedList();
    }

   
    public RpslSnaps() {}
    
   
    public Object getRouterRpslSnapId(Object rpslSnapTimeStamp){
       return (getRouterRpslSnapId(rpslSnaps.get(rpslSnapTimeStamp))); 
    }
    
    public RpslSnap getRpslSnapById(Object routerRpslSnapId){
        return ((RpslSnap)rpslSnapIds.get(routerRpslSnapId));
    }
    
    public RpslSnap getRpslSnapByTimeStamp(Object rpslSnapTimeStamp){
        return ((RpslSnap)rpslSnaps.get(rpslSnapTimeStamp)); 
    }
    
    public void addRpslSnap(RpslSnap rpslSnap) {
      rpslSnapTimeStamps.add(rpslSnap.getTimeStored());
      rpslSnaps.put(rpslSnap.getTimeStored(), rpslSnap);
      rpslSnapIds.put(rpslSnap.getRouterConfigurationId(), rpslSnap);
    }
    
    public void removeRpslSnap(Object rpslSnapTimeStamp) {
        if (rpslSnaps.containsKey(rpslSnapTimeStamp)){
        rpslSnapIds.remove(getRouterRpslSnapId(rpslSnapTimeStamp));    
        rpslSnapTimeStamps.remove(rpslSnapTimeStamp);
        rpslSnaps.remove(rpslSnapTimeStamp);
        }
    }
   
    public Map getRpslSnaps(){
        return rpslSnaps;
    }
    
    public void setRpslSnaps(Map rpslSnaps){
        this.rpslSnaps = rpslSnaps;
    }
    
    public Map getRpslSnapIds(){
        return rpslSnapIds;
    }
    
    public void setRpslSnapIds(Map rpslSnapIds){
        this.rpslSnapIds = rpslSnapIds;
    }
     
    public List getRpslSnapTimeStamps(){
        return rpslSnapTimeStamps;
    }
    
    public void setRpslSnapIds(List rpslSnapTimeStamps){
        this.rpslSnapTimeStamps = rpslSnapTimeStamps;
    }
    
 
}
