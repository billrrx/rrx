
package ca.rrx.nw.rr.model.router.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import java.io.*;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.Constants;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class TransitPort implements java.io.Serializable {

    private Object transitPortId;
    private Object routerProfileId;
    private String transitPortName;
    private String transitPortNumber;
    private String timeStored;
    private String disabled;
    private String circuit;
    private String designatedIpv4;
    private String designatedIpv4MaskLength;
    private String transportProtocol;
    private String peerRoutingProtocol;
    private String peerDesignatedIpv4;
    private Object uclpProfileId;
    private String peerSupportsUclp;
    private Object ipv6ProfileId;
    private String peerSupportsIpv6;
    private String remarks;
    
    

        
    public TransitPort(Object transitPortId,Object routerProfileId){
                this.transitPortId = transitPortId;
                this.routerProfileId = routerProfileId;

    }
    

    public TransitPort(){}

    public Object clone(){
        return new  TransitPort (transitPortId, routerProfileId);

    }

    // get methods for the instance variables

    public Object getTransitPortId() {
        return transitPortId;
    }
    
    public void setTransitPortId(Object transitPortId) {
        this. transitPortId = transitPortId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getTransitPortName() {
        return transitPortName;
    }
    
    public void setTransitPortName(String transitPortName) {
        this. transitPortName = transitPortName;
    }

    public String getTransitPortNumber() {
        return transitPortNumber;
    }
    
    public void setTransitPortNumber(String transitPortNumber) {
        this.transitPortNumber = transitPortNumber;
    }

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }

    public String getDisabled() {
        return disabled;
    }
    
    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public String getCircuit() {
        return circuit;
    }
    
    public void setCircuit(String circuit) {
        this.circuit = circuit;
    }    
    
    public String getDesignatedIpv4() {
        return designatedIpv4;
    }

    public void setDesignatedIpv4(String designatedIpv4) {
        this.designatedIpv4 = designatedIpv4;
    }

    public String getDesignatedIpv4MaskLength() {
        return designatedIpv4MaskLength;
    }

    public void setDesignatedIpv4MaskLength(String designatedIpv4MaskLength) {
        this.designatedIpv4MaskLength = designatedIpv4MaskLength;
    }

    public String getTransportProtocol(){
        return transportProtocol;
    }
    
    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }
    
    public String getPeerRoutingProtocol(){
        return peerRoutingProtocol;
    }
    
    public void setPeerRoutingProtocol(String peerRoutingProtocol) {
        this.peerRoutingProtocol = peerRoutingProtocol;
    }
    
    public String getPeerDesignatedIpv4(){
        return peerDesignatedIpv4;
    }
    
    public void setPeerDesignatedIpv4(String peerDesignatedIpv4) {
        this.peerDesignatedIpv4 = peerDesignatedIpv4;
    }
    
    public Object getUclpProfileId(){
        return uclpProfileId;
    }
    
    public void setUclpProfileId(Object uclpProfileId) {
        this.uclpProfileId = uclpProfileId;
    }
    
    public String getPeerSupportsUclp(){
        return peerSupportsUclp;
    }
    
    public void setPeerSupportsUclp(String peerSupportsUclp) {
        this.peerSupportsUclp = peerSupportsUclp;
    }
    
    public Object getIpv6ProfileId(){
        return ipv6ProfileId;
    }
    
    public void setIpv6ProfileId(Object ipv6ProfileId) {
        this.ipv6ProfileId = ipv6ProfileId;
    }
    
    public String getPeerSupportsIpv6(){
        return peerSupportsIpv6;
    }
    
    public void setPeerSupportsIpv6(String peerSupportsIpv6) {
        this.peerSupportsIpv6 = peerSupportsIpv6;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String ping(String ipv4) {
        return(executeCommandLine(Constants.PING_PATH + ipv4));
    }
    
        public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
     public String toString(){
        return "[ transitPortId=" + transitPortId + ", routerProfileId=" + routerProfileId +
                ", transitPortName="  + transitPortName + ", transitPortNumber=" + transitPortNumber + 
                ", timeStored=" + timeStored + ", disabled=" + disabled + 
                ", designatedIpv4="  + designatedIpv4 + ", designatedIpv4MaskLength=" + designatedIpv4MaskLength + 
                ", transportProtocol="  + transportProtocol + ", uclpProfileId=" + uclpProfileId +
                ", ipv6ProfileId="  + ipv6ProfileId +
                "]";
    }

    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("TransitPort");
        if (id != null)
            root.setAttribute("Id", id);

        Element node = doc.createElement("transitPortName");
        node.appendChild(doc.createTextNode(transitPortName));
        root.appendChild(node);

        node = doc.createElement("transitPortNumber");
        node.appendChild(doc.createTextNode(transitPortNumber));
        root.appendChild(node);

        node = doc.createElement("timeStored");
        node.appendChild(doc.createTextNode(timeStored));
        root.appendChild(node);
        
        node = doc.createElement("disabled");
        node.appendChild(doc.createTextNode(disabled));
        root.appendChild(node);
        
        node = doc.createElement("designatedIpv4");
        node.appendChild(doc.createTextNode(designatedIpv4));
        root.appendChild(node);
        
        node = doc.createElement("designatedIpv4MaskLength");
        node.appendChild(doc.createTextNode(designatedIpv4MaskLength));
        root.appendChild(node);

        node = doc.createElement("transportProtocol");
        node.appendChild(doc.createTextNode(transportProtocol));
        root.appendChild(node);

        node = doc.createElement("uclpProfileId");
        node.appendChild(doc.createTextNode(uclpProfileId.toString()));
        root.appendChild(node);

        node = doc.createElement("ipv6ProfileId");
        node.appendChild(doc.createTextNode(ipv6ProfileId.toString()));
        root.appendChild(node);


        return root;
    }
    
    private static String loadFile(String filePath, String encoding){
        File inputFile;
        FileInputStream is;
        String returnString = new String("");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            inputFile = new File(filePath);
            is = new FileInputStream(inputFile);
            long total =0;
            byte [] buffer = new byte[1024];
            while (true){
                int nRead = is.read(buffer,0,buffer.length);
                total += nRead;
                if (nRead <=0) break;
                bos.write(buffer,0, nRead);
            }
            is.close();
            bos.close();
            
        }catch (IOException e){
            System.out.print ("Error Reading file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Reading: " + e + "\n");
        }
        try{
            byte[] bytes = bos.toByteArray();
            if (encoding != null) returnString = new String(bytes,0, bytes.length, encoding);
            else returnString = new String(bytes);
        }catch (UnsupportedEncodingException enex){
            //Debug.println("Unable to Convert Source File");
        }
        return returnString;
    }
     private static void saveFile(ByteArrayInputStream bis, String filePath){
        
        File outputFile;
        FileOutputStream os;
        
        try {
            outputFile = new File(filePath);
            os = new FileOutputStream(outputFile);
            int c;
            while ((c = bis.read()) != -1){
                os.write(c);
            }
            os.close();
    
        }catch (IOException e){
            System.out.print ("Error Writing file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Writing: " + e + "\n");
        }
    }
    
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Command Line Exec Error = " + e.getMessage());
        }
        //return("debug cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
}

