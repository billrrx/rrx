
package ca.rrx.nw.rr.model.server.model;

import ca.rrx.nw.rr.model.server.model.Server;
import java.io.Serializable;
import java.util.*;

import ca.rrx.nw.rr.util.Debug;

public class Servers implements Serializable{
    
    private Map servers;
    private Map serverIds;
    private List serverDnsNames;
    private List serverProfileNames;
    private Object defaultServerId;
    
    {
        servers = new HashMap();
        serverIds = new HashMap();
        serverDnsNames = new LinkedList();
        serverProfileNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public Servers(Object serverProfileId) {
        
        this.defaultServerId = serverProfileId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public Servers() {}
    
   
    public Object getServerProfileId(Object serverProfileName){
        return (getServerProfileId((Server)servers.get(serverProfileName)));
    }
    
    public Server getServerById(Object serverProfileId){
        return ((Server)serverIds.get(serverProfileId));
    }
    
    public Server getServerByName(Object serverProfileName){
        return ((Server)servers.get(serverProfileName));
    }
    
    public void addServer(Server server) {
      serverDnsNames.add(server.getServerDnsName());
      serverProfileNames.add(server.getServerProfileName());
      servers.put(server.getServerProfileName(), server);
      serverIds.put(server.getServerProfileId(), server);
    }
    
    public void removeServer(Object serverProfileName) {
        if (servers.containsKey(serverProfileName)){
        serverIds.remove(getServerProfileId(serverProfileName));    
        serverDnsNames.remove(serverProfileName);
        servers.remove(serverProfileName);
        serverProfileNames.remove(serverProfileName);
        }
    }
   
   public void updateServer(Server server) {
      Object serverProfileId = server.getServerProfileId();
      Server currentServer = ((Server)serverIds.get(serverProfileId));
      serverDnsNames.remove(currentServer.getServerDnsName());
      serverDnsNames.add(server.getServerDnsName());
      servers.put(server.getServerProfileName(), server);
      serverIds.put(server.getServerProfileId(), server);
    }
    
    public Map getServers(){
        return servers;
    }
    
    public Map getServerIds(){
        return serverIds;
    }
     
    public List getServerDnsNames(){
        return serverDnsNames;
    }
    
    public List getServerProfileNames(){
        return serverProfileNames;
    }
    
    public Object getDefaultServerId(){
        return defaultServerId;
    }
    
    public void setDefaultServerId(Object defaultServerId){
        this. defaultServerId = defaultServerId;
    }
    
}
