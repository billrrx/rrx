package ca.rrx.nw.irr.model.page.dao;

public class PageDAOImpl 
    implements PageDAO
{
}