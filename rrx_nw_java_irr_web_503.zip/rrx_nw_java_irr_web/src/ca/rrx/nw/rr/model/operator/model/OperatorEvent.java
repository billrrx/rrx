package ca.rrx.nw.rr.model.operator.model;

import java.io.Serializable;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class OperatorEvent implements Serializable{
    
    protected Object operatorEventId;
    protected Object operatorId;
    protected Object sessionProfileId;
    protected String httpSessionCode;
    protected String maintainerCode;
    protected String fullName;
    protected String telephone;
    protected String email;
    protected String eventCode;
    protected String timeStored;
    protected String extendedInformation;
    

    public OperatorEvent() {}
    
    public Object getOperatorEventId() {
        return operatorEventId;
    }
    
    public void setOperatorEventId(Object operatorEventId) {
        this. operatorEventId = operatorEventId;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public Object getSessionProfileId() {
        return sessionProfileId;
    }
    
    public void setSessionProfileId(Object sessionProfileId) {
        this. sessionProfileId = sessionProfileId;
    }
    
    public String getHttpSessionCode() {
        return httpSessionCode;
    }
    
    public void setHttpSessionCode(String httpSessionCode) {
        this. httpSessionCode = httpSessionCode;
    }
        

    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this. maintainerCode = maintainerCode;
    }
    
    public String getFullName(){
        return fullName;
    }

    public void setFullName(String fullName){
        this.fullName = fullName;
    }   
    
    public String getTelephone(){
        return telephone;
    }
        
    public void setTelephone(String telephone){
        this.telephone = telephone;
    }   
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }   
    
    public String getEventCode(){
        return eventCode;
    }
    
    public void setEventCode(String eventCode){
        this.eventCode = eventCode;
    }   

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }
    
    public String getExtendedInformation(){
        return extendedInformation;
    }
    
    public void setExtendedInformation(String extendedInformation){
        this.extendedInformation = extendedInformation;
    }   
    
    
    public String toString(){
        return "[operatorEventId=" + operatorEventId
        + ", operatorId=" + operatorId
        + ", sessionProfileId=" + sessionProfileId
        + ", httpSessionCode=" + httpSessionCode
        + ", maintainerCode=" + maintainerCode
        + ", fullName=" + fullName
        + ", telephone=" + telephone
        + ", email=" + email
        + ", eventCode=" + eventCode
        + ", timeStored=" + timeStored
        + ", extendedInformation=" + extendedInformation + "]";
    }
    
    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("operatorEvent");
        if (id != null)
            root.setAttribute("Id", id);
        
        Element node = doc.createElement("operatorEventId");
        node.appendChild(doc.createTextNode(operatorEventId.toString()));
        root.appendChild(node);
        
        node  = doc.createElement("operatorId");
        node.appendChild(doc.createTextNode(operatorId.toString()));
        root.appendChild(node);
        
        node = doc.createElement("sessionProfileId");
        node.appendChild(doc.createTextNode(sessionProfileId.toString()));
        root.appendChild(node);
        
        node = doc.createElement("httpSessionCode");
        node.appendChild(doc.createTextNode(httpSessionCode));
        root.appendChild(node);
        
        node = doc.createElement("maintainerCode");
        node.appendChild(doc.createTextNode(maintainerCode));
        root.appendChild(node);
        
        node = doc.createElement("fullName");
        node.appendChild(doc.createTextNode(fullName));
        root.appendChild(node);
        
        node = doc.createElement("telephone");
        node.appendChild(doc.createTextNode(telephone));
        root.appendChild(node);
        
        node = doc.createElement("email");
        node.appendChild(doc.createTextNode(email));
        root.appendChild(node);
        
        node = doc.createElement("eventCode");
        node.appendChild(doc.createTextNode(eventCode));
        root.appendChild(node);
        
        node = doc.createElement("timeStored");
        node.appendChild(doc.createTextNode(timeStored));
        root.appendChild(node);
        
        node = doc.createElement("extendedInformation");
        node.appendChild(doc.createTextNode(extendedInformation));
        root.appendChild(node);
        
        return root;
    }
    
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R and nested Address object
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        sqlSetString = sqlSetString.substring(0,sqlSetString.length()-1);
        //Debug.println("OperatorSession.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString);
    }      
}
