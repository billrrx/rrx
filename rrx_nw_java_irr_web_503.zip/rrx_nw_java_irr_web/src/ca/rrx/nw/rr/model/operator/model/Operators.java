package ca.rrx.nw.rr.model.operator.model;

import ca.rrx.nw.rr.model.operator.model.*;
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

public class Operators implements Serializable{
    
    private Map operators;
    private Map operatorIds;
    private List operatorFullNames;
    private List operatorLoginNames;
        
    private Map administrators;
    private Map administratorIds;
    private List administratorFullNames;
    private List administratorLoginNames;

    {
        operators = new HashMap();
        operatorIds = new HashMap();
        operatorFullNames = new LinkedList();
        operatorLoginNames = new LinkedList();
        administrators = new HashMap();
        administratorIds = new HashMap();
        administratorFullNames = new LinkedList();
        administratorLoginNames = new LinkedList();
    }

   
    public Operators() {}
    
   
    public Object getOperatorId(Object fullName){
        Operator operator = (Operator) operators.get(fullName);
       return (operator.getOperatorId()); 
    }
    
    public Operator getOperatorById(Object OperatorId){
        return ((Operator)operatorIds.get(OperatorId));
    }
    
    public Operator getOperatorByFullName(Object fullName){
        return ((Operator)operators.get(fullName)); 
    }
    
    public Operator getOperatorByLoginName(Object loginName){
        return ((Operator)operators.get(loginName)); 
    }
    
    public Operator getOperatorByLoginName(String loginName){
        return ((Operator)operators.get(loginName)); 
    }
        
    public void addOperator(Operator operator) {
      operatorFullNames.add(operator.getFullName());
      operatorLoginNames.add(operator.getOperatorLoginName());
      operators.put(operator.getFullName(), operator);
      operators.put(operator.getOperatorLoginName(), operator);
      operatorIds.put(operator.getOperatorId(), operator);
    }
    
    public void removeOperator(Object fullName) {
        if (operators.containsKey(fullName)){
        operatorIds.remove(getOperatorId(fullName));    
        operatorFullNames.remove(fullName);
        operators.remove(fullName);
        }
    }
    
    public Object getAdministratorId(Object fullName){
       Operator operator = (Operator) administrators.get(fullName);
       return (operator.getOperatorId()); 
    }
    
    public Operator getAdministratorById(Object AdministratorId){
        return ((Operator)administratorIds.get(AdministratorId));
    }
    
    public Operator getAdministratorByFullName(Object fullName){
        return ((Operator)administrators.get(fullName)); 
    }
    
    public void addAdministrator(Operator administrator) {
      administratorFullNames.add(administrator.getFullName());
      administratorLoginNames.add(administrator.getOperatorLoginName());
      administrators.put(administrator.getFullName(), administrator);
      administrators.put(administrator.getOperatorLoginName(), administrator);
      administratorIds.put(administrator.getOperatorId(), administrator);
    }
    
    public void removeAdministrator(Object fullName) {
        if (administrators.containsKey(fullName)){
        administratorIds.remove(getAdministratorId(fullName));    
        administratorFullNames.remove(fullName);
        administrators.remove(fullName);
        }
    }
   
    public Map getOperators(){
        return operators;
    }
    
    public void setOperators(Map operators){
        this.operators = operators;
    }
    
    public Map getAdministrators(){
        return administrators;
    }
    
    public void setAdministrators(Map administrators){
        this.administrators = administrators;
    }
    
    public Map getOperatorIds(){
        return operatorIds;
    }
    
    public void setOperatorIds(Map operatorIds){
        this.operatorIds = operatorIds;
    }
    
    public Map getAdministratorIds(){
        return administratorIds;
    }
    
    public void setAdministratorIds(Map administratorIds){
        this.administratorIds = administratorIds;
    }
     
    public List getOperatorFullNames(){
        return operatorFullNames;
    }
    
    public void setOperatorFullNames(List operatorFullNames){
        this.operatorFullNames = operatorFullNames;
    }
    
    public List getOperatorLoginNames(){
        return operatorLoginNames;
    }
    
    public void setOperatorLoginNames(List operatorLoginNames){
        this.operatorLoginNames = operatorLoginNames;
    }
    
    public List getAdministratorFullNames(){
        return administratorFullNames;
    }
    
    public void setAdministratorFullNames(List administratorFullNames){
        this.administratorFullNames = administratorFullNames;
    }
    
 
}
