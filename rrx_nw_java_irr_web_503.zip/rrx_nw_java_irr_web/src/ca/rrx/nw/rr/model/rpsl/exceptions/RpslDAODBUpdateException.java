package ca.rrx.nw.rr.model.rpsl.exceptions;

/**
 * RpslDAODBUpdateException is an exception that extends the
 * RpslDAOAppException. This is thrown by the DAOs of the Rpsl
 * component when there is an error while writing/updating databases
 */
public class RpslDAODBUpdateException extends RpslDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RpslDAODBUpdateException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RpslDAODBUpdateException() {
        super();
    }

}
