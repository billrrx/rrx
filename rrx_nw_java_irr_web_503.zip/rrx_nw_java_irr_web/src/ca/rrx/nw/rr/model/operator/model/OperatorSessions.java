package ca.rrx.nw.rr.model.operator.model;

import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import java.io.Serializable;
import java.util.*;

/**
 * This class represents all the data needed to
 * identify an operator session from operator sessions.
 * This class is meant to be immutable.
 */
public class OperatorSessions implements Serializable{
    
    private Map operatorSessions;
    private Map operatorSessionIds;
    private List operatorSessionNames;
    private Object operatorId;
    
    {
        operatorSessions = new HashMap();
        operatorSessionIds = new HashMap();
        operatorSessionNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public OperatorSessions(Object operatorId) {
        
        this.operatorId = operatorId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public OperatorSessions() {}
    
    public Object getOperatorId(){
        return operatorId;
    }
   
    public void setOperatorId(Object operatorId){
        this.operatorId = operatorId;
    }
    
    public Object getSessionProfileId(Object sessionProfileName){
        OperatorSession operatorSession = ((OperatorSession)operatorSessions.get(sessionProfileName));
        return operatorSession.getSessionProfileId();
    }
    
    public OperatorSession getOperatorSessionById(Object sessionProfileId){
        return ((OperatorSession)operatorSessionIds.get(sessionProfileId));
    }
    
    public OperatorSession getOperatorSessionByName(Object sessionProfileName){
        return ((OperatorSession)operatorSessions.get(sessionProfileName));
    }
    
    public void addOperatorSession(OperatorSession operatorSession) {
      operatorSessionNames.add(operatorSession.getSessionProfileName());
      operatorSessions.put(operatorSession.getSessionProfileName(), operatorSession);
      operatorSessionIds.put(operatorSession.getSessionProfileId(), operatorSession);
    }
    
    public void removeOperatorSession(Object sessionProfileName) {
        if (operatorSessions.containsKey(sessionProfileName)){
        operatorSessionIds.remove(getSessionProfileId(sessionProfileName));    
        operatorSessionNames.remove(sessionProfileName);
        operatorSessions.remove(sessionProfileName);
        }
    }
   
    public Map getOperatorSessions(){
        return operatorSessions;
    }
     
   public List getOperatorSessionNames(){
        return operatorSessionNames;
    }
    
}
