
package ca.rrx.nw.rr.model.rpsl.dao;

import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOSysException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOAppException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAODBUpdateException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOFinderException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAODupKeyException;

import ca.rrx.nw.rr.model.rpsl.model.RpslModel;

import java.lang.reflect.InvocationTargetException;

public interface RpslDAO {

    public void create(Object daoObject) throws 
    RpslDAOSysException,
    RpslDAODupKeyException,
    RpslDAODBUpdateException,
    RpslDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public RpslModel load(Object operatorId) throws   
    RpslDAOSysException,
    RpslDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void store(Object daoObject) throws 
    RpslDAODBUpdateException,
    RpslDAOAppException,
    RpslDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void remove(Object daoObject) throws 
    RpslDAODBUpdateException,
    RpslDAOSysException;
    
    public Object findByPrimaryKey(Object id) throws 
    RpslDAOFinderException,
    RpslDAOSysException;
}
