
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.ControlPort;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

/**
 * This class represents all the data needed to
 * identify an  controlPort from  controlPorts.
 * This class is meant to be immutable.
 */
public class ControlPorts implements Serializable{
    
    private Map controlPorts;
    private Map controlPortIds;
    private List controlPortNames;
    private Object defaultControlPortId;
    
    {
        controlPorts = new HashMap();
        controlPortIds = new HashMap();
        controlPortNames = new LinkedList();
    }

    public ControlPorts(Object defaultControlPortId) {
        
        this.defaultControlPortId = defaultControlPortId;
        
    }
    
    public ControlPorts() {}
    
   
    public Object getControlPortId(Object controlPortName){
         //Debug.println("ControlPorts:getControlPortId = controlPortName=" + controlPortName);
        return (getControlPortId((ControlPort)controlPorts.get(controlPortName)));
    }
    
    public ControlPort getControlPortById(Object controlPortId){
         //Debug.println("ControlPorts:getControlPortById=" + controlPortId);
        return ((ControlPort)controlPortIds.get(controlPortId));
    }
    
    public ControlPort getControlPortByName(Object controlPortName){
         //Debug.println("ControlPorts:getControlPortByName = controlPortName=" + controlPortName);
        return ((ControlPort)controlPorts.get(controlPortName));
    }
    
    public void addControlPort(ControlPort controlPort) {
      controlPortNames.add(controlPort.getControlPortName());
      controlPorts.put(controlPort.getControlPortName(), controlPort);
      controlPortIds.put(controlPort.getControlPortId(), controlPort);
    }
    
    public void removeControlPort(Object controlPortName) {
        if (controlPorts.containsKey(controlPortName)){
        controlPortIds.remove(getControlPortId(controlPortName));    
        controlPortNames.remove(controlPortName);
        controlPorts.remove(controlPortName);
        }
    }
   
    public Map getControlPorts(){
        return controlPorts;
    }
    
    public Map getControlPortIds(){
        return controlPortIds;
    }
     
    public List getControlPortNames(){
        return controlPortNames;
    }
    
    public Object getDefaultControlPortId(){
        return defaultControlPortId;
    }
    
}
