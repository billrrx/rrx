
package ca.rrx.nw.rr.model.router.exceptions;

import java.lang.RuntimeException;

/**
 * RouterDAOSysException is an exception that extends the standard
 * RunTimeException Exception. This is thrown by the DAOs of the Router
 * component when there is some irrecoverable error (like SQLException)
 */
public class RouterDAOSysException extends RuntimeException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RouterDAOSysException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RouterDAOSysException() {
        super();
    }

}
