package ca.rrx.nw.rr.model.rpsl.model;

import java.io.*;
import java.util.*;
import com.sun.xml.parser.*;
import com.sun.xml.tree.*; 
import org.xml.sax.*;
import org.w3c.dom.*;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

public class RpslDefs {
    
    
    private Hashtable rpslAttributes;
    private Vector rpslAttributeCodes;
    private Vector rpslClasses;
    private Vector rpslAttributeAliases;
    private Vector rpslAttributeAliasesMap;
    private Vector rpslClassAliases;
    private Vector rpslClassAliasesMap;
    private Vector rpslQueries;
    
    private String contextPath = Constants.FULL_BASE_DIR + "/";
    
    public RpslDefs(boolean normalize) {
        // Create a normalized DOM from the xml file for the attributes.
        XmlDocument attrDOM = getDOM(contextPath + "data/xml/attributes.xml", "rpslAttribute", normalize);
        ////Debug.println("RpslDefs: constructor: after getDom attributes.xml");
        // Initialize.
        rpslAttributes = new Hashtable();
        rpslAttributeCodes = new Vector();
        rpslAttributeAliases = new Vector();
        rpslAttributeAliasesMap = new Vector();
        rpslClassAliases = new Vector();
        rpslClassAliasesMap = new Vector();
        rpslQueries = new Vector();
        
        // Recurse through node tree
        NodeList attrNodes = attrDOM.getElementsByTagName("rpslAttribute");
        for (int i=0; i < attrNodes.getLength(); i++) {
            // (Checking if the attribute is valid)
            if (validate("rpslAttribute", attrNodes.item(i))) {
                AttributeDef attributeDef = new AttributeDef(attrNodes.item(i));
                
                // and each attribute,
                rpslAttributes.put(attributeDef.getCode(), attributeDef);
                
                // and it's code.
                rpslAttributeCodes.addElement(attributeDef.getCode());
                
                // and it's aliases.
                // also map the alias to the attribute index.
                
                // set the index to map to.
                Integer mapIndex = new Integer(rpslAttributeCodes.size()-1);
                
                //  first the code.
                rpslAttributeAliases.addElement(attributeDef.getCode());
                rpslAttributeAliasesMap.addElement(mapIndex);
                
                //  then the name.
                rpslAttributeAliases.addElement(attributeDef.getName());
                rpslAttributeAliasesMap.addElement(mapIndex);
                
                if (attributeDef.getAltName().length() > 1) {
                    //  then the altName.
                    rpslAttributeAliases.addElement(attributeDef.getAltName());
                    rpslAttributeAliasesMap.addElement(mapIndex);
                }
            }
        }
        
        // Create a normalized DOM from the xml file for the classes.
        XmlDocument rpslClassesXmlDocument = getDOM(contextPath + "data/xml/classes.xml", "rpslClass", normalize);
        ////Debug.println("RpslDefs: constructor: after getDom classes.xml");
        // Create a vector to store the classes.
        rpslClasses = new Vector();
        
        // Recurse through node tree getElementExById
        NodeList rpslClassNodeList = rpslClassesXmlDocument.getElementsByTagName("rpslClass");
        
        ////Debug.println("RpslDefs: after getDom: classes objNodes.getLength() = " + rpslClassNodeList.getLength());
        ////Debug.println("RpslDefs: after getDom: classes objNodes = " + rpslClassNodeList);
        for (int i=0; i < rpslClassNodeList.getLength(); i++) {
            // Check if the class is valid
            if (validate("class", rpslClassNodeList.item(i))) {
                
                ////Debug.println("RpslDefs: after getDom: classes objNodes.item(i) = " + rpslClassNodeList.item(i));
                ClassDef classDef = new ClassDef(rpslClassNodeList.item(i), rpslAttributes);
                
                // Add the class.
                rpslClasses.addElement(classDef);
                
                // set the index to map to.
                Integer mapIndex = new Integer(rpslClasses.size()-1);
                
                //  first the code.
                rpslClassAliases.addElement(classDef.getCode());
                rpslClassAliasesMap.addElement(mapIndex);
                
                //  then the name.
                rpslClassAliases.addElement(classDef.getName());
                rpslClassAliasesMap.addElement(mapIndex);
                
            }
        }
        
        // replace class/attribute variables in queries
        
        
        
    } // Defs()
    
    public String getValueByEnum(String name) {
        Enumeration e = rpslClasses.elements();
        for( int i = 0; e.hasMoreElements();  i++) {
            ClassDef d = (ClassDef)e.nextElement();
            String a = d.getEnum();
            
            //System.out.println( d );
            
            if( name.equals(a) ) {
                return (new Integer(i)).toString();
            }
        }
        System.out.println("ERROR: cannot resolve variable name " + name );
        System.exit(-1);
        
        return ""; 
    }
    

    private XmlDocument getDOM(String xmlDocName, String rpslClass, boolean normalize) {
        
        // Convert filename to an input source.
        InputSource inSrc= new InputSource();
        try {
            inSrc = Resolver.createInputSource(new File(xmlDocName));
            ////Debug.println("RpslDefs: getDom: xmlDocName = " + xmlDocName + "  inSrc = " + inSrc );
        }
        catch (IOException e) {
            System.err.println("Failed to convert filename: " + xmlDocName +
            "to an input source" + e);
            e.printStackTrace();  System.exit(-1);
        }
        
        // Create and validate a DOM.
        XmlDocument dom=null;
        try {
            dom = XmlDocument.createXmlDocument(inSrc, true);
            ////Debug.println("RpslDefs: getDom: xmlDocument = " + dom );
            
        }
        catch (SAXException e) {
            System.err.println("Failed to create DOM & validate." + e);
            e.printStackTrace();  System.exit(-1);
        }
        catch (IOException e) {
            System.err.println("Failed to create DOM & validate." + e);
            e.printStackTrace();  System.exit(-1);
        }
        
        // Normalize the document.
        if (normalize) {
            dom.getDocumentElement().normalize();
        }
        
        return dom;
        
    } // getDOM()
    
    private boolean validate(String type, Node obj) {
        boolean result=false;
        String status = obj.getAttributes().getNamedItem("status").getNodeValue();
        String name   = obj.getAttributes().getNamedItem("name").getNodeValue();
        
        if (status.equals("valid")) {
            result=true;
        }
        else {
            System.err.println("Warning: " + type + " " + name + " is " + status);
        }
        
        return result;
    } // validClass()
    
    //-------------------GAIT getter methods------------------
    
    //returns a list of all class names
    public List getClassNames() {

        List classNames = new ArrayList();
        ////Debug.println("RpslDefs: getClassNames: enter"); 
        Enumeration enumeration = rpslClasses.elements();
        while (enumeration.hasMoreElements()) {
            String className = ((ClassDef)enumeration.nextElement()).getName();
            classNames.add(className);
            ////Debug.println("RpslDefs: getClassNames: className = " + className);
        }
        return(classNames);
    }
    
     //returns a list of all valid attribute names
     public List getAttributeNames() {

        List attributeNames = new ArrayList();
        ////Debug.println("RpslDefs: getClassNames: enter"); 
        Enumeration enumeration = rpslAttributeCodes.elements();
        while (enumeration.hasMoreElements()) {
            String attributeCode = ((String)enumeration.nextElement());
            AttributeDef attributeDef = (AttributeDef)rpslAttributes.get(attributeCode);
            if (attributeDef.getStatus().equals("valid")) {
                attributeNames.add(attributeDef.getName());
            }
        }
        return(attributeNames);
    }
    
         //returns a list of all valid inverse attribute names
     public List getInverseAttributeNames() {

        List inverseAttributeNames = new ArrayList();
        ////Debug.println("RpslDefs: getClassNames: enter"); 
        Enumeration enumeration = rpslAttributeCodes.elements();
        while (enumeration.hasMoreElements()) {
            String attributeCode = ((String)enumeration.nextElement());
            AttributeDef attributeDef = (AttributeDef)rpslAttributes.get(attributeCode);
            if (attributeDef.getInverse() == true) {
                inverseAttributeNames.add(attributeDef.getName());
            }
        }
        return(inverseAttributeNames);
    }
    
         //returns a list of all valid inverse attribute names for a particular class
     public List getInverseAttributeNames(String className) {
        ClassDef classDef = null;
        List inverseAttributeNames = new ArrayList();
        Enumeration enumerationClasses = rpslClasses.elements();
        
        //get the class definition
        while (enumerationClasses.hasMoreElements()) {
            ClassDef classDefTemp = (ClassDef)enumerationClasses.nextElement();
            if ( className.equals(classDefTemp.getName())) {
                classDef = classDefTemp;
                ////Debug.println("RpslDefs: getInverseAttributeNames: className = " + className + "  classDef = " + classDef );
            }
        }
        //get the class attributes
        Vector classAttributes = classDef.getAttributes();
        
        Enumeration enumerationClassAttributes = classAttributes.elements();
        
        while (enumerationClassAttributes.hasMoreElements()) {
            AttributeDef attributeDef = ((AttributeDef)enumerationClassAttributes.nextElement());
            if (attributeDef.getInverse() == true) {
                inverseAttributeNames.add(attributeDef.getName());
            }
        }
        return(inverseAttributeNames);
    }
    
     //returns a standard rpsl template for the class name
     public String getClassTemplate(String templateClassName) {

        Enumeration enumeration = rpslClasses.elements();

        while (enumeration.hasMoreElements() ) {
            ClassDef classDef = (ClassDef)enumeration.nextElement();
            String className = classDef.getName();
      
            if (className.equalsIgnoreCase(templateClassName)) {
                
                return(classDef.getTemplate(false));
            }
        } 
        return("RpslDefs: getClassTemplate: " + templateClassName + " not found");
    }
    
    // -----------------oOo-----------------
    //              Print Methods
    // -----------------oOo-----------------
    private void printDF_attribute_aliases() {
        System.out.println("char * const Attribute_aliases[] = {");
        Enumeration e = rpslAttributeAliases.elements();
        while (e.hasMoreElements()) {
            String a = (String)e.nextElement();
            System.out.println("  \"" + a + "\",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Attribute_aliases */");
    } // printDF_attribute_aliases()
    
    private void printDF_attribute_aliases_map() {
        System.out.println("int const Attribute_aliases_map[] = {");
        Enumeration e = rpslAttributeAliasesMap.elements();
        while (e.hasMoreElements()) {
            Integer am = (Integer)e.nextElement();
            System.out.println("  " + am + ",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Attribute_aliases_map */");
    } // printDF_attribute_aliases_map()
    
    private void printDF_attribute_codes() {
        System.out.println("char * const Attribute_codes[] = {");
        Enumeration e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            
            // If the attribute has status="valid".
            if (ad.getStatus().equals("valid")) {
                // Output the attribute code.
                System.out.println("  \"" + ad.getCode() + "\",");
            }
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Attribute_codes */");
    } // printDF_attribute_codes()
    
    private void printDF_attribute_enum() {
        System.out.println("typedef enum _A_Type_t {");
        
        // Enumerate through the attribute codes.
        Enumeration e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            
            // If the attribute has status="valid".
            if (ad.getStatus().equals("valid")) {
                // Output the attribute enum.
                System.out.println("  " + ad.getEnum() + ",");
            }
        }
        
        System.out.println("  " + "A_END" + "\n" + "} A_Type_t;");
    } // printDF_attribute_enum()
    
    private void printDF_attribute_inv_attr_mask() {
        System.out.print("#define INV_ATTR_MASK ");
        
        // Enumerate through the attribute codes.
        Enumeration e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            
            // If the attribute has status="valid".
            if (ad.getStatus().equals("valid") && ad.getInverse()) {
                // Output the attribute enum.
                System.out.print(ad.getEnum() + ", ");
            }
        }
        
        System.out.println("MA_END");
    } // printDF_attribute_inv_attr_mask()
    
    private void printDF_attribute_names() {
        System.out.println("char * const Attribute_names[] = {");
        Enumeration e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            
            // If the attribute has status="valid".
            if (ad.getStatus().equals("valid")) {
                // Output the attribute name.
                System.out.println("  \"" + ad.getName() + "\",");
            }
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Attribute_names */");
    } // printDF_attribute_names()
    
    private void printDF_class_aliases() {
        System.out.println("char * const Class_aliases[] = {");
        Enumeration e = rpslClassAliases.elements();
        while (e.hasMoreElements()) {
            String a = (String)e.nextElement();
            System.out.println("  \"" + a + "\",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Class_aliases */");
    } // printDF_class_aliases()
    
    private void printDF_class_aliases_map() {
        System.out.println("int const Class_aliases_map[] = {");
        Enumeration e = rpslClassAliasesMap.elements();
        while (e.hasMoreElements()) {
            Integer am = (Integer)e.nextElement();
            System.out.println("  " + am + ",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Class_aliases_map */");
    } // printDF_class_aliases_map()
    
    private void printDF_class_codes() {
        System.out.println("char * const Class_codes[] = {");
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            ClassDef od = (ClassDef)e.nextElement();
            System.out.println("  \"" + od.getCode() + "\",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Class_codes */");
    } // printDF_class_codes()
    
    private void printDF_class_dbase_code_map() {
        System.out.println("int const Class_dbase_code_map[] = {");
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            ClassDef cd = (ClassDef)e.nextElement();
            System.out.println("  " + cd.getDbaseCode() + ",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Class_dbase_code_map */");
    } // printDF_class_dbase_code_map()
    
    private void printDF_class_enum() {
        System.out.println("typedef enum _C_Type_t {");
        Enumeration e = rpslClasses.elements();
        
        System.out.println("  C_ANY = -1, ");
        while (e.hasMoreElements()) {
            ClassDef od = (ClassDef)e.nextElement();
            System.out.println("  " + od.getEnum() + ",");
        }
        System.out.println("  " + "C_END" + "\n" + "} C_Type_t;");
    } // printDF_class_enum()
    
    private void printDF_class_mask() {
        System.out.print("#define CLASS_MASK ");
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            ClassDef cd = (ClassDef)e.nextElement();
            System.out.print(cd.getEnum() + ", ");
        }
        System.out.println("MA_END");
    } // printDF_class_mask()
    //done
    private void printDF_class_names() {
        System.out.println("char * const Class_names[] = {");
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            String a = ((ClassDef)e.nextElement()).getName();
            System.out.println("  \"" + a + "\",");
        }
        System.out.println("  " + "NULL" + "\n" + "}; /* Class_names */");
    } // printDF_class_names()
    
    private void printQI_queries() {
        System.out.println(RpslQuery.startDoc());
        Enumeration e1 = rpslAttributes.elements();
        while (e1.hasMoreElements()) {
            AttributeDef ad = (AttributeDef)e1.nextElement();
            Enumeration e2 = ad.getQueries().elements();
            while (e2.hasMoreElements()) {
                RpslQuery q = (RpslQuery)e2.nextElement();
                System.out.println(q.getStruct("  ", this));
            }
        }
        System.out.println(RpslQuery.endDoc());
    } // printQI_queries()
    
    private void printUD_queries() {
        
        Enumeration e;
        
        System.out.println("UD_query Insert[] = {");
        e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            System.out.println("  {" + ad.getInsertQ_type() + ", " + "\"" +  ad.getInsert() + "\"},");
        }
        System.out.println("  " + "{0, NULL}" + "\n" + "}; /* Insert */\n");
        
        
        System.out.println("UD_query Update[] = {");
        e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            System.out.println("  {" + ad.getUpdateQ_type() + ", " + "\"" +  ad.getUpdate() + "\"},");
        }
        System.out.println("  " + "{0, NULL}" + "\n" + "}; /* Update */\n");
        
        System.out.println("UD_query Dummy[] = {");
        e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            System.out.println("  {" + ad.getDummyQ_type() + ", " + "\"" +  ad.getDummy() + "\"},");
        }
        System.out.println("  " + "{0, NULL}" + "\n" + "}; /* Dummy */\n");
        
        System.out.println("UD_query Select[] = {");
        e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            System.out.println("  {" + ad.getSelectQ_type() + ", " + "\"" +  ad.getSelect() + "\"},");
        }
        System.out.println("  " + "{0, NULL}" + "\n" + "}; /* Select */\n");
        
    } // printUD_queries()
    
    private void printTemplates() {
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            ClassDef cd = (ClassDef)e.nextElement();
            System.out.println(cd.getName() + "\n");
            System.out.println(cd.getTemplate(false) + "\n");
        }
    } // printTemplates()
    
    private void printDF_class_templates() {
        Enumeration e = rpslClasses.elements();
        System.out.println("const char *Templates[] = {");
        while (e.hasMoreElements()) {
            ClassDef cd = (ClassDef)e.nextElement();
            System.out.print(cd.getTemplate(true));
            System.out.println(",");
        }
        System.out.println("NULL");
        System.out.println("}; /* Templates */");
    } // printDF_class_templates()
    //verbose
    private void printDF_class_templates_v() {
        Enumeration e = rpslClasses.elements();
        System.out.println("const char *Templates_v[] = {");
        while (e.hasMoreElements()) {
            ClassDef od = (ClassDef)e.nextElement();
            System.out.print(od.getTemplateV(true));
            System.out.println(",");
        }
        System.out.println("NULL");
        System.out.println("}; /* Templates_v */");
    } // printDF_class_templates_v()
    
    private void printTemplatesV() {
        Enumeration e = rpslClasses.elements();
        while (e.hasMoreElements()) {
            ClassDef od = (ClassDef)e.nextElement();
            System.out.println(od.getName() + "\n");
            System.out.println(od.getTemplateV(false) + "\n");
        }
    } // printTemplatesV()
    
    private void printDiagrams() {
        int maxWidth=0;  // Widest diagram
        Hashtable foreigns = new Hashtable();
        
        Enumeration e1 = rpslClasses.elements();
        while (e1.hasMoreElements()) {
            ClassDef od = (ClassDef)e1.nextElement();
            if (maxWidth < od.getWidth()) {
                maxWidth = od.getWidth();
            }
            
            Hashtable foriegnAttrs = od.getForeignAttrs();
            if (foriegnAttrs != null) {
                Enumeration e2 = foriegnAttrs.keys();
                while (e2.hasMoreElements()) {
                    String key = (String)e2.nextElement();
                    if (!foreigns.containsKey(key)) {
                        foreigns.put(key, foriegnAttrs.get(key));
                    }
                }
            }
        }
        
        System.out.print("Classes:");
        for (int i=0; i < maxWidth; i++) {
            System.out.print(" ");
        }
        System.out.println("Foreign keys:");
        
        Enumeration e3 = rpslClasses.elements();
        while (e3.hasMoreElements()) {
            ClassDef od = (ClassDef)e3.nextElement();
            System.out.print(od.getDiagram(maxWidth, foreigns));
        }
    } // printDiagrams()
    
    private void printDF_radix_load() {
        System.out.print("DF_Load_t DF_radix_load[] = \n{\n");
        
        // Enumerate through the attribute codes.
        Enumeration e = rpslAttributeCodes.elements();
        while (e.hasMoreElements()) {
            String ac = (String)e.nextElement();
            AttributeDef ad = (AttributeDef)rpslAttributes.get(ac);
            
            // If the attribute has status="valid".
            if (ad.getFamily() != null) {
                String ip4 = ad.getV4Load() != null
                ? "\"" + ad.getV4Load() + "\"" : "NULL";
                String ip6 = ad.getV6Load() != null
                ? "\"" + ad.getV6Load() + "\"" : "NULL";
                
                System.out.print("  { " +  ad.getEnum()
                + ", "   + ad.getFamily()
                + ",\n\t"  + ip4.replace('\n',' ')
                + ",\n\t"  + ip6.replace('\n',' ')
                + "\n  },\n");
            }
        } // while more
        
        
        System.out.println("  { -1, -1, NULL, NULL }\n};");
    } // printDF_radix_load()
    

} // Defs
