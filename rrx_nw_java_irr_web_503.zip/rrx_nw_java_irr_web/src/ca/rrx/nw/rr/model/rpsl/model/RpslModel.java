
package ca.rrx.nw.rr.model.rpsl.model;

import ca.rrx.nw.rr.model.rpsl.model.*;

import java.rmi.RemoteException;
import java.io.*;
import java.util.*;
import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

public class RpslModel implements java.io.Serializable {
    
    private Object operatorId;
    private RpslFilters rpslFilters;
    
        
    public RpslModel(Object operatorId,RpslFilters rpslFilters) {
        this.operatorId = operatorId;
        this.rpslFilters = rpslFilters;
    }
    
    public RpslModel(Object operatorId) {
        this.operatorId = operatorId;
    }

    public RpslModel() {}
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
 
    public RpslFilters getRpslFilters() {
        return rpslFilters;
    }
    
    public void setRpslFilters(RpslFilters rpslFilters) {
        this.rpslFilters = rpslFilters;
    }
    
    public RpslDefs getRpslDefs() {
        //normalize changes the formatting only see ClassDef
        boolean normalize=false;
        
        RpslDefs rpslDefs = new RpslDefs(normalize);
        
        return(rpslDefs);
    }        
  
       
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("RpslModel: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
    
}
