package ca.rrx.nw.rr.model.operator.model;

import java.io.Serializable;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class OperatorSession implements Serializable{
    
    protected Object sessionProfileId;
    protected Object operatorId;
    protected String maintainerCode;
    protected String nicHandle;
    protected String sessionProfileName;
    protected Object primaryServerProfileId;
    protected Object secondaryServerProfileId;
    protected String relativeConfigPath;
    protected String remarks;
    
    /**
     * Test Constructor
     */
    public OperatorSession(Object sessionProfileId, String relativeConfigPath, 
    String maintainerCode,String nicHandle,String sessionProfileName,
    Object primaryServerProfileId,Object secondaryServerProfileId,String remarks){
        
        this.sessionProfileId = sessionProfileId;
        this.relativeConfigPath = relativeConfigPath;
        this.maintainerCode = maintainerCode;
        this.nicHandle = nicHandle;
        this.sessionProfileName = sessionProfileName;
        this.primaryServerProfileId = primaryServerProfileId;
        this.secondaryServerProfileId = secondaryServerProfileId;
        this.remarks = remarks;
    }
    
    /**
     * Default Class constructor
     */
    public OperatorSession() {}
    
  
    public Object getSessionProfileId() {
        return sessionProfileId;
    }
    
    public void setSessionProfileId(Object sessionProfileId) {
        this. sessionProfileId = sessionProfileId;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
        
    public String getRelativeConfigPath() {
        return relativeConfigPath;
    }
    
    public void setRelativeConfigPath(String relativeConfigPath) {
        this.relativeConfigPath = relativeConfigPath;
    }
    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this. maintainerCode = maintainerCode;
    }
    
    public String getNicHandle() {
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle) {
        this. nicHandle = nicHandle;
    }
    
    public String getSessionProfileName() {
        return sessionProfileName;
    }
    
    public void setSessionProfileName(String sessionProfileName) {
        this. sessionProfileName = sessionProfileName;
    }
    
    public Object getPrimaryServerProfileId() {
        return primaryServerProfileId;
    }
    
    public void setPrimaryServerProfileId(Object primaryServerProfileId) {
        this. primaryServerProfileId = primaryServerProfileId;
    }
    
    public Object getSecondaryServerProfileId() {
        return secondaryServerProfileId;
    }
    
    public void setSecondaryServerProfileId(Object secondaryServerProfileId) {
        this. secondaryServerProfileId = secondaryServerProfileId;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String toString(){
        return "[sessionProfileId=" + sessionProfileId
        + ", relativeConfigPath=" + relativeConfigPath
        + ", maintainerCode=" + maintainerCode
        + ", nicHandle=" + nicHandle
        + ", sessionProfileName=" + sessionProfileName
        + ", primaryServerProfileId=" + primaryServerProfileId
        + ", secondaryServerProfileId=" + secondaryServerProfileId
        + ", remarks=" + remarks + "]";
    }
    
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R and nested Address object
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        sqlSetString = sqlSetString.substring(0,sqlSetString.length()-1);
        //Debug.println("OperatorSession.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString);
    }      
}
