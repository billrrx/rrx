
package ca.rrx.nw.rr.model.router.exceptions;

/**
 * RouterDAOFinderException is an exception that extends the
 * RouterDAOAppException. This is thrown by the DAOs of the Router
 * component when there is no row corresponding to a primary key
 */
public class RouterDAOFinderException extends RouterDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RouterDAOFinderException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RouterDAOFinderException() {
        super();
    }

}
