
package ca.rrx.nw.rr.model.operator.dao;

import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOSysException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOAppException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAODBUpdateException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOFinderException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAODupKeyException;

import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;

import java.lang.reflect.InvocationTargetException;


public interface OperatorDAO {
    
    public void create(Object daoObject) throws 
    OperatorDAOSysException,
    OperatorDAODupKeyException,
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public OperatorModel load(String id) throws   
    OperatorDAOSysException,
    OperatorDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void store(Object daoObject) throws 
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void remove(Object daoObject) throws 
    OperatorDAODBUpdateException,
    OperatorDAOSysException;
    
    public String findByPrimaryKey(String id) throws 
    OperatorDAOFinderException,
    OperatorDAOSysException;
    
   
}

