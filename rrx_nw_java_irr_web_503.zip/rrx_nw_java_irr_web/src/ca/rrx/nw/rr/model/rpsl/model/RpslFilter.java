
package ca.rrx.nw.rr.model.rpsl.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import java.io.*;
import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.Constants;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class RpslFilter implements java.io.Serializable {
    
    protected Object rpslFilterId;
    protected Object operatorId;
    protected Object sessionProfileId;
    protected Object serverProfileId;
    protected String rpslObjectType;
    protected String rpslAttributeType;
    protected String filterExpression;

    
    
    public RpslFilter(){}
    
    
    public Object getRpslFilterId() {
        return rpslFilterId;
    }
    
    public void setRpslFilterId(Object rpslFilterId) {
        this. rpslFilterId = rpslFilterId;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public Object getSessionProfileId() {
        return sessionProfileId;
    }
    
    public void setSessionProfileId(Object sessionProfileId) {
        this. sessionProfileId = sessionProfileId;
    }
    
    public Object getServerProfileId() {
        return serverProfileId;
    }
    
    public void setServerProfileId(Object serverProfileId) {
        this. serverProfileId = serverProfileId;
    }
 
    public String getRpslObjectType() {
        return rpslObjectType;
    }
    
    public void setRpslObjectType(String rpslObjectType) {
        this. rpslObjectType = rpslObjectType;
    }
    
    public String getRpslAttributeType() {
        return rpslAttributeType;
    }
    
    public void setRpslAttributeType(String rpslAttributeType) {
        this. rpslAttributeType = rpslAttributeType;
    }
    
    public String getFilterExpression() {
        return filterExpression;
    }
    
    public void setFilterExpression(String filterExpression) {
        this. filterExpression = filterExpression;
    }
    
    
    private static String loadFile(String filePath, String encoding){
        File inputFile;
        FileInputStream is;
        String returnString = new String("");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            inputFile = new File(filePath);
            is = new FileInputStream(inputFile);
            long total =0;
            byte [] buffer = new byte[1024];
            while (true){
                int nRead = is.read(buffer,0,buffer.length);
                total += nRead;
                if (nRead <=0) break;
                bos.write(buffer,0, nRead);
            }
            is.close();
            bos.close();
            
        }catch (IOException e){
            System.out.print ("Error Reading file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Reading: " + e + "\n");
        }
        try{
            byte[] bytes = bos.toByteArray();
            if (encoding != null) returnString = new String(bytes,0, bytes.length, encoding);
            else returnString = new String(bytes);
        }catch (UnsupportedEncodingException enex){
            //Debug.println("Unable to Convert Source File");
        }
        return returnString;
    }
    
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    

    
}

