package ca.rrx.nw.rr.model.rpsl.model;

public class RpslRoute
    extends java.lang.Object
{
    private String route;
    private String descr;
    private String remarks[];
    private String origin;
    private String memberOf;
    private String notify[];
    private String mntBy;
    private String changed;
    private String integrity;
    private String source;

    private int numRemarks;
    private int numNotify;

    public RpslRoute()
    {
        route = new String();
        descr = new String();
        remarks = new String[10];
        origin = new String();
        memberOf = new String();
        notify = new String[10];
        mntBy = new String();
        changed = new String();
        integrity = new String();
        source = new String();

        numRemarks = 0;
        numNotify = 0;
    }

    public void setRoute(String s)
    {
        route = s;
    }

    public void setDescr(String d)
    {
        descr = d;
    }

    public void addRemarks(String r)
    {
        remarks[numRemarks++] = r;
    }

    public void setOrigin(String o)
    {
        origin = o;
    }

    public void setMemberOf(String m)
    {
        memberOf = m;
    }

    public void addNotify(String n)
    {
        notify[numNotify++] = n;
    }

    public void setMntBy(String m)
    {
        mntBy = m;
    }

    public void setChanged(String c)
    {
        changed = c;
    }

    public void setIntegrity(String i)
    {
        integrity = i;
    }

    public void setSource(String s)
    {
        source = s;
    }

    public String getRoute()
    {
        return(route);
    }


    public String getDescr()
    {
        return(descr);
    }

    public String getRemarks(int i)
    {
        return(remarks[i]);
    }

    public String getOrigin()
    {
        return(origin);
    }

    public String getMemberOf()
    {
        return(memberOf);
    }

    public String getNotify(int i)
    {
        return(notify[i]);
    }

    public String getMntBy()
    {
        return(mntBy);
    }

    public String getChanged()
    {
        return(changed);
    }

    public String getIntegrity()
    {
        return(integrity);
    }

    public String getSource()
    {
        return(source);
    }

    public void display()
    {
        System.out.println("<RpslObject>");
        System.out.println("\t<route>" + this.getRoute() + "</route>");
        System.out.println("\t<descr>" + this.getDescr() + "</descr>");
        System.out.println("\t<remarks>" + this.getRemarks(0) + "</remarks>");
        System.out.println("\t<origin>" + this.getOrigin() + "</origin>");
        System.out.println("\t<member-of>" + this.getMemberOf() + "</member-of>");
        System.out.println("\t<notify>" + this.getNotify(0) + "</notify>");
        System.out.println("\t<mnt-by>" + this.getMntBy() + "</mnt-by>");
        System.out.println("\t<changed>" + this.getChanged() + "</changed>");
        System.out.println("\t<integrity>" + this.getIntegrity() + "</integrity>");
        System.out.println("</RpslObject>");
    }

   public String toXml()
    {
       StringBuffer temp;
       temp = new StringBuffer();


       temp.append("<RPSLObject>");
       temp.append("\t<route>" + this.getRoute() + "</route>");
       temp.append("\t<descr>" + this.getDescr() + "</descr>");
       temp.append("\t<remarks>" + this.getRemarks(0) + "</remarks>");
       temp.append("\t<origin>" + this.getOrigin() + "</origin>");
       temp.append("\t<member-of>" + this.getMemberOf() + "</member-of>");
       temp.append("\t<notify>" + this.getNotify(0) + "</notify>");
       temp.append("\t<mnt-by>" + this.getMntBy() + "</mnt-by>");
       temp.append("\t<changed>" + this.getChanged() + "</changed>");
       temp.append("\t<integrity>" + this.getIntegrity() + "</integrity>");
       temp.append("</RPSLObject>");

       return(temp.toString());
    }
}