package ca.rrx.nw.rr.model.operator.exceptions;

/**
 * OperatorDAODBUpdateException is an exception that extends the
 * OperatorDAOAppException. This is thrown by the DAOs of the Operator
 * component when there is an error while writing/updating databases
 */
public class OperatorDAODBUpdateException extends OperatorDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public OperatorDAODBUpdateException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public OperatorDAODBUpdateException() {
        super();
    }

}
