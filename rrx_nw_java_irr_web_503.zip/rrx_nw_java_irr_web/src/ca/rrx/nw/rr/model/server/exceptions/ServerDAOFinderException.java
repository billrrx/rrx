 
package ca.rrx.nw.rr.model.server.exceptions;

/**
 * ServerDAOFinderException is an exception that extends the
 * ServerDAOAppException. This is thrown by the DAOs of the Server
 * component when there is no row corresponding to a primary key
 */
 
public class ServerDAOFinderException extends ServerDAOAppException {

    /*--------------------------------------------------------------------
     * Constructor
     * @param str    a string that explains what the exception condition is
     *--------------------------------------------------------------------*/
     
    public ServerDAOFinderException(String str) 
    {
        super(str);
    }

   
    /*--------------------------------------------------------------------
     * Default constructor. Takes no arguments
     *--------------------------------------------------------------------*/
     
    public ServerDAOFinderException() 
    {
        super();
    }

}
