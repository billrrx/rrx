package ca.rrx.nw.rr.model.rpsl.model;

import java.util.LinkedList;
import java.util.Collection;
import java.util.Iterator;

public class RpslObject
    extends java.lang.Object
{

    private String value;
    private String type;
//    private RpslAttribute attributes[];
    private LinkedList attributes;

    public RpslObject()
    {
        value = new String("");
        type = new String("");
        attributes = new LinkedList();
    }

    public RpslObject(String t, String v)
    {
        type = t;
        value = v;
        attributes = new LinkedList();
    }

    public void setValue(String v)
    {
        value = v;
    }

    public String getKey()
    {
        return (value);
    }

    public void setType(String t)
    {
        type = t;
    }

    public void addAttribute(RpslAttribute a)
    {
        attributes.add(a);
    }

    public RpslAttribute getAttribute(int i)
    {
        return((RpslAttribute)attributes.get(i));
    }

    public Collection getAttributes()
    {
        return(attributes);
    }

    public String toString()
    {
        StringBuffer sb;
        Iterator it;

        sb = new StringBuffer();

        sb.append(type);
        sb.append(": ");
        sb.append(value);

        it = attributes.iterator();

        while(it.hasNext())
        {
            RpslAttribute ra;
            ra = (RpslAttribute)it.next();

            sb.append(ra.getType());
            sb.append(": ");
            sb.append(ra.getValue());
            sb.append("\n");
        }

        sb.append("\n");
        return(new String(sb));
    }

    public String toXmlString()
    {
        StringBuffer sb;
        String newline;
        Iterator it;
        int offset;
        String objectType;

        objectType = null;
        offset = 0;
        newline = System.getProperty("line.separator");
        sb = new StringBuffer();

        sb.append(newline + "\t<" + type + " key=\"" + value + "\">");

        it = attributes.iterator();

        while(it.hasNext())
        {
            RpslAttribute ra;
            ra = (RpslAttribute)it.next();

            sb.append(newline + "\t\t<" + ra.getType() + ">" + ra.getValue() + "</" + ra.getType() + ">");
        }

        sb.append(newline + "\t</" + type + ">");

        return(new String(sb));
    }
}