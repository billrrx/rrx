package ca.rrx.nw.rr.model.operator.model;

import ca.rrx.nw.rr.model.operator.model.Address;
import java.io.Serializable;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class OperatorInformation implements Serializable{

    //note well >>> properties must correspond to db fields exactly
    // no more and no less - both are disastrous
    
    protected String operatorLoginName;
    protected Object operatorId; //new or approved
    protected Object defaultSessionId;
    protected String maintainerCodes;
    protected String password;
    protected String nicHandle;
    protected String firstName;
    protected String lastName;
    protected Address address;
    protected String telephone;
    protected String email;
    protected String lang;
    protected String role;
    protected String remarks;
    
    

    public OperatorInformation() {}

    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public Object getDefaultSessionId() {
        return defaultSessionId;
    }
    
    public void setDefaultSessionId(Object defaultSessionId) {
        this.defaultSessionId = defaultSessionId;
    }
    
    public String getMaintainerCodes() {
        return maintainerCodes;
    }
    
    public void setMaintainerCodes(String maintainerCodes) {
        this.maintainerCodes = maintainerCodes;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getNicHandle(){
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle){
        this.nicHandle = nicHandle;
    }
    
    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }   
    
    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }   

    public Address getAddress(){
        return address;
    }
            
    public void setAddress(Address address){
        this.address = address;
    }   

    public String getTelephone(){
        return telephone;
    }
        
    public void setTelephone(String telephone){
        this.telephone = telephone;
    }   
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }   

    public String getLang(){
        return lang;
    }
            
    public void setLang(String lang){
        this.lang = lang;
    }   
  
    public String getRole(){
        return role;
    }
            
    public void setRole(String role){
        this.role = role;
    }   
      
    public String getRemarks(){
        return remarks;
    }
            
    public void setRemarks(String remarks){
        this.remarks = remarks;
    }   
       
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class") || columnName.equals("Address")) {
                //do nothing-get rid of bean Class info-Bill R and nested Address object
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        sqlSetString = sqlSetString.substring(0,sqlSetString.length()-1);
        //Debug.println("OperatorInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString);
    }      

    
}

