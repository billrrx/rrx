
package ca.rrx.nw.rr.model.rpsl.dao;

import javax.naming.NamingException;
import javax.naming.InitialContext;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOSysException;

import ca.rrx.nw.rr.util.Debug;

public class RpslDAOFactory {

    /**
     * This method instantiates a particular subclass implementing
     * the DAO methods 
     * 
     */
    public static RpslDAO getDAO() throws RpslDAOSysException {

        RpslDAO rtrDao = null;
        try {
            InitialContext ic = new InitialContext();
            String className = (String) ic.lookup(JNDINames.RPSL_DAO_CLASS);
            rtrDao = (RpslDAO) Class.forName(className).newInstance();
        } catch (NamingException ne) {
            throw new RpslDAOSysException("RpslDAOFactory.getDAO:  NamingException while getting DAO type : \n" + ne.getMessage());
        } catch (Exception se) {
            throw new RpslDAOSysException("RpslDAOFactory.getDAO:  Exception while getting DAO type : \n" + se.getMessage());
        }
        return rtrDao;
    }
}
