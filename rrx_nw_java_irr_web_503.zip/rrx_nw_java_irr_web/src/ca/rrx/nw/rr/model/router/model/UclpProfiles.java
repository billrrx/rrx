package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.UclpProfile;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;
/**
 * This class represents all the data needed to
 * identify an  uclpProfile from  uclpProfiles.
 * This class is meant to be immutable.
 */
public class UclpProfiles implements Serializable{
    
    private Map uclpProfiles;
    private Map uclpProfileIds;
    private List uclpProfileNames;
    private Object defaultUclpProfileId;
    
    {
        uclpProfiles = new HashMap();
        uclpProfileIds = new HashMap();
        uclpProfileNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public UclpProfiles(Object defaultUclpProfileId) {
        
        this.defaultUclpProfileId = defaultUclpProfileId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public UclpProfiles() {}
    
   
    public Object getUclpProfileId(Object uclpProfileName){
        return (getUclpProfileId((UclpProfile)uclpProfiles.get(uclpProfileName)));
    }
    
    public UclpProfile getUclpProfileById(Object uclpProfileId){
        return ((UclpProfile)uclpProfileIds.get(uclpProfileId));
    }
    
    public UclpProfile getUclpProfileByName(Object uclpProfileName){
        return ((UclpProfile)uclpProfiles.get(uclpProfileName));
    }
    
    public void addUclpProfile(UclpProfile uclpProfile) {
      uclpProfileNames.add(uclpProfile.getUclpProfileName());
      uclpProfiles.put(uclpProfile.getUclpProfileName(), uclpProfile);
      uclpProfileIds.put(uclpProfile.getUclpProfileId(), uclpProfile);
    }
    
    public void removeUclpProfile(Object uclpProfileName) {
        if (uclpProfiles.containsKey(uclpProfileName)){
        uclpProfileIds.remove(getUclpProfileId(uclpProfileName));    
        uclpProfileNames.remove(uclpProfileName);
        uclpProfiles.remove(uclpProfileName);
        }
    }
   
    public Map getUclpProfiles(){
        return uclpProfiles;
    }
    
    public Map getUclpProfileIds(){
        return uclpProfileIds;
    }
     
    public List getUclpProfileNames(){
        return uclpProfileNames;
    }
    
    public Object getDefaultUclpProfileId(){
        return defaultUclpProfileId;
    }
    
}
