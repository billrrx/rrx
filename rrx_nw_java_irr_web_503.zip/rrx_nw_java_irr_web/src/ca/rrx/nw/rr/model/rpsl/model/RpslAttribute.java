package ca.rrx.nw.rr.model.rpsl.model;

public class RpslAttribute
    extends java.lang.Object
{
    private String type;
    private String value;

    public RpslAttribute()
    {
        type = new String("");
        value = new String("");
    }

    public RpslAttribute(String t, String v)
    {
        type = t;
        value = v;
    }

    public void setType(String t)
    {
        type = t;
    }

    public void setValue(String v)
    {
        value = v;
    }

    public void appendValue(String v)
    {
        value = value + v;
    }

    public String getType()
    {
        return (type);
    }

    public String getValue()
    {
        return (value);
    }
}