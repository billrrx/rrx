
package ca.rrx.nw.rr.model.rpsl.model;

import ca.rrx.nw.rr.model.rpsl.model.RpslFilter;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

public class RpslFilters implements Serializable{
    
    private Map rpslFilterIds;

   
    {

        rpslFilterIds = new HashMap();

    }

    
    public RpslFilters() {}
    
   
   
    //temp need to set the id from other params from action
    public Object getRpslFilterId(RpslFilter rpslFilterMockup){

        Collection collectionRpslFilters = rpslFilterIds.values();
        List selectedFilterExpressions = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();

        int i = 0;
        while (i < collectionRpslFilters.size()) {
            
            rpslFilter = (RpslFilter) iterator.next();
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilterMockup.getSessionProfileId() = " + rpslFilterMockup.getSessionProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilterMockup.getServerProfileId() = " + rpslFilterMockup.getServerProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilterMockup.getRpslObjectType() = " + rpslFilterMockup.getRpslObjectType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilterMockup.getRpslAttributeType() = " + rpslFilterMockup.getRpslAttributeType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilterMockup.getFilterExpression() = " + rpslFilterMockup.getFilterExpression());
            if ( (rpslFilterMockup.getSessionProfileId().equals(rpslFilter.getSessionProfileId())) 
            && (rpslFilterMockup.getServerProfileId().equals(rpslFilter.getServerProfileId()))
            && (rpslFilterMockup.getRpslObjectType().equals(rpslFilter.getRpslObjectType()))
            && (rpslFilterMockup.getRpslAttributeType().equals(rpslFilter.getRpslAttributeType())) 
            && (rpslFilterMockup.getFilterExpression().equals(rpslFilter.getFilterExpression())) ) {
                
            return (rpslFilter.getRpslFilterId());
                
            }
          i++;  
        } 
        return (rpslFilterMockup.getRpslFilterId());
    }    
    
    public RpslFilter getRpslFilterById(Object rpslFilterId){
        return ((RpslFilter)rpslFilterIds.get(rpslFilterId));
    }
    
    
    public void addRpslFilter(RpslFilter rpslFilter) {
      ////Debug.println("RpslFilters: addRpslFilter: rpslFilter.getRpslFilterId() = " + rpslFilter.getRpslFilterId());

      rpslFilterIds.put(rpslFilter.getRpslFilterId(), rpslFilter);
      
    }
    
    public void removeRpslFilter(RpslFilter rpslFilter) {

        rpslFilterIds.remove(rpslFilter.getRpslFilterId());    
   
    }
   
    public Collection getRpslFilters(){
        return rpslFilterIds.values();
    }
    
    public Map getRpslFilterIds(){
        return rpslFilterIds;
    }
/*
    public List getFilterExpressions()
    {
        Collection collectionRpslFilters = rpslFilterIds.values();
        Set selectedFilterExpressions = new HashSet();
        List returnList = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();

        int i = 0;

        while (i < collectionRpslFilters.size())
        {
            rpslFilter = (RpslFilter) iterator.next();
            selectedFilterExpressions.add(rpslFilter.getFilterExpression());

            i++;
        }

        iterator = selectedFilterExpressions.iterator();

        while(iterator.hasNext())
        {
            returnList.add((RpslFilter)iterator.next());
        }

        return returnList;
    }*/


    public Set getFilterExpressions()
//    public List getFilterExpressions()
    {
        Collection collectionRpslFilters = rpslFilterIds.values();
        Set selectedFilterExpressions = new HashSet();
        List returnList = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();

        int i = 0;

        while (i < collectionRpslFilters.size())
        {
            rpslFilter = (RpslFilter) iterator.next();
            selectedFilterExpressions.add(rpslFilter.getFilterExpression());

            i++;
        }

        iterator = selectedFilterExpressions.iterator();
/*
        while(iterator.hasNext())
        {
            returnList.add(iterator.next());
        }
*/

//        return returnList;
        return selectedFilterExpressions;
    }




    public List getFilterExpressionsList()
    {
        Collection collectionRpslFilters = rpslFilterIds.values();
        Set selectedFilterExpressions = new HashSet();
        List returnList = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();

        int i = 0;

        while (i < collectionRpslFilters.size())
        {
            rpslFilter = (RpslFilter) iterator.next();
            selectedFilterExpressions.add(rpslFilter.getFilterExpression());

            i++;
        }

        iterator = selectedFilterExpressions.iterator();

        while(iterator.hasNext())
        {
            String s;
            s = (String)iterator.next();

            returnList.add(s);
            // this works
            //returnList.add(new Integer(1));
        }


        return returnList;
//        return selectedFilterExpressions;
    }

    public List getFilterExpressions(Object sessionProfileId, 
    Object serverProfileId, String rpslObjectType, String rpslAttributeType){
    
        Collection collectionRpslFilters = rpslFilterIds.values();
        List selectedFilterExpressions = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();
        
            ////Debug.println("RpslFilters: getFilterExpressions: sessionProfileId = " + sessionProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: serverProfileId = " + serverProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslObjectType = " + rpslObjectType);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslAttributeType = " + rpslAttributeType);
        
        //int collectionRpslFiltersSize = collectionRpslFilters.size();
        ////Debug.println("RpslFilters: getFilterExpressions: collectionFilterExpressionsSize = " + collectionFilterExpressionsSize);
        int i = 0;
        while (i < collectionRpslFilters.size()) {
            
            rpslFilter = (RpslFilter) iterator.next();
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslFilterId() = " + rpslFilter.getRpslFilterId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getSessionProfileId() = " + rpslFilter.getSessionProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getServerProfileId() = " + rpslFilter.getServerProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslObjectType() = " + rpslFilter.getRpslObjectType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslAttributeType() = " + rpslFilter.getRpslAttributeType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getFilterExpression() = " + rpslFilter.getFilterExpression());
            if ( 
               // (sessionProfileId.equals(rpslFilter.getSessionProfileId())) &&  //disabled for now
                (serverProfileId.equals(rpslFilter.getServerProfileId()))
             && (rpslObjectType.equals(rpslFilter.getRpslObjectType()))
            && (rpslAttributeType.equals(rpslFilter.getRpslAttributeType())) ) {
                
                selectedFilterExpressions.add(rpslFilter.getFilterExpression());
                ////Debug.println("RpslFilters: getFilterExpressions: selectedFilterExpressions = " + selectedFilterExpressions);
            }
          i++;  
        } 
        return selectedFilterExpressions;
    }
    
        public List getAllFilterExpressions(Object sessionProfileId, 
    Object serverProfileId, String rpslAttributeType){
    
        Collection collectionRpslFilters = rpslFilterIds.values();
        List selectedFilterExpressions = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();
        
            ////Debug.println("RpslFilters: getFilterExpressions: sessionProfileId = " + sessionProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: serverProfileId = " + serverProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslObjectType = " + rpslObjectType);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslAttributeType = " + rpslAttributeType);
        
        //int collectionRpslFiltersSize = collectionRpslFilters.size();
        ////Debug.println("RpslFilters: getFilterExpressions: collectionFilterExpressionsSize = " + collectionFilterExpressionsSize);
        int i = 0;
        while (i < collectionRpslFilters.size()) {
            
            rpslFilter = (RpslFilter) iterator.next();
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslFilterId() = " + rpslFilter.getRpslFilterId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getSessionProfileId() = " + rpslFilter.getSessionProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getServerProfileId() = " + rpslFilter.getServerProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslObjectType() = " + rpslFilter.getRpslObjectType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslAttributeType() = " + rpslFilter.getRpslAttributeType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getFilterExpression() = " + rpslFilter.getFilterExpression());
            if ( 
                // (sessionProfileId.equals(rpslFilter.getSessionProfileId())) && //disabled for now
                (serverProfileId.equals(rpslFilter.getServerProfileId()))
             && (rpslAttributeType.equals(rpslFilter.getRpslAttributeType())) ) {
                
                 if (selectedFilterExpressions.contains(rpslFilter.getFilterExpression()))
                 { //do nothing
                 }
                 else
                 {
                 selectedFilterExpressions.add(rpslFilter.getFilterExpression());
                ////Debug.println("RpslFilters: getFilterExpressions: selectedFilterExpressions = " + selectedFilterExpressions);
                 }
            }
          i++;  
        } 
        return selectedFilterExpressions;
    }
    
    public List getDefaultFilterExpressions(String rpslObjectType, String rpslAttributeType){
    
        Collection collectionRpslFilters = rpslFilterIds.values();
        List selectedFilterExpressions = new ArrayList();
        RpslFilter rpslFilter = null;
        Iterator iterator = collectionRpslFilters.iterator();
        
            ////Debug.println("RpslFilters: getFilterExpressions: sessionProfileId = " + sessionProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: serverProfileId = " + serverProfileId);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslObjectType = " + rpslObjectType);
            ////Debug.println("RpslFilters: getFilterExpressions: rpslAttributeType = " + rpslAttributeType);
        
        //int collectionRpslFiltersSize = collectionRpslFilters.size();
        ////Debug.println("RpslFilters: getFilterExpressions: collectionFilterExpressionsSize = " + collectionFilterExpressionsSize);
        int i = 0;
        while (i < collectionRpslFilters.size()) {
            
            rpslFilter = (RpslFilter) iterator.next();
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslFilterId() = " + rpslFilter.getRpslFilterId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getSessionProfileId() = " + rpslFilter.getSessionProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getServerProfileId() = " + rpslFilter.getServerProfileId());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslObjectType() = " + rpslFilter.getRpslObjectType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getRpslAttributeType() = " + rpslFilter.getRpslAttributeType());
            ////Debug.println("RpslFilters: getFilterExpressions: rpslFilter.getFilterExpression() = " + rpslFilter.getFilterExpression());
            if (  (rpslObjectType.equals(rpslFilter.getRpslObjectType()))
            && (rpslAttributeType.equals(rpslFilter.getRpslAttributeType())) ) {
                
                selectedFilterExpressions.add(rpslFilter.getFilterExpression());
                ////Debug.println("RpslFilters: getFilterExpressions: selectedFilterExpressions = " + selectedFilterExpressions);
            }
          i++;  
        } 
        return selectedFilterExpressions;
    }
    
}
