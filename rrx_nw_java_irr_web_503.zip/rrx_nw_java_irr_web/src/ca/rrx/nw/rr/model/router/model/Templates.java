
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.Template;
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

public class Templates implements Serializable{
    
    private Map templates;
    private Map templateIds;
    private List templateTimeStamps;

    {
        templates = new HashMap();
        templateIds = new HashMap();
        templateTimeStamps = new LinkedList();
    }

   
    public Templates() {}
    
   
    public Object getRouterTemplateId(Object templateTimeStamp){
       return (getRouterTemplateId(templates.get(templateTimeStamp))); 
    }
    
    public Template getTemplateById(Object routerTemplateId){
        return ((Template)templateIds.get(routerTemplateId));
    }
    
    public Template getTemplateByTimeStamp(Object templateTimeStamp){
        return ((Template)templates.get(templateTimeStamp)); 
    }
    
    public void addTemplate(Template template) {
      templateTimeStamps.add(template.getTimeStored());
      templates.put(template.getTimeStored(), template);
      templateIds.put(template.getRouterConfigurationId(), template);
    }
    
    public void removeTemplate(Object templateTimeStamp) {
        if (templates.containsKey(templateTimeStamp)){
        templateIds.remove(getRouterTemplateId(templateTimeStamp));    
        templateTimeStamps.remove(templateTimeStamp);
        templates.remove(templateTimeStamp);
        }
    }
   
    public Map getTemplates(){
        return templates;
    }
    
    public void setTemplates(Map templates){
        this.templates = templates;
    }
    
    public Map getTemplateIds(){
        return templateIds;
    }
    
    public void setTemplateIds(Map templateIds){
        this.templateIds = templateIds;
    }
     
    public List getTemplateTimeStamps(){
        return templateTimeStamps;
    }
    
    public void setTemplateIds(List templateTimeStamps){
        this.templateTimeStamps = templateTimeStamps;
    }
    
 
}
