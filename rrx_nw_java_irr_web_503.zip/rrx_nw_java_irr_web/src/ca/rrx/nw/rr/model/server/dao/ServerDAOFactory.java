 
package ca.rrx.nw.rr.model.server.dao;

import javax.naming.NamingException;
import javax.naming.InitialContext;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAOSysException;

import ca.rrx.nw.rr.util.Debug;

public class ServerDAOFactory
{

    public static ServerDAO getDAO() throws ServerDAOSysException
    {

        ServerDAO serverDao = null;
        try 
        {
            InitialContext ic = new InitialContext();
            String className = (String) ic.lookup(JNDINames.SERVER_DAO_CLASS);
            serverDao = (ServerDAO) Class.forName(className).newInstance();
        }
            catch (NamingException ne) 
                  {
                      throw new ServerDAOSysException("ServerDAOFactory.getDAO:  NamingException while getting DAO type : \n" + ne.getMessage());
                  }
            catch (Exception se) 
                  {
                      throw new ServerDAOSysException("ServerrDAOFactory.getDAO:  Exception while getting DAO type : \n" + se.getMessage());
                  }
        return serverDao;
    }
}
