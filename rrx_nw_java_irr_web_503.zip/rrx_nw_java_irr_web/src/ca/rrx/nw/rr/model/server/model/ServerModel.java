 
package ca.rrx.nw.rr.model.server.model;

import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

import java.rmi.RemoteException;
import java.util.List;

import ca.rrx.nw.rr.util.Debug;

 
public class ServerModel implements java.io.Serializable {

    private Servers servers;
    private Server defaultServer;
    private Servers secondaryServers;
    
   /*--------------------------------------------------------------------
    * Class constructor with no arguments, used by the web tier.
    *--------------------------------------------------------------------*/
    
    public ServerModel() {}

    
   /*--------------------------------------------------------------------
    * Class constructor with multiple arguments, used by the web tier.
    *--------------------------------------------------------------------*/ 
    
    public ServerModel(Servers servers) { 
     this.servers = servers;
     this.defaultServer = servers.getServerById(servers.getDefaultServerId());
        //Debug.println("ServerModel:Constructor:Instant- Multiple Arguments");
    }

    
       /*--------------------------------------------------------------------
    * Class constructor with multiple arguments, used by the web tier.
    *--------------------------------------------------------------------*/ 
    
    public ServerModel(Servers servers, Servers secondaryServers) { 
     this.servers = servers;
     this.defaultServer = defaultServer;     
     this.secondaryServers = secondaryServers;
        //Debug.println("ServerModel:Constructor:Instant- Multiple Arguments");
    }
    
   /*--------------------------------------------------------------------
    * Get and Set Methods.
    *--------------------------------------------------------------------*/ 
    
   public Servers getServers() {
        return servers;
    }
    
    public void setServers(Servers servers) {
        this.servers = servers;
    }
    
    public Object getServerProfileId() {
        return defaultServer.getServerProfileId();
    }
    
    public void setServerProfileId(Object serverProfileId) {
        defaultServer.setServerProfileId(serverProfileId);
    }
    
    public String getServerProfileName() {
        return defaultServer.getServerProfileName();
    }
    
    public void setServerProfileName(String serverProfileName) {
        defaultServer.setServerProfileName(serverProfileName);
    }
        
    public String getServerDnsName() {
        return defaultServer.getServerDnsName();
    }
    
    public void setServerDnsName(String serverDnsName) {
        defaultServer.setServerDnsName(serverDnsName);
    }
    
    public String getServerIpv4() {
        return defaultServer.getServerIpv4();
    }
    
    public void setServerIpv4(String serverIpv4) {
        defaultServer.setServerIpv4(serverIpv4);
    }
    
    public String getServerIpv6() {
        return defaultServer.getServerIpv6();
    }
    
    public void setServerIpv6(String serverIpv6) {
        defaultServer.setServerIpv6(serverIpv6);
    }
    
    public String getServerType() {
        return defaultServer.getServerType();
    }
    
    public void setServerType(String serverType) {
        defaultServer.setServerType(serverType);
    }
    
    public String getQueryPort() {
        return defaultServer.getQueryPort();
    }
    
    public void setQueryPort(String queryPort) {
        defaultServer.setQueryPort(queryPort);
    }
    
    public String getUpdatePort() {
        return defaultServer.getUpdatePort();
    }
    
    public void setUpdatePort(String updatePort) {
        defaultServer.setUpdatePort(updatePort);
    }
    
    public String getFloodPort() {
        return defaultServer.getFloodPort();
    }
    
    public void setFloodPort(String floodPort) {
        defaultServer.setFloodPort(floodPort);
    }
    
    public String getMirrorPort() {
        return defaultServer.getMirrorPort();
    }
    
    public void setMirrorPort(String mirrorPort) {
        defaultServer.setMirrorPort(mirrorPort);
    }
    
    public String getAuthoritativeSourceCodes() {
        return defaultServer.getAuthoritativeSourceCodes();
    }

    public void setAuthoritativeSourceCodes(String authoritativeSourceCodes) {
        defaultServer.setAuthoritativeSourceCodes(authoritativeSourceCodes);
    }
    
    public String getMirroredSourceCodes() {
        return defaultServer.getMirroredSourceCodes();
    }
    
    public void setMirroredSourceCodes(String mirroredSourceCodes) {
        defaultServer.setMirroredSourceCodes(mirroredSourceCodes);
    }
    
    public String getFtpServer() {
        return defaultServer.getFtpServer();
    }
    
    public void setFtpServer(String ftpServer) {
        defaultServer.setFtpServer(ftpServer);
    }
    
    public String getFtpPath() {
        return defaultServer.getFtpPath();
    }
    
    public void setFtpPath(String ftpPath) { 
        defaultServer.setFtpPath(ftpPath);
    }
     
    public String getFtpDataFile() {
        return defaultServer.getFtpDataFile();
    }
    
    public void setFtpDataFile(String ftpDataFile) {
        defaultServer.setFtpDataFile(ftpDataFile);
    }
    
    public String getFtpSerialFile() {
        return defaultServer.getFtpSerialFile();
    }
    
    public void setFtpSerialFile(String ftpSerialFile) {
        defaultServer.setFtpSerialFile(ftpSerialFile);
    }
    
    public String getRpslCode() {
        return defaultServer.getRpslCode();
    }
    
    public void setRpslCode(String rpslCode) {
        defaultServer.setRpslCode(rpslCode);
    }
        
    public String getRemarks() {
        return defaultServer.getRemarks();
    }
    
    public void setRemarks(String remarks) {
        defaultServer.setRemarks(remarks);
    }
    
    
   /*--------------------------------------------------------------------
    *   Conversion To String
    *--------------------------------------------------------------------*/      

    public String toString()
    {
        String ret = null;
        ret  = "servers=" + servers + "\n";
        ret += "defaultServer="  + defaultServer + "\n";
        ret += "secondaryServers="  + secondaryServers + "\n";
        return ret;
    }

   /*--------------------------------------------------------------------
    *   Server Shallow Copy
    *--------------------------------------------------------------------*/  
    
    public void copy(ServerModel other) 
    {
        this.servers = other.servers;
        this.defaultServer      = other.defaultServer;
        this.secondaryServers   = other.secondaryServers;
    }
}
