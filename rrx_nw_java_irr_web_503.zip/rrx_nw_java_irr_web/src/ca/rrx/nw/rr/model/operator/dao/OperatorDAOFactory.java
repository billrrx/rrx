package ca.rrx.nw.rr.model.operator.dao;

import javax.naming.NamingException;
import javax.naming.InitialContext;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOSysException;

import ca.rrx.nw.rr.util.Debug;

public class OperatorDAOFactory {

    /**
     * This method instantiates a particular subclass implementing
     * the DAO methods 
     * 
     */
    public static OperatorDAO getDAO() throws OperatorDAOSysException {

        OperatorDAO opDao = null;
        try {
            InitialContext ic = new InitialContext();
            String className = (String) ic.lookup(JNDINames.OPERATOR_DAO_CLASS);
            opDao = (OperatorDAO) Class.forName(className).newInstance();
        } catch (NamingException ne) {
            throw new OperatorDAOSysException("OperatorDAOFactory.getDAO:  NamingException while getting DAO type : \n" + ne.getMessage());
        } catch (Exception se) {
            throw new OperatorDAOSysException("OperatorDAOFactory.getDAO:  Exception while getting DAO type : \n" + se.getMessage());
        }
        return opDao;
    }
}
