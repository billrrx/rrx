
package ca.rrx.nw.rr.model.router.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import java.io.*;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.Constants;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class UclpProfile implements java.io.Serializable {

    private Object uclpProfileId;
    private Object routerProfileId;
    private Object portId;
    private String portType;
    private String uclpProfileName;
    private String uclpConfig;
    private String descr;
    private String memberOf;
    private String remarks;
    private String adminC;
    private String techC;
    private String notify;
    private String mntBy;
    private String changed;
    private String source;
    
    

    //called from routerTransitPortProfile.jsp
    public UclpProfile(String RCPID,String RPID){
                this.uclpProfileId = new Integer(1); //
                this.routerProfileId = new Integer(1); 


    }
    
    public UclpProfile(Object uclpProfileId,Object routerProfileId){
                this.uclpProfileId = uclpProfileId;
                this.routerProfileId = routerProfileId;

    }
    

    public UclpProfile(){}

    public Object clone(){
        return new  TransitPort (uclpProfileId, routerProfileId);

    }

    // get methods for the instance variables

    public Object getUclpProfileId() {
        return uclpProfileId;
    }
    
    public void setUclpProfileId(Object uclpProfileId) {
        this. uclpProfileId = uclpProfileId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public Object getPortId() {
        return portId;
    }
    
    public void setPortId(Object portId) {
        this.portId = portId;
    }
    
    public String getPortType() {
        return portType;
    }
    
    public void setPortType(String portType) {
        this. portType = portType;
    }
    
    public String getUclpProfileName() {
        return uclpProfileName;
    }
    
    public void setUclpProfileName(String uclpProfileName) {
        this. uclpProfileName = uclpProfileName;
    }

    public String getUclpConfig() {
        return uclpConfig;
    }
    
    public void setUclpConfig(String uclpConfig) {
        this.uclpConfig = uclpConfig;
    }

    public String getDescr() {
        return descr;
    }
    
    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getMemberOf() {
        return memberOf;
    }
    
    public void setMemberOf(String memberOf) {
        this.memberOf = memberOf;
    }

    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String getAdminC(){
        return adminC;
    }
    
    public void setAdminC(String adminC) {
        this.adminC = adminC;
    }
    
    public String getTechC(){
        return techC;
    }
    
    public void setTechC(String techC) {
        this.techC = techC;
    }
    
    public String getNotify(){
        return notify;
    }
    
    public void setNotify(String notify) {
        this.notify = notify;
    }
    
    public String getMntBy(){
        return mntBy;
    }
    
    public void setMntBy(String mntBy) {
        this.mntBy = mntBy;
    }
    
    public String getChanged(){
        return changed;
    }
    
    public void setChanged(String changed) {
        this.changed = changed;
    }
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    
        public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
     public String toString(){
        return "[ uclpProfileId=" + uclpProfileId + ", routerProfileId=" + routerProfileId +
                ", portId="  + portId + ", portType=" + portType + 
                ", uclpProfileName=" + uclpProfileName + ", uclpConfig=" + uclpConfig + 
                ", descr="  + descr + ", memberOf=" + memberOf + 
                ", remarks="  + remarks + ", adminC=" + adminC +
                ", techC="  + techC + ", notify=" + notify +
                ", mntBy="  + mntBy + ", changed=" + changed +
                ", source="  + source +
                "]";
    }
    
    public String getRpslUclpConfig(){
        return "uclp-config:    " + uclpConfig + "\n" +
               "descr:          "  + descr + "\n" +
               "member-of:      " + memberOf + "\n" +
               "remarks:        "  + remarks + "\n" +
               "admin-c:        " + adminC + "\n" +
               "tech-c:         "  + techC + "\n" +
               "notify:         " + notify + "\n" +
               "mnt-by:         "  + mntBy + "\n" +
               "changed:        " + changed + "\n" +
               "source:         "  + source  ;
    }

    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("UclpProfile");
        if (id != null)
            root.setAttribute("Id", id);

        Element node = doc.createElement("uclpProfileName");
        node.appendChild(doc.createTextNode(uclpProfileName));
        root.appendChild(node);

        node = doc.createElement("uclpConfig");
        node.appendChild(doc.createTextNode(uclpConfig));
        root.appendChild(node);

        node = doc.createElement("descr");
        node.appendChild(doc.createTextNode(descr));
        root.appendChild(node);
        
        node = doc.createElement("memberOf");
        node.appendChild(doc.createTextNode(memberOf));
        root.appendChild(node);
        
        node = doc.createElement("remarks");
        node.appendChild(doc.createTextNode(remarks));
        root.appendChild(node);
        
        node = doc.createElement("adminC");
        node.appendChild(doc.createTextNode(adminC));
        root.appendChild(node);

        node = doc.createElement("techC");
        node.appendChild(doc.createTextNode(techC));
        root.appendChild(node);

        node = doc.createElement("notify");
        node.appendChild(doc.createTextNode(notify));
        root.appendChild(node);

        node = doc.createElement("mntBy");
        node.appendChild(doc.createTextNode(mntBy));
        root.appendChild(node);
        
        node = doc.createElement("changed");
        node.appendChild(doc.createTextNode(changed));
        root.appendChild(node);
        
        node = doc.createElement("source");
        node.appendChild(doc.createTextNode(source));
        root.appendChild(node);


        return root;
    }
    
    private static String loadFile(String filePath, String encoding){
        File inputFile;
        FileInputStream is;
        String returnString = new String("");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            inputFile = new File(filePath);
            is = new FileInputStream(inputFile);
            long total =0;
            byte [] buffer = new byte[1024];
            while (true){
                int nRead = is.read(buffer,0,buffer.length);
                total += nRead;
                if (nRead <=0) break;
                bos.write(buffer,0, nRead);
            }
            is.close();
            bos.close();
            
        }catch (IOException e){
            System.out.print ("Error Reading file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Reading: " + e + "\n");
        }
        try{
            byte[] bytes = bos.toByteArray();
            if (encoding != null) returnString = new String(bytes,0, bytes.length, encoding);
            else returnString = new String(bytes);
        }catch (UnsupportedEncodingException enex){
            //Debug.println("Unable to Convert Source File");
        }
        return returnString;
    }
     private static void saveFile(ByteArrayInputStream bis, String filePath){
        
        File outputFile;
        FileOutputStream os;
        
        try {
            outputFile = new File(filePath);
            os = new FileOutputStream(outputFile);
            int c;
            while ((c = bis.read()) != -1){
                os.write(c);
            }
            os.close();
    
        }catch (IOException e){
            System.out.print ("Error Writing file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Writing: " + e + "\n");
        }
    }
    
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Command Line Exec Error = " + e.getMessage());
        }
        return("debug cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        //return(new String(stringBuffer));
    }
}

