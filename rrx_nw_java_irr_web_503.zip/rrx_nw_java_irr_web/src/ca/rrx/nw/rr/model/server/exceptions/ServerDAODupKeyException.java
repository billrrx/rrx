

package ca.rrx.nw.rr.model.server.exceptions;


public class ServerDAODupKeyException extends ServerDAOAppException 
{

    /*--------------------------------------------------------------------
     * Constructor
     * @param str    a string that explains what the exception condition is
     *--------------------------------------------------------------------*/
          
    public ServerDAODupKeyException(String str) 
    {
        super(str);
    }

    /*--------------------------------------------------------------------
     * Default constructor. Takes no arguments
     *--------------------------------------------------------------------*/
     
    public ServerDAODupKeyException() 
    {
        super();
    }

}
