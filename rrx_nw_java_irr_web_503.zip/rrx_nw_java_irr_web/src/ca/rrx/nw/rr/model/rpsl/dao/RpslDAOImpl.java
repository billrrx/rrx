
package ca.rrx.nw.rr.model.rpsl.dao;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.rpsl.dao.RpslDAO;
import ca.rrx.nw.rr.util.DatabaseNames;

import ca.rrx.nw.rr.model.rpsl.model.*;

import ca.rrx.nw.rr.model.rpsl.exceptions.*;

import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;



public class RpslDAOImpl implements RpslDAO {
    
    private transient Connection dbConnection = null;
    private transient DataSource datasource   = null;
    
    public RpslDAOImpl() throws RpslDAOSysException {
        try {
            InitialContext ic = new InitialContext();
        } catch (NamingException ne) {
            throw new RpslDAOSysException("Naming Exception while looking "
            + " up DataSource Connection " +
            JNDINames.IRR_DATASOURCE +
            ": \n" + ne.getMessage());
        }
    }
    
    public void create(Object daoObject) throws RpslDAOSysException,
    RpslDAODupKeyException,
    RpslDAODBUpdateException,
    RpslDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RpslFilter rpslFilter = new RpslFilter();
        
       
        if (daoObject.getClass().getName() == rpslFilter.getClass().getName()) {
            rpslFilter = (RpslFilter) daoObject;
            //Debug.println("RpslDAOImpl: create: rpslFilter = "+ rpslFilter);
            insertRpslFilter(rpslFilter);
        } 
        
 
    }
    
    public RpslModel load(Object operatorId) throws 
    RpslDAOSysException,
    RpslDAOFinderException, 
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RpslModel rpslModel = new RpslModel(operatorId,selectRpslFilters(operatorId));
        return(rpslModel);
    }
    
    public void store(Object daoObject) throws RpslDAODBUpdateException,
    RpslDAOAppException,
    RpslDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RpslFilter rpslFilter = new RpslFilter();
        
      
        if (daoObject.getClass().getName() == rpslFilter.getClass().getName()) {
            rpslFilter = (RpslFilter) daoObject;
            //Debug.println("RpslDAOImpl: store: rpslFilter = "+ rpslFilter);
            updateRpslFilter(rpslFilter);
        } 
        

    }
    
    public void remove(Object rpslFilterId) throws RpslDAODBUpdateException,
    RpslDAOSysException {
        deleteRpslFilter(rpslFilterId);
    }
    
    public Object findByPrimaryKey(Object rpslFilterId) throws
    RpslDAOFinderException,
    RpslDAOSysException {
        if (rpslFilterExists(rpslFilterId))
            return (rpslFilterId);
        throw new RpslDAOFinderException("primary key not found :"+rpslFilterId);
    }
    
    private boolean rpslFilterExists(Object rpslFilterId) throws RpslDAOSysException {
        PreparedStatement stmt = null;
        ResultSet result = null;
        boolean returnValue = false;
        String queryStr ="SELECT rpslFilterId FROM " +
        DatabaseNames.RPSL_FILTER_TABLE
        + " WHERE rpslFilterId = " + "'" + rpslFilterId + "'";
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            if ( !result.next() ) {
                returnValue = false;
            } else {
                rpslFilterId = new Integer(result.getInt(1));
                returnValue = true;
            }
        } catch(SQLException se) {
            throw new RpslDAOSysException(
            "SQLException while checking for an"
            + " existing user - id -> " + rpslFilterId + " :\n" + se);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
        return returnValue;
    }
    
    private boolean isValidData(Object rpslFilterId, RpslFilter rpslFilter) {
        if ( (rpslFilter.getOperatorId() == null) ||
        (rpslFilter.getSessionProfileId() == null) ||
        (rpslFilter.getServerProfileId() == null) ||
        (rpslFilter.getRpslAttributeType() == null) )
        return (false);
        else
            return (true);
    }
    

    
    private RpslFilters selectRpslFilters(Object operatorId)
    throws
    RpslDAOSysException,
    RpslDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        //modified to always include operator 0 data 
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.RPSL_FILTER_TABLE
        + " WHERE OperatorId = " + "'" + operatorId + "'" + " OR OperatorId = 0";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            RpslFilters rpslFilters = new RpslFilters();
            
            while (resultSet.next()) {
                
                
                RpslFilter rpslFilter = new RpslFilter();
                copyResultSetToProperties(rpslFilter, resultSet);
                rpslFilters.addRpslFilter(rpslFilter);
           // //Debug.println("RpslDAOImpl: selectRpslFilters: rpslFilter.getSessionProfileId() = " + rpslFilter.getSessionProfileId());
           // //Debug.println("RpslDAOImpl: selectRpslFilters: rpslFilter.getServerProfileId() = " + rpslFilter.getServerProfileId());
           // //Debug.println("RpslDAOImpl: selectRpslFilters: rpslFilter.getRpslObjectType() = " + rpslFilter.getRpslObjectType());
          //  //Debug.println("RpslDAOImpl: selectRpslFilters: rpslFilter.getRpslAttributeType() = " + rpslFilter.getRpslAttributeType());
            }
            return(rpslFilters);
            
        } catch(SQLException ae) {
            throw new RpslDAOSysException("RpslDAOImpl.selectRpslFilters:SQLException while getting rpslFilters \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    

    
    
    //not used - maybe later - Bill R
    private void updateRpslFilter(RpslFilter rpslFilter) throws
    RpslDAODBUpdateException,
    RpslDAOAppException,
    RpslDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.RPSL_FILTER_TABLE + " SET "
        + rpslFilter.propertiesToSqlSetString(rpslFilter) + ","
        + " WHERE RpslFilterId = " + "'" + rpslFilter.getRpslFilterId() + "'";

        //Debug.println("RpslDAOImpl: updateRpslFilter: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RpslDAODBUpdateException
                ("ERROR updating Rpsl in RPSL_FILTER_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RpslDAOSysException("SQLException while updating " +
            "RpslFilter; id = " + rpslFilter.getRpslFilterId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }

   
    private void insertRpslFilter(RpslFilter rpslFilter)
    throws
    RpslDAOSysException,
    RpslDAODupKeyException,
    RpslDAODBUpdateException,
    RpslDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.RPSL_FILTER_TABLE);
        //set this integer into the bean
        rpslFilter.setRpslFilterId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.RPSL_FILTER_TABLE
        + " SET "
        + propertiesToSqlSetString(rpslFilter);

        //Debug.println("RpslDAOImpl.insertRpslFilter: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RpslDAODBUpdateException(
                "RpslDAOImpl.insertRpslFilter:ERROR in RPSL_FILTER_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RpslDAOSysException(
            "RpslDAOImpl.insertRpslFilter:SQLException while inserting new " +
            "RpslFilter=" + rpslFilter + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }


    
    private void deleteRpslFilter (Object rpslFilterId) throws
    RpslDAODBUpdateException,
    RpslDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.RPSL_FILTER_TABLE
        + " WHERE RpslFilterID = " + "'" + rpslFilterId + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RpslDAODBUpdateException
                ("ERROR deleteing Rpsl from RPSL_FILTER_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RpslDAOSysException("SQLException while removing " +
            "Rpsl; id = " + rpslFilterId + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private Object getUniqueId(String tableName) throws 
    RpslDAOSysException,
    RpslDAODBUpdateException
    {
        Object nextId = null;
        getDBConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        try 
        {
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);
            
            ResultSetMetaData rmd  = resultSet.getMetaData();
            ////Debug.println("RpslDAOImpl:getUniqueId: ColumnName1 = "+ rmd.getColumnName(1));
            ////Debug.println("RpslDAOImpl:getUniqueId: ColumnName2 = "+ rmd.getColumnName(2));
            ////Debug.println("RpslDAOImpl:getUniqueId: ColumnName3 = "+ rmd.getColumnName(3));
            
            String columnName = rmd.getColumnName(1);
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(" + columnName + ") FROM " + tableName);
            if(resultSet.next()) nextId = new Integer(resultSet.getInt(1) + 1);
            
        statement.close();    
        closeConnection();
        } 
        catch(SQLException se) 
        {
        throw new RpslDAOSysException("RpslDAOImpl.getUniqueRpslID:RpslDAOSysException=  \n" + se);
        }
        //Debug.println("RpslDAOImpl.getUniqueRpslID:tableName=" + tableName + " nextId=" + nextId);
        return(nextId);
    }
    
    
    private void getDBConnection() throws RpslDAOSysException {

        loadDriver();
        getConnection();
        ////Debug.println("RpslDAOImpl - inside getDBconnection = "+ datasource);

        return;
    }
    
    private void closeConnection() throws RpslDAOSysException {
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
            }
        } catch (SQLException se) {
            throw new RpslDAOSysException("SQL Exception while closing " +
            "DB connection : \n" + se);
        }
    }
    
    private void closeResultSet(ResultSet result) throws RpslDAOSysException {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException se) {
            throw new RpslDAOSysException("SQL Exception while closing " +
            "Result Set : \n" + se);
        }
    }
    
    private void closeStatement(PreparedStatement stmt) throws RpslDAOSysException {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException se) {
            throw new RpslDAOSysException("SQL Exception while closing " +
            "Statement : \n" + se);
        }
    }
    
    
    private PreparedStatement createPreparedStatement(java.sql.Connection con, String querry)
    throws SQLException {
        ArrayList targetStrings = new ArrayList();
        String processedQuerry = "";
        int startIndex = 0;
        if (startIndex != -1) {
            int index = startIndex;
            int literalStart = -1;
            while (index < querry.length()) {
                if (querry.charAt(index) == '\'') {
                    if (literalStart == -1 && index + 1 < querry.length()) {
                        literalStart = index +1;
                    } else {
                        String targetString = querry.substring(literalStart, index);
                        targetStrings.add(targetString);
                        literalStart = -1;
                        processedQuerry += "?";
                        index++;
                    }
                }
                if (index < querry.length() && literalStart == -1) {
                    processedQuerry += querry.charAt(index);
                }
                index++;
            }
            PreparedStatement stmt = con.prepareStatement(processedQuerry + " ");
            Iterator it = targetStrings.iterator();
            int counter =1;
            while (it.hasNext()) {
                String arg = (String)it.next();
                stmt.setString(counter++, arg);
            }
            return stmt;
        } else {
            PreparedStatement stmt = con.prepareStatement(querry);
            return stmt;
        }
    }
    private void loadDriver()
    {
        //see jdbc tutotials
        try {
            
            // The newInstance() call is a work around for some
            // broken Java implementations
            
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
//            System.out.println("SQL Driver Loaded");
            //Debug.println("RpslDAOImpl.loadDriver:SQL Driver Loaded");
        }
        catch (Exception E) {
            System.err.println("Unable to load mySQL JDBC2 driver.");
            E.printStackTrace();
        }
    }
    
    private void getConnection()
    {
        //see jdbc tutotials
        try {
            
            dbConnection = DriverManager.getConnection(Constants.DAO_SQL_KEY);
            System.out.println("SQL Connection Processed");
        }
        catch (SQLException E) {
            System.out.println("SQLException: " + E.getMessage());
            System.out.println("SQLState:     " + E.getSQLState());
            System.out.println("VendorError:  " + E.getErrorCode());
        }
    }
    
    //Object dest should be a bean-like object - Bill R
    private void copyResultSetToProperties(Object dest, ResultSet resultSet)
    throws 
    IllegalAccessException, 
    InvocationTargetException,
    NoSuchMethodException {
        
        if (dest == null)
            throw new IllegalArgumentException
            ("No destination bean specified");
        if (resultSet == null)
            throw new IllegalArgumentException("No origin resultSet specified");
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();
            
            for (int i = 0; i < numberOfColumns; i++) {
                String columnName = rsmd.getColumnName(i + 1);
                //note that the first char of database name is capitalized >>> convert to lowercase to match the bean property
                String propertyName = columnName.substring(0,1).toLowerCase() + columnName.substring(1);
                if (PropertyUtils.getPropertyDescriptor(dest, propertyName) != null) {
                    Object columnValue = resultSet.getObject(columnName);
                    try {
                        PropertyUtils.setSimpleProperty(dest, propertyName, columnValue);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
            
        }   catch (SQLException se) {
            throw new RpslDAOSysException("RpslDAOImpl.copyResultSetToProperties:SQL Exception while copying: \n" + se);
        }
    }
    
    private String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
            //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',"; 
            }
        }
        //chop off the last comma
        //Debug.println("RpslDAOImpl.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
}


