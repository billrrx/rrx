package ca.rrx.nw.rr.model.router.exceptions;

/**
 * RouterDAODBUpdateException is an exception that extends the
 * RouterDAOAppException. This is thrown by the DAOs of the Router
 * component when there is an error while writing/updating databases
 */
public class RouterDAODBUpdateException extends RouterDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RouterDAODBUpdateException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RouterDAODBUpdateException() {
        super();
    }

}
