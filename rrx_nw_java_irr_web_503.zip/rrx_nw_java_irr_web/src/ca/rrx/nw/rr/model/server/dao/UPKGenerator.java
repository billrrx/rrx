 
package ca.rrx.nw.rr.model.server.dao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ca.rrx.nw.rr.model.server.exceptions.ServerDAOSysException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAODBUpdateException;

import ca.rrx.nw.rr.util.Debug;

public class UPKGenerator implements java.io.Serializable {

    /**
     * This method gets the next sequence number
     * and updates the sequence number. A database
     * is used to store the sequence number.
     *
     * @return  the next sequence number
     */
    public static int nextSeqNum(Connection dbConnection) throws
                             ServerDAODBUpdateException, 
                             ServerDAOSysException 
    {
//Debug.println("UPKGenerator.nextSeqNum: Begin");
        int seqNum = 99999;

        Statement s = null;
        ResultSet rs = null;
        try 
        {
            s = dbConnection.createStatement();
            rs = s.executeQuery("SELECT MAX(ServerProfileId) FROM IRRServers");
            if(rs.next())
                seqNum = rs.getInt(1);
                seqNum = seqNum + 1;    
        } 
        catch(SQLException se) 
        {
               throw new ServerDAOSysException(
                        "UPKGenerator:Server:SQL Exception while updating sequence : \n" + se);
        }
//Debug.println("UPKGenerator.nextSeqNum: Before Return: "+ seqNum);        
        return (seqNum);
    }
}
