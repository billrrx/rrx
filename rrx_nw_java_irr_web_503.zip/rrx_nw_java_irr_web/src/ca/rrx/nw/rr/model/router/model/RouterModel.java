
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.*;

import java.rmi.RemoteException;
import java.io.*;
import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

public class RouterModel implements java.io.Serializable {
    
    private String maintainerCode;
    private Routers routers;
    
    public RouterModel(String maintainerCode, Routers routers) {
        this.maintainerCode = maintainerCode;
        this.routers = routers;
    }
    
    public RouterModel(String maintainerCode) {
        this.maintainerCode = maintainerCode;
    }

    public RouterModel() {}
    
    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this.maintainerCode = maintainerCode;
    }
    
    public Routers getRouters() {
        return routers;
    }
    
    public void setRouters(Routers routers) {
        this.routers = routers;
    }
    
    public String getRpslInetRtr(String serverIp, String serverPort, String dnsName) {
        return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -r -T inet-rtr " + dnsName));
    }
    
    public String toString() {
        String ret = null;
        ret = "maintainerCode= " + maintainerCode + "\n";
        ret += "routers="  + routers + "\n";
        return ret;
        
    }
    
    public void copy(RouterModel other) {
        this.maintainerCode = other.maintainerCode;
        this.routers = other.routers;
    }

    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("RouterModel: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
    
}
