package ca.rrx.nw.rr.model.router.dao;

import javax.naming.NamingException;
import javax.naming.InitialContext;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOSysException;

import ca.rrx.nw.rr.util.Debug;

public class RouterDAOFactory {

    /**
     * This method instantiates a particular subclass implementing
     * the DAO methods 
     * 
     */
    public static RouterDAO getDAO() throws RouterDAOSysException {

        RouterDAO rtrDao = null;
        try {
            InitialContext ic = new InitialContext();
            String className = (String) ic.lookup(JNDINames.ROUTER_DAO_CLASS);
            rtrDao = (RouterDAO) Class.forName(className).newInstance();
        } catch (NamingException ne) {
            throw new RouterDAOSysException("RouterDAOFactory.getDAO:  NamingException while getting DAO type : \n" + ne.getMessage());
        } catch (Exception se) {
            throw new RouterDAOSysException("RouterDAOFactory.getDAO:  Exception while getting DAO type : \n" + se.getMessage());
        }
        return rtrDao;
    }
}
