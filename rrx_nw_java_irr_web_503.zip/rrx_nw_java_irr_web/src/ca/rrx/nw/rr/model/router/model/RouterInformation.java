
package ca.rrx.nw.rr.model.router.model;

import java.io.Serializable;
import ca.rrx.nw.rr.Constants;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import java.sql.Timestamp;

import ca.rrx.nw.rr.util.Debug;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class RouterInformation implements Serializable{
    
    
    protected Object routerProfileId;
    protected Object sessionProfileId;
    protected String maintainerCode;
    protected String routerProfileName;
    protected String dnsName;
    protected String locationCode;
    protected String localAs;
    protected String manufacturer;
    protected String model;
    protected String series;
    protected String mainSerialNumber;
    protected String manufacturedDate;
    protected String installationDate;
    protected String osVersion;
    protected String osUpgradeDate;
    protected String osFeatures;
    protected String remarks;
 
    public RouterInformation(Object routerProfileId,Object sessionProfileId,
    String maintainerCode,String routerProfileName,String dnsName,String locationCode,
    String localAs,String manufacturer,String model,String series,String mainSerialNumber,
    String manufacturedDate,String installationDate,String osVersion,String osUpgradeDate,
    String osFeatures,String remarks){
        
        this.routerProfileId = routerProfileId;
        this.sessionProfileId = sessionProfileId;
        this.maintainerCode = maintainerCode;
        this.routerProfileName = routerProfileName;
        this.dnsName = dnsName;
        this.locationCode = locationCode;
        this.localAs = localAs;
        this.manufacturer = manufacturer;
        this.model = model;
        this.series = series;
        this.mainSerialNumber = mainSerialNumber;
        this.manufacturedDate = manufacturedDate;
        this.installationDate = installationDate;
        this.osVersion = osVersion;
        this.osUpgradeDate = osUpgradeDate;
        this.osFeatures = osFeatures;
        this.remarks = remarks;

    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public RouterInformation() {}
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this. routerProfileId = routerProfileId;
    }
    
    public Object getSessionProfileId() {
        return sessionProfileId;
    }
    
    public void setSessionProfileId(Object sessionProfileId) {
        this. sessionProfileId = sessionProfileId;
    }
    
    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this. maintainerCode = maintainerCode;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public String getDnsName() {
        return dnsName;
    }
    
    public void setDnsName(String dnsName) {
        this. dnsName = dnsName;
    }
    
    public String getLocationCode() {
        return locationCode;
    }
    
    public void setLocationCode(String locationCode) {
        this. locationCode = locationCode;
    }
    
    public String getLocalAs() {
        return localAs;
    }
    
    public void setLocalAs(String localAs) {
        this. localAs = localAs;
    }
    
    public String getManufacturer() {
        return manufacturer;
    }
    
    public void setManufacturer(String manufacturer) {
        this. manufacturer = manufacturer;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this. model = model;
    }
    
    public String getSeries() {
        return series;
    }
    
    public void setSeries(String series) {
        this. series = series;
    }
    
    public String getMainSerialNumber() {
        return mainSerialNumber;
    }
    
    public void setMainSerialNumber(String mainSerialNumber) {
        this. mainSerialNumber = mainSerialNumber;
    }
    
    public String getManufacturedDate() {
        return manufacturedDate;
    }
    
    public void setManufacturedDate(String manufacturedDate) {
        this. manufacturedDate = manufacturedDate;
    }
    
    public String getInstallationDate() {
        return installationDate;
    }
    
    public void setInstallationDate(String installationDate) {
        this. installationDate = installationDate;
    }
    
    public String getOsVersion() {
        return osVersion;
    }
    
    public void setOsVersion(String osVersion) {
        this. osVersion = osVersion;
    }
    
    public String getOsUpgradeDate() {
        return osUpgradeDate;
    }
    
    public void setOsUpgradeDate(String osUpgradeDate) {
        this. osUpgradeDate = osUpgradeDate;
    }
    
    public String getOsFeatures() {
        return osFeatures;
    }
    
    public void setOsFeatures(String osFeatures) {
        this. osFeatures = osFeatures;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this. remarks = remarks;
    }
    
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
            //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',"; 
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
    public String toString(){
        return "[routerProfileId=" + routerProfileId
        + ", sessionProfileId=" + sessionProfileId
        + ", maintainerCode=" + maintainerCode
        + ", routerProfileName=" + routerProfileName
        + ", dnsName=" + dnsName
        + ", locationCode=" + locationCode
        + ", localAs=" + localAs
        + ", manufacturer=" + manufacturer
        + ", model=" + model
        + ", series=" + series
        + ", mainSerialNumber=" + mainSerialNumber
        + ", manufacturedDate=" + manufacturedDate
        + ", installationDate=" + installationDate
        + ", osVersion=" + osVersion
        + ", osUpgradeDate=" + osUpgradeDate
        + ", osFeatures=" + osFeatures
        + ", remarks=" + remarks + "]";
    }
    
}
