
package ca.rrx.nw.rr.model.server.dao;

import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.model.server.exceptions.ServerDAOSysException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAOAppException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAODBUpdateException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAOFinderException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAODupKeyException;

import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;


public interface ServerDAO
{
    
    public void create(Server server)
    throws
    ServerDAOSysException,
    ServerDAODupKeyException,
    ServerDAODBUpdateException,
    ServerDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public ServerModel load(Object serverProfileId)
    throws
    ServerDAOSysException,
    ServerDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void store(Server server)
    throws
    ServerDAODBUpdateException,
    ServerDAOAppException,
    ServerDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void remove(Object serverProfileId)
    throws
    ServerDAODBUpdateException,
    ServerDAOSysException;
    
    public Object findByPrimaryKey(Object serverProfileId)
    throws
    ServerDAOFinderException,
    ServerDAOSysException;
    

    
    
}
