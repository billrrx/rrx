package ca.rrx.nw.irr.model.page.dao;
//PageDAO.java

public interface PageDAO
{
};