package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.ControlConnection;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;
/**
 * This class represents all the data needed to
 * identify an  controlConnection from  controlConnections.
 * This class is meant to be immutable.
 */
public class ControlConnections implements Serializable{
    
    private Map controlConnections;
    private Map controlConnectionIds;
    private List controlConnectionNames;
    private Object defaultControlConnectionId;
    
    {
        controlConnections = new HashMap();
        controlConnectionIds = new HashMap();
        controlConnectionNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public ControlConnections(Object defaultControlConnectionId) {
        
        this.defaultControlConnectionId = defaultControlConnectionId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public ControlConnections() {}
    
   
    public Object getControlConnectionId(Object controlConnectionName){
        return (getControlConnectionId((ControlConnection)controlConnections.get(controlConnectionName)));
    }
    
    public ControlConnection getControlConnectionById(Object controlConnectionId){
        return ((ControlConnection)controlConnectionIds.get(controlConnectionId));
    }
    
    public ControlConnection getControlConnectionByName(Object controlConnectionName){
        return ((ControlConnection)controlConnections.get(controlConnectionName));
    }
    
    public void addControlConnection(ControlConnection controlConnection) {
      controlConnectionNames.add(controlConnection.getControlConnectionName());
      controlConnections.put(controlConnection.getControlConnectionName(), controlConnection);
      controlConnectionIds.put(controlConnection.getControlConnectionId(), controlConnection);
    }
    
    public void removeControlConnection(Object controlConnectionName) {
        if (controlConnections.containsKey(controlConnectionName)){
        controlConnectionIds.remove(getControlConnectionId(controlConnectionName));    
        controlConnectionNames.remove(controlConnectionName);
        controlConnections.remove(controlConnectionName);
        }
    }
   
    public Map getControlConnections(){
        return controlConnections;
    }
    
    public Map getControlConnectionIds(){
        return controlConnectionIds;
    }
     
    public List getControlConnectionNames(){
        return controlConnectionNames;
    }
    
    public Object getDefaultControlConnectionId(){
        return defaultControlConnectionId;
    }
    
}