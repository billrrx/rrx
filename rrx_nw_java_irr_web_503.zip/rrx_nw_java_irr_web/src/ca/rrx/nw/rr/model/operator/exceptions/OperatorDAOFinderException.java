
package ca.rrx.nw.rr.model.operator.exceptions;

/**
 * OperatorDAOFinderException is an exception that extends the
 * OperatorDAOAppException. This is thrown by the DAOs of the Operator
 * component when there is no row corresponding to a primary key
 */
public class OperatorDAOFinderException extends OperatorDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public OperatorDAOFinderException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public OperatorDAOFinderException() {
        super();
    }

}
