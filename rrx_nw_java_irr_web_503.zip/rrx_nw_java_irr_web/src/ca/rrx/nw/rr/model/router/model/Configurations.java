package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.Configuration;
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

public class Configurations implements Serializable{
    
    private Map configurations;
    private Map configurationIds;
    private List configurationTimeStamps;

    {
        configurations = new HashMap();
        configurationIds = new HashMap();
        configurationTimeStamps = new LinkedList();
    }

   
    public Configurations() {}
    
   
    public Object getRouterConfigurationId(Object configurationTimeStamp){
       return (getRouterConfigurationId(configurations.get(configurationTimeStamp))); 
    }
    
    public Configuration getConfigurationById(Object routerConfigurationId){
        return ((Configuration)configurationIds.get(routerConfigurationId));
    }
    
    public Configuration getConfigurationByTimeStamp(Object configurationTimeStamp){
        return ((Configuration)configurations.get(configurationTimeStamp)); 
    }
    
    public void addConfiguration(Configuration configuration) {
      configurationTimeStamps.add(configuration.getTimeStored());
      configurations.put(configuration.getTimeStored(), configuration);
      configurationIds.put(configuration.getRouterConfigurationId(), configuration);
    }
    
    public void removeConfiguration(Object configurationTimeStamp) {
        if (configurations.containsKey(configurationTimeStamp)){
        configurationIds.remove(getRouterConfigurationId(configurationTimeStamp));    
        configurationTimeStamps.remove(configurationTimeStamp);
        configurations.remove(configurationTimeStamp);
        }
    }
   
    public Map getConfigurations(){
        return configurations;
    }
    
    public void setConfigurations(Map configurations){
        this.configurations = configurations;
    }
    
    public Map getConfigurationIds(){
        return configurationIds;
    }
    
    public void setConfigurationIds(Map configurationIds){
        this.configurationIds = configurationIds;
    }
     
    public List getConfigurationTimeStamps(){
        return configurationTimeStamps;
    }
    
    public void setConfigurationIds(List configurationTimeStamps){
        this.configurationTimeStamps = configurationTimeStamps;
    }
    
 
}
