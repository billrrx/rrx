
package ca.rrx.nw.rr.model.server.dao;

import java.sql.*;

import java.util.*;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.server.dao.ServerDAO;
//import ca.rrx.nw.rr.model.server.dao.UPKGenerator;
import ca.rrx.nw.rr.util.DatabaseNames;

import ca.rrx.nw.rr.model.server.model.*;

import ca.rrx.nw.rr.model.server.exceptions.*;

import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class ServerDAOImpl implements ServerDAO {
    
    private transient Connection dbConnection = null;
    private transient DataSource datasource   = null;
    
    public ServerDAOImpl()
    throws
    ServerDAOSysException
    {
        try
        {
            InitialContext ic = new InitialContext();
            //Debug.println("ServerDAOImpl - before datasource = "+ ic);
            //== datasource = (DataSource) ic.lookup(JNDINames.IRR_DATASOURCE);
        }
        catch (NamingException ne)
        {
            throw new ServerDAOSysException("ServerDAOImpl:Constructor == Naming Exception while looking "
            + " up DataSource Connection "
            + JNDINames.IRR_DATASOURCE
            + ": \n" + ne.getMessage());
        }
    }
    
    public void create(Server server)
    throws
    ServerDAOSysException,
    ServerDAODupKeyException,
    ServerDAODBUpdateException,
    ServerDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        insertServer(server);
    }
    //this returns the model with the default server set to serverProfileId
    public ServerModel load(Object serverProfileId)
    throws
    ServerDAOSysException,
    ServerDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        ServerModel serverModel = new ServerModel(selectServers(serverProfileId));
        //note secondary servers need to be added here later - Bill R
        return(serverModel);
    }
    
    public void store(Server server)
    throws
    ServerDAODBUpdateException,
    ServerDAOAppException,
    ServerDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException    
    {
        //Debug.println("ServerDAOImpl - store="+ server);
        updateServer(server);
    }
    
    public void remove(Object serverProfileId)
    throws
    ServerDAODBUpdateException,
    ServerDAOSysException
    {
        deleteServer(serverProfileId);
    }
    
    /*---------------------------------------------------------------------
     *   FIND - By Primary Key
     *--------------------------------------------------------------------*/
    
    public Object findByPrimaryKey(Object serverProfileId)
    throws
    ServerDAOFinderException,
    ServerDAOSysException
    {
        if (serverExists(serverProfileId))
            return (serverProfileId);
        throw new ServerDAOFinderException("ServerDAOImpl.findByPrimaryKey == primary key not found :"+serverProfileId);
    }
    
    /*---------------------------------------------------------------------
     *   DUPLICATE KEY  - Check if Record Already Exists
     *--------------------------------------------------------------------*/
    
    private boolean serverExists (Object serverProfileId)
    throws
    ServerDAOSysException
    {
        PreparedStatement stmt            = null;
        ResultSet         result          = null;
        boolean           returnValue     = false;
        String            serverDnsName  = null;
        String queryStr ="SELECT ServerDnsName FROM " +
        DatabaseNames.SERVER_TABLE +
        " WHERE ServerProfileId = " + "'" + serverProfileId + "'";
        ////Debug.println("ServerDAOImpl.serverExists:queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            if ( !result.next() ) {
                returnValue = false;
            } else {
                serverDnsName = result.getString(1);
                returnValue = true;
            }
        } catch(SQLException se) {
            throw new ServerDAOSysException(
            "ServerDAOImpl.serverExists: SQLException while checking for an"
            + " existing Server serverProfileId -> " + serverProfileId + " :\n" + se);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
        return returnValue;
    }
    
    
   /*---------------------------------------------------------------------
    *   INSERT - Adding New Record
    *--------------------------------------------------------------------*/
    
    private void insertServer(Server server)
    throws
    ServerDAOSysException,
    ServerDAODupKeyException,
    ServerDAODBUpdateException,
    ServerDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
       
        Object ServerProfileId = getUniqueServerID();
        server.setServerProfileId(ServerProfileId);

        PreparedStatement stmt = null;
        
        String queryStr = "INSERT INTO "
        + DatabaseNames.SERVER_TABLE
        + " SET "
        + propertiesToSqlSetString(server);

        //Debug.println("ServerDAOImpl.insertServer: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new ServerDAODBUpdateException(
                "ServerDAOImpl.insertServer:ERROR in SERVER_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new ServerDAOSysException(
            "ServerDAOImpl.insertServer:SQLException while inserting new " +
            "Server: DNS = " + server.getServerDnsName() + " :\n" + ae);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    //builds a memory set of all servers for ServerModel
    private Servers selectServers(Object serverProfileId)
    throws
    ServerDAOSysException,
    ServerDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        PreparedStatement stmt = null;
        ResultSet result       = null;
        
        String queryStr = "SELECT * FROM " + DatabaseNames.SERVER_TABLE;
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            
            Servers servers = new Servers(serverProfileId);
            
            while (result.next()) {
                
                
                Server server = new Server();
                copyResultSetToProperties(server, result);
                servers.addServer(server);
            }
            return(servers);
            
        } catch(SQLException ae) {
            throw new ServerDAOSysException("ServerDAOImpl.selectServers:SQLException while getting servers \n" + ae);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
    }
    

   /*---------------------------------------------------------------------
    *   DELETE - Deleting Server Record
    *--------------------------------------------------------------------*/
    
    private void deleteServer (Object serverProfileId)
    throws
    ServerDAODBUpdateException,
    ServerDAOSysException
    {
        String queryStr = "DELETE FROM " +
        DatabaseNames.SERVER_TABLE
        + " WHERE ServerProfileId= " + "'" + serverProfileId + "'";
        PreparedStatement stmt = null;
        
        //Debug.println("ServerDAOImpl.deleteServer:queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new ServerDAODBUpdateException
                ("ERROR deleting IRR Server from SERVER_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.deleteServer:SQLException while removing " +
            "Server: ServerProfileId=" + serverProfileId + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
   /*---------------------------------------------------------------------
    *   UPDATE - Modifying Server Record  needs more work -Bill R
    *--------------------------------------------------------------------*/
    
    private void updateServer(Server server)
    throws
    ServerDAODBUpdateException,
    ServerDAOAppException,
    ServerDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        //Debug.println("ServerDAOImpl.updateServer: before queryString ");
        
        String queryStr = "UPDATE "
        + DatabaseNames.SERVER_TABLE
        + " SET "
        + propertiesToSqlSetString(server)
        + " WHERE ServerProfileId= " + "'" + server.getServerProfileId() + "'";
        ////Debug.println("ServerDAOImpl.updateServer:queryString is: "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if ((resultCount != 1) && (resultCount != 2))
                throw new ServerDAODBUpdateException
                ("ServerDAOImpl.updateServer:ERROR updating Server in SERVER_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.updateServer:SQLException while updating " +
            "Server; id = " + server.getServerDnsName() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void getDBConnection() throws ServerDAOSysException {
        loadDriver();
        getConnection();
        //Debug.println("ServerDAOImpl.getDBConnection:datasource = "+ datasource);
        return;
    }
    
    private void closeConnection() throws ServerDAOSysException {
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
            }
        } catch (SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.closeConnection:SQL Exception while closing " +
            "DB connection : \n" + se);
        }
    }
    
    private void closeResultSet(ResultSet result) throws ServerDAOSysException {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.closeResultSet:SQL Exception while closing " +
            "Result Set : \n" + se);
        }
    }
    
    private void closeStatement(PreparedStatement stmt) throws ServerDAOSysException {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.closeStatement:SQL Exception while closing " +
            "Statement : \n" + se);
        }
    }
    
   
    private PreparedStatement createPreparedStatement(Connection con, String querry)
    throws SQLException {
        ArrayList targetStrings = new ArrayList();
        String processedQuerry = "";
        int startIndex = 0;
        if (startIndex != -1) {
            int index = startIndex;
            int literalStart = -1;
            while (index < querry.length()) {
                if (querry.charAt(index) == '\'') {
                    if (literalStart == -1 && index + 1 < querry.length()) {
                        literalStart = index +1;
                    } else {
                        String targetString = querry.substring(literalStart, index);
                        targetStrings.add(targetString);
                        literalStart = -1;
                        processedQuerry += "?";
                        index++;
                    }
                }
                if (index < querry.length() && literalStart == -1) {
                    processedQuerry += querry.charAt(index);
                }
                index++;
            }
            PreparedStatement stmt = con.prepareStatement(processedQuerry + " ");
            Iterator it = targetStrings.iterator();
            int counter =1;
            while (it.hasNext()) {
                String arg = (String)it.next();
                stmt.setString(counter++, arg);
            }
            return stmt;
        } else {
            PreparedStatement stmt = con.prepareStatement(querry);
            return stmt;
        }
    }
    
   /*---------------------------------------------------------------------
    *   UNIQUE Server ID   - Modifying Server Record
    *--------------------------------------------------------------------*/
    
    private Object getUniqueServerID() throws ServerDAOSysException,
    ServerDAODBUpdateException
    {
        Object nextID = new Integer(0);
        try
        {
            getDBConnection();
            nextID = new Integer(UPKGenerator.nextSeqNum(dbConnection));
            return nextID;
        }
        catch(ServerDAODBUpdateException oddb)
        {
            throw new ServerDAODBUpdateException(oddb.getMessage());
        }
        catch(ServerDAOSysException se)
        {
            throw new ServerDAOSysException("ServerDAOImpl.getUniqueServerID:SQLException while getting " +
            "Server ID : \n" + se);
        }
        finally
        {
            closeConnection();
        }
    }
    
    private void loadDriver()
    {
        try {
            
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            //Debug.println("ServerDAOImpl.loadDriver:SQL Driver Loaded");
        }
        catch (Exception E) {
            //Debug.println("ServerDAOImpl.loadDriver:Unable to load mySQL JDBC2 driver.");
            E.printStackTrace();
        }
    }
    
    private void getConnection()
    {
        //see jdbc tutotials
        try {
            
            dbConnection = DriverManager.getConnection(Constants.DAO_SQL_KEY);
            //Debug.println("ServerDAOImpl.getConnection:SQL Connection Processed");
        }
        catch (SQLException E) {
            //Debug.println("ServerDAOImpl.getConnection:SQLException: " + E.getMessage());
            //Debug.println("ServerDAOImpl.getConnection:SQLState:     " + E.getSQLState());
            //Debug.println("ServerDAOImpl.getConnection:VendorError:  " + E.getErrorCode());
        }
    }
    //Object dest should be a bean-like object - Bill R
    private void copyResultSetToProperties(Object dest, ResultSet resultSet)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        if (dest == null)
            throw new IllegalArgumentException
            ("No destination bean specified");
        if (resultSet == null)
            throw new IllegalArgumentException("No origin resultSet specified");
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();
            
            for (int i = 0; i < numberOfColumns; i++) {
                String columnName = rsmd.getColumnName(i + 1);
                //note that the first char of database name is capitalized >>> convert to lowercase to match the bean property
                String propertyName = columnName.substring(0,1).toLowerCase() + columnName.substring(1);
                if (PropertyUtils.getPropertyDescriptor(dest, propertyName) != null) {
                    Object columnValue = resultSet.getObject(columnName);
                    try {
                        PropertyUtils.setSimpleProperty(dest, propertyName, columnValue);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
            
        }   catch (SQLException se) {
            throw new ServerDAOSysException("ServerDAOImpl.copyResultSetToProperties:SQL Exception while copying: \n" + se);
        }
    }
    
    private String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
            //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',"; 
            }
        }
        //chop off the last comma
        ////Debug.println("ServerDAOImpl.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
    
    
}


