
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.Router;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;
/**
 * This class represents all the data needed to
 * identify an IRR router from IRR routers.
 * This class is meant to be immutable.
 */
public class Routers implements Serializable{
    
    private Map routers;
    private Map routerIds;
    private List routerProfileNames;
    private Object lastRouterId;
    
    {
        routers = new HashMap();
        routerIds = new HashMap();
        routerProfileNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public Routers(Object lastRouterId) {
        
        this.lastRouterId = lastRouterId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public Routers() {}
    
   
    public Object getRouterProfileId(Object routerProfileName){
        return (getRouterProfileId(routers.get(routerProfileName)));
    }
    
    public Router getRouterById(Object routerProfileId){
        return ((Router)routerIds.get(routerProfileId));
    }
    
    public Router getRouterByName(Object routerProfileName){
        return ((Router)routers.get(routerProfileName));
    }
    
    public void addRouter(Router router) {
      routerProfileNames.add(router.getRouterInformation().getRouterProfileName());
      routers.put(router.getRouterInformation().getRouterProfileName(), router);
      routerIds.put(router.getRouterProfileId(), router);
    }
    
    public void removeRouter(Object routerProfileName) {
        if (routers.containsKey(routerProfileName)){
        routerIds.remove(getRouterProfileId(routerProfileName));    
        routerProfileNames.remove(routerProfileName);
        routers.remove(routerProfileName);
        }
    }
   
    public Map getRouters(){
        return routers;
    }
     
   public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
}

