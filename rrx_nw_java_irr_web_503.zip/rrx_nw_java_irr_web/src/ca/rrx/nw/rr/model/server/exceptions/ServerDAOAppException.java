 
package ca.rrx.nw.rr.model.server.exceptions;

 
public class ServerDAOAppException extends Exception 
{

    /*--------------------------------------------------------------------
     * Constructor
     * @param str    a string that explains what the exception condition is
     *--------------------------------------------------------------------*/
     
    public ServerDAOAppException(String str)
    {
        super(str);
    }

    /*--------------------------------------------------------------------
     * Default constructor. Takes no arguments
     *--------------------------------------------------------------------*/
     
    public ServerDAOAppException() 
    {
        super();
    }

}
