
package ca.rrx.nw.rr.model.router.model;

import ca.rrx.nw.rr.model.router.model.TransitPort;
import java.io.Serializable;
import java.util.*;
import ca.rrx.nw.rr.Constants;
/**
 * This class represents all the data needed to
 * identify an  transitPort from  transitPorts.
 * This class is meant to be immutable.
 */
public class TransitPorts implements Serializable{
    
    private Map transitPorts;
    private Map transitPortIds;
    private List transitPortNames;
    private Object defaultTransitPortId;
    
    {
        transitPorts = new HashMap();
        transitPortIds = new HashMap();
        transitPortNames = new LinkedList();
    }
    /**
     * Default Constructor
     */
    public TransitPorts(Object defaultTransitPortId) {
        
        this.defaultTransitPortId = defaultTransitPortId;
        
    }
    
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public TransitPorts() {}
    
   
    public Object getTransitPortId(Object transitPortName){
        return (getTransitPortId((TransitPort)transitPorts.get(transitPortName)));
    }
    
    public TransitPort getTransitPortById(Object transitPortId){
        return ((TransitPort)transitPortIds.get(transitPortId));
    }
    
    public TransitPort getTransitPortByName(Object transitPortName){
        return ((TransitPort)transitPorts.get(transitPortName));
    }
    
    public void addTransitPort(TransitPort transitPort) {
      transitPortNames.add(transitPort.getTransitPortName());
      transitPorts.put(transitPort.getTransitPortName(), transitPort);
      transitPortIds.put(transitPort.getTransitPortId(), transitPort);
    }
    
    public void removeTransitPort(Object transitPortName) {
        if (transitPorts.containsKey(transitPortName)){
        transitPortIds.remove(getTransitPortId(transitPortName));    
        transitPortNames.remove(transitPortName);
        transitPorts.remove(transitPortName);
        }
    }
   
    public Map getTransitPorts(){
        return transitPorts;
    }
    
    public Map getTransitPortIds(){
        return transitPortIds;
    }
     
    public List getTransitPortNames(){
        return transitPortNames;
    }
    
    public Object getDefaultTransitPortId(){
        return defaultTransitPortId;
    }
    
}
