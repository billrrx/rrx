
package ca.rrx.nw.rr.model.rpsl.exceptions;

/**
 * RpslDAODupKeyException is an exception that extends the
 * RpslDAOAppException. This is thrown by the DAOs of the Rpsl
 * component when a row is already found with a given primary key
 */
public class RpslDAODupKeyException extends RpslDAOAppException {
    
    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RpslDAODupKeyException(String str) {
        super(str);
    }
    
    /**
     * Default constructor. Takes no arguments
     */
    public RpslDAODupKeyException() {
        super();
    }
    
}
