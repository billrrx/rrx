 
package ca.rrx.nw.rr.model.server.exceptions;

 
public class ServerDAODBUpdateException extends ServerDAOAppException
{

    /*--------------------------------------------------------------------
     * Constructor
     * @param str    a string that explains what the exception condition is
     *--------------------------------------------------------------------*/
     
    public ServerDAODBUpdateException(String str) 
    {
        super(str);
    }

    /*--------------------------------------------------------------------
     * Default constructor. Takes no arguments
     *--------------------------------------------------------------------*/
     
    public ServerDAODBUpdateException() 
    {
        super();
    }

}
