
package ca.rrx.nw.rr.model.operator.exceptions;

import java.lang.RuntimeException;

/**
 * OperatorDAOSysException is an exception that extends the standard
 * RunTimeException Exception. This is thrown by the DAOs of the Operator
 * component when there is some irrecoverable error (like SQLException)
 */
public class OperatorDAOSysException extends RuntimeException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public OperatorDAOSysException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public OperatorDAOSysException() {
        super();
    }

}
