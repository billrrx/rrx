
package ca.rrx.nw.rr.model.router.exceptions;

/**
 * RouterDAODupKeyException is an exception that extends the
 * RouterDAOAppException. This is thrown by the DAOs of the Router
 * component when a row is already found with a given primary key
 */
public class RouterDAODupKeyException extends RouterDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RouterDAODupKeyException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RouterDAODupKeyException() {
        super();
    }

}
