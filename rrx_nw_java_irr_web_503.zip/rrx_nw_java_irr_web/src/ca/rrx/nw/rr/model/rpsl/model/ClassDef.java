package ca.rrx.nw.rr.model.rpsl.model;

import java.util.*;
import org.w3c.dom.*;
//import org.w3c.dom.traversal.*;
import com.sun.xml.tree.*;
//import org.apache.xerces.dom.*;

import ca.rrx.nw.rr.util.Debug;

public class ClassDef {

  public static final int EXTRA_BIT=11;

  
  private String    rpslClassName;
  private String    rpslClassEnum;
  private String    rpslClassCode;
  private String    rpslClassStatus;
  private String    rpslClassDescription;
  private Vector    rpslClassAttributes;
  private int       dbaseCode;

  private int       width;        
  private Hashtable foreignAttrs;

  public ClassDef(Node rpslClassNode, Hashtable rpslAttributes) {
    width = 0;
    rpslClassName      = rpslClassNode.getAttributes().getNamedItem("name").getNodeValue();
    rpslClassCode      = rpslClassNode.getAttributes().getNamedItem("code").getNodeValue();
    rpslClassStatus    = rpslClassNode.getAttributes().getNamedItem("status").getNodeValue();
    rpslClassEnum      = new String("C_" + rpslClassCode).toUpperCase();
    

    TreeWalker treeWalker = new TreeWalker(rpslClassNode);

    rpslClassDescription = getNodeRawValue(treeWalker.getNextElement("description"));

    Node classAttributesNode = treeWalker.getNextElement("classAttributes");

    rpslClassAttributes = createAttributes(classAttributesNode, rpslAttributes);
    
    dbaseCode = -1;
    Node dcn = treeWalker.getNextElement("dbase_code");
    if (dcn != null) {
      String dbaseCodeStr = dcn.getAttributes().getNamedItem("value").getNodeValue();
      try {
        dbaseCode = Integer.parseInt(dbaseCodeStr);
      }
      catch (NumberFormatException e) {
        System.err.println("Bad dbaseCode: " + dbaseCodeStr); 
        System.err.println("\tencounterd in rpslClassNode: " + rpslClassNode); 
        System.exit(-1);
      }
    }

    foreignAttrs = createForeignAttrs();

  } 

  
  private String getNodeRawValue(Node node) {
    String nodeStr = node.toString();
    int startIndex = nodeStr.indexOf('>') + 1;
    int endIndex = nodeStr.lastIndexOf('<') - 1;
    
    return nodeStr.substring(startIndex, endIndex);
  } 
  

  private Vector createAttributes(Node classAttributesNode, Hashtable rpslAttributes) {
  
    Vector          result = new Vector();
    TreeWalker      treeWalker;
    Node            classAttributeNode   =   null;
    AttributeDef    adTmp;
    String          classAttributeCode   =   null;
    String          classAttributeChoice =    null;
    String          status;


    if (classAttributesNode.hasChildNodes()) {
        
    NodeList classAttributeNodeList = classAttributesNode.getChildNodes();

    treeWalker = new TreeWalker(classAttributesNode);
    
    try {

      for (int i=0; i < classAttributeNodeList.getLength(); i++)
      {
        classAttributeNode = treeWalker.getNext();
          
         if (classAttributeNode.getAttributes() != null) {

        classAttributeChoice = classAttributeNode.getAttributes().getNamedItem("choice").getNodeValue();

        classAttributeCode = new String(classAttributeNode.getNodeName());

        adTmp = (AttributeDef)rpslAttributes.get(classAttributeCode);
        
        if ( adTmp.getName().length() > width ) {
          width = adTmp.getName().length();
        }

        // If the attribute is "valid"
        if ((status=adTmp.getStatus()).equals("valid")) {

          // Create a clone of the attribute.
          AttributeDef attributeDef = null;
          try {
            attributeDef = (AttributeDef)adTmp.clone();
          }
          catch (CloneNotSupportedException e) {
            System.err.println("Doh!");
          }

          // Set the min attribute.
          attributeDef.setChoice(classAttributeNode.getAttributes().getNamedItem("choice").getNodeValue());

          // Set the max attribute.
          attributeDef.setNumber(classAttributeNode.getAttributes().getNamedItem("number").getNodeValue());

          // Add the attribute to this class.
          result.addElement(attributeDef);
        }
        else {
          System.err.println("Warning: rpslClassName: " + rpslClassName + " contains a rpslClassStatus: " +
                             rpslClassStatus + " classAttributeCode: " + classAttributeCode);
        }
       }
      }
    }
    catch (NullPointerException e) {
      System.err.println("Trouble creating class attributes: " + e);
      System.err.println("classAttributeCode=" + classAttributeCode);
      System.err.println("classAttributesNode=" + classAttributesNode);
    }
   }
    return result;
  } 

  private Hashtable createForeignAttrs() {

    Hashtable result = new Hashtable();

    Enumeration e = rpslClassAttributes.elements();
    while (e.hasMoreElements()) {
      AttributeDef ad = (AttributeDef)e.nextElement();
      String code = ad.getCode();
      String foreign = ad.getForeign();
      if (foreign.length() > 1 ) {
        result.put(code, foreign);
      }
    }
    return result;
  } // createAttributes()

  private String toCString(String str) {
    String result = new String();
    char c;
    
    result += "\"";
    for(int i=0; i < str.length(); i++) {
      c = str.charAt(i);
      switch (c) {
        case '\n':
          result += "\\n\"\n\"";
        break;
        
        case '"':
          result += "\\\"";
        break;
        
        case '&':
          if(str.regionMatches(true, i, "&lt;", 0, 4)) {
            result += "<";
            i += 3;
          } else if(str.regionMatches(true, i, "&gt;", 0, 4)) {
            result += ">";
            i += 3;
          }
          else {
            result += c;
          }
        break;

        default:
          result += c;
      }
    }
    result += "\"";

    return result;
  } // toCString

  public String getName() {
    return rpslClassName;
  } // getCode()

  public String getCode() {
    return rpslClassCode;
  } // getCode()

  public String getStatus() {
    return rpslClassStatus;
  } // getStatus()

  public String getDescription(boolean CStyle) {
    String result = rpslClassDescription;

    if (CStyle) {
      result = toCString(rpslClassDescription);
    }

    return result;
  } // getDescription()

  public int getDbaseCode() {
    return dbaseCode;
  } // getDbaseCode()

  public int getWidth() {
    return width + EXTRA_BIT;
  } // getWidth()

  public Vector getAttributes() {
    return rpslClassAttributes;
  } // getAttributes()

  public Hashtable getForeignAttrs() {
    return foreignAttrs;
  } // getForeignAttrs()

  public String getEnum() {
    return rpslClassEnum;
  } // getEnum()

 /**
  * Returns a template for the class in the form:
  *
  * boolean CStyle Returns in C style eg, with "\n\" at the end of each line.
  *
  * person:      [mandatory]  [single]     [primary/look-up key]    
  * address:     [mandatory]  [multiple]   [ ]                      
  * phone:       [mandatory]  [multiple]   [ ]                      
  * fax-no:      [optional]   [multiple]   [ ]                      
  * e-mail:      [optional]   [multiple]   [look-up key]            
  * nic-hdl:     [mandatory]  [single]     [primary/look-up key]    
  * remarks:     [optional]   [multiple]   [ ]                      
  * notify:      [optional]   [multiple]   [inverse key]            
  * mnt-by:      [optional]   [multiple]   [inverse key]            
  * changed:     [mandatory]  [multiple]   [ ]                      
  * source:      [mandatory]  [single]     [ ]                      
  *
  * @return String the template.
  */
  public String getTemplate(boolean CStyle) {
    String result = new String();

    String pad1 = "              "; 
    String pad2 = "           ";
    String pad3 = "           ";

    String sofl = new String();
    String eofl = new String();
    if(CStyle) {
      sofl = "\"";
      eofl = "\\n\"\n";
    }
    else {
      sofl = "";
      eofl = "\n";
    }

    AttributeDef ad;
    String name, choice, number, keytype;
    Enumeration e = rpslClassAttributes.elements();
    while (e.hasMoreElements()) {
      ad = (AttributeDef)e.nextElement();
      name = ad.getName();
      choice = ad.getChoice();
      number = ad.getNumber();
      keytype = ad.getKeytype2();
      result += (sofl + name + ":"                                 +
                 pad1.substring(0, pad1.length()-name.length())    +
                 "[" + choice + "]"                                +
                 pad2.substring(0, pad2.length()-choice.length())  +
                 "[" + number + "]"                                +
                 pad3.substring(0, pad3.length()-number.length())  +
                 "[" + keytype + "]"                               +
                 eofl
                );
    }

    return result;
  } // getTemplate()

  public String getTemplateV(boolean CStyle) {
    String result=new String();
    String templ = getTemplate(CStyle);

    String sofl = new String();
    String eofl = new String();
    if(CStyle) {
      sofl = "\"";
      eofl = "\\n\"\n";
    }
    else {
      sofl = "";
      eofl = "\n";
    }

    result += (sofl + "The " + rpslClassName + " class:" + eofl          +
               toCString(rpslClassDescription)                           +
               sofl + eofl                                      +
               templ                                            +
               sofl + eofl                                      +
               sofl + "The content of the attributes of the "   +
               rpslClassName + " class are defined below:" + eofl        +
               sofl + eofl
              );

    AttributeDef ad;
    String name, rpslClassDescription, format;
    Enumeration e = rpslClassAttributes.elements();
    while (e.hasMoreElements()) {
      ad = (AttributeDef)e.nextElement();
      name = ad.getName();
      if (CStyle) {
        rpslClassDescription = toCString(ad.getDescription());
        format = toCString(ad.getFormat());
      }
      else {
        rpslClassDescription = ad.getDescription();
        format = ad.getFormat();
      }

      result += (sofl + rpslClassName + eofl +
                 rpslClassDescription        +
                 format             +
                 sofl + eofl     
                );
    }

    result += (sofl + eofl                                               +
               sofl + "Further information may be found at:" + eofl      +
               sofl + eofl                                               +
               sofl + "http://www.oran.net/docs" + eofl    +
               sofl + "ftp://ftp.oran.net/docs" + eofl  +
               sofl + eofl
              );

    return result;
  } // getTemplateV()

  public String getDiagram(int maxWidth, Hashtable foreigns) {
    ClassDiagram om = new ClassDiagram(this, maxWidth, foreigns);

    return om.toString();
  } // getDiagram()

  /*
  public boolean equals(ClassDef ro) {
    return code.equals(ro.getCode());
  } // equals()
  */
    
  public String toString() {
    return new String("rpslClass={" +
                         "\n\tname="         + rpslClassName          +
                         "\n\tcode="         + rpslClassCode          +
                         "\n\tstatus="       + rpslClassStatus        +
                         "\n\tdescription="  + rpslClassDescription   +
                         "\n\tattributes="   + rpslClassAttributes    +
                         "\n\tdbaseCode="    + dbaseCode     +
                         "\n\twidth="        + width         +
                         "\n\tforeignAttrs=" + foreignAttrs  +
                         "\n}");
  } // toString()


  public class ClassDiagram {
    private Vector    diagram;

    public ClassDiagram(ClassDef od, int maxWidth, Hashtable foreigns) {
      diagram = new Vector();
      String line = new String();

      String border = new String();
      border = "+-"; 
      for (int i=0; i < getWidth(); i++) {
        border += ("-");
      }
      border += "-+   "; 
      for (int i=od.getWidth(); i < maxWidth; i++) {
        border += (" ");
      }
      Enumeration e1 = foreigns.keys();
      while (e1.hasMoreElements()) {
        String foreign = (String)e1.nextElement();
        if (e1.hasMoreElements()) {
          border += ("|--");
        }
      }
      border += ("|\n");
      diagram.addElement(border);

      line = ("| " + od.getCode() + ": " + od.getName());
      for (int i=od.getName().length()+4; i < getWidth(); i++) {
        line += (" ");
      }
      line += (" |   ");
      for (int i=od.getWidth(); i < maxWidth; i++) {
        line += (" ");
      }
      Enumeration e3 = foreigns.keys();
      while (e3.hasMoreElements()) {
        String foreign = (String)e3.nextElement();
        line += (foreign + " ");
      }
      line += ("\n");
      diagram.addElement(line);

      diagram.addElement(border);

      AttributeDef ad;
      Enumeration e = od.getAttributes().elements();
      while (e.hasMoreElements()) {
        ad = (AttributeDef)e.nextElement();
        String name = ad.getName();
        String keytype = ad.getKeytype3();
        line = ("| " + ad.getCode() + ": " + name + " ");
        for (int i=name.length(); i < width; i++) {
          line += (" ");
        }
        line += (keytype + " |");

        // The horizontal line.
        // Is a foreign key.
        boolean f = (ad.getForeign().length() > 1);
        // Is a referenced key.
        boolean p = (foreigns.contains(ad.getCode()));
        if (f) {
          line += ("->-");
        }
        else if (p) {
          line += ("-|-");
        } else {
          line += ("   ");
        }
        for (int i=od.getWidth(); i < maxWidth; i++) {
          if (f || p) {
            line += ("-");
          }
          else {
            line += (" ");
          }
        }

        // Add the xrefs.
        Enumeration e2 = foreigns.keys();
        while (e2.hasMoreElements()) {
          String foreign = (String)e2.nextElement();
          String code = ad.getCode();
          if (foreign.equals(code)) {
            line += ("X");
          }
          else if (foreigns.get(foreign).equals(code)) {
            line += ("o");
          }
          else {
            line += ("|");
          }
          if (e2.hasMoreElements()) {
            line += ("--");
          }
        }
        line += ("\n");
        diagram.addElement(line);
      }

      diagram.addElement(border);
    } // ClassDiagram()

    public String toString() {
      String result = new String();

      Enumeration e = diagram.elements();
      while (e.hasMoreElements()) {
        String line = (String)e.nextElement();
        result += line;
      }
      
      return result;
    } // toString()

  } // ClassDiagram

} // ClassDef
