package ca.rrx.nw.rr.model.operator.model;

import ca.rrx.nw.rr.model.operator.model.*;
import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;

public class OperatorEvents implements Serializable{
    
    private Map operatorEvents;
    private Map operatorEventIds;
    private List operatorEventTimeStamps;

    {
        operatorEvents = new HashMap();
        operatorEventIds = new HashMap();
        operatorEventTimeStamps = new LinkedList();
    }

   
    public OperatorEvents() {}
    
   
    public Object getOperatorEventId(Object operatorEventTimeStamp){
       return (getOperatorEventId(operatorEvents.get(operatorEventTimeStamp))); 
    }
    
    public OperatorEvent getOperatorEventById(Object operatorEventId){
        return ((OperatorEvent)operatorEventIds.get(operatorEventId));
    }
    
    public OperatorEvent getOperatorEventByTimeStamp(Object operatorEventTimeStamp){
        return ((OperatorEvent)operatorEvents.get(operatorEventTimeStamp)); 
    }
    
    public void addOperatorEvent(OperatorEvent operatorEvent) {
      operatorEventTimeStamps.add(operatorEvent.getTimeStored());
      operatorEvents.put(operatorEvent.getTimeStored(), operatorEvent);
      operatorEventIds.put(operatorEvent.getOperatorEventId(), operatorEvent);
    }
    
    public void removeOperatorEvent(Object operatorEventTimeStamp) {
        if (operatorEvents.containsKey(operatorEventTimeStamp)){
        operatorEventIds.remove(getOperatorEventId(operatorEventTimeStamp));    
        operatorEventTimeStamps.remove(operatorEventTimeStamp);
        operatorEvents.remove(operatorEventTimeStamp);
        }
    }
   
    public Map getOperatorEvents(){
        return operatorEvents;
    }
    
    public void setOperatorEvents(Map operatorEvents){
        this.operatorEvents = operatorEvents;
    }
    
    public Map getOperatorEventIds(){
        return operatorEventIds;
    }
    
    public void setOperatorEventIds(Map operatorEventIds){
        this.operatorEventIds = operatorEventIds;
    }
     
    public List getOperatorEventTimeStamps(){
        return operatorEventTimeStamps;
    }
    
    public void setOperatorEventIds(List operatorEventTimeStamps){
        this.operatorEventTimeStamps = operatorEventTimeStamps;
    }
    
     public String toString() {
        String ret = null;
        ret = "operatorEvents= " + operatorEvents + "\n";
        ret += "operatorEventIds= " + operatorEventIds + "\n";
        ret += "operatorEventTimeStamps= " + operatorEventTimeStamps + "\n";
        return ret;
        }
    
}
