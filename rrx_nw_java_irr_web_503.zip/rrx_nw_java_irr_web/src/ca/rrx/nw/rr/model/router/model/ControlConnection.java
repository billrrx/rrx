package ca.rrx.nw.rr.model.router.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;
import java.io.*;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.Constants;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class ControlConnection implements java.io.Serializable {

    private Object controlConnectionId;
    private Object routerProfileId;
    private String controlConnectionName;
    private String controlConnectionNumber;
    private String timeStored;
    private String connectionType;
    private String connectionParameter1;
    private String connectionParameter2;
    private String typeConfigPath;
    private String executablePath;
    private String loginName;
    private String password;
    private String connectionServer;
    private String connectionServerPath;
    private String targetServerPath;
    private String remarks;    

    //called from routerConnectionProfile.jsp
    public ControlConnection(String RCPID,String RPID){
                this.controlConnectionId = new Integer(1); //
                this.routerProfileId = new Integer(1); 


    }
    
    public ControlConnection(Object controlConnectionId,Object routerProfileId){
                this.controlConnectionId = controlConnectionId;
                this.routerProfileId = routerProfileId;

    }
    

    public ControlConnection(){}

    public Object clone(){
        return new  ControlConnection (controlConnectionId, routerProfileId);

    }

    // get methods for the instance variables

    public Object getControlConnectionId() {
        return controlConnectionId;
    }
    
    public void setControlConnectionId(Object controlConnectionId) {
        this. controlConnectionId = controlConnectionId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getControlConnectionName() {
        return controlConnectionName;
    }
    
    public void setControlConnectionName(String controlConnectionName) {
        this. controlConnectionName = controlConnectionName;
    }

    public String getControlConnectionNumber() {
        return controlConnectionNumber;
    }
    
    public void setControlConnectionNumber(String controlConnectionNumber) {
        this.controlConnectionNumber = controlConnectionNumber;
    }

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }

    public String getConnectionType() {
        return connectionType;
    }
    
    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getConnectionParameter1() {
        return connectionParameter1;
    }

    public void setConnectionParameter1(String connectionParameter1) {
        this.connectionParameter1 = connectionParameter1;
    }

    public String getConnectionParameter2() {
        return connectionParameter2;
    }

    public void setConnectionParameter2(String connectionParameter2) {
        this.connectionParameter2 = connectionParameter2;
    }

    public String getTypeConfigPath() {
        return typeConfigPath;
    }

    public void setTypeConfigPath(String typeConfigPath) {
        this.typeConfigPath = typeConfigPath;
    }

    public String getExecutablePath(){
        return executablePath;
    }
    
    public void setExecutablePath(String executablePath) {
        this.executablePath = executablePath;
    }
    
    public String getLoginName(){
        return loginName;
    }
    
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getConnectionServer(){
        return connectionServer;
    }
    
    public void setConnectionServer(String connectionServer) {
        this.connectionServer = connectionServer;
    }
    
    public String getConnectionServerPath(){
        return connectionServerPath;
    }
    
    public void setConnectionServerPath(String connectionServerPath) {
        this.connectionServerPath = connectionServerPath;
    }
    
    public String getTargetServerPath(){
        return targetServerPath;
    }
    
    public void setTargetServerPath(String targetServerPath) {
        this.targetServerPath = targetServerPath;
    }

    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
     public String toString(){
        return "[ controlConnectionId=" + controlConnectionId + ", routerProfileId=" + routerProfileId +
                ", controlConnectionName="  + controlConnectionName + ", controlConnectionNumber=" + controlConnectionNumber + 
                ", timeStored=" + timeStored + ", connectionType=" + connectionType + 
                ", connectionParameter1="  + connectionParameter1 + ", connectionParameter2=" + connectionParameter2 + 
                ", typeConfigPath="  + typeConfigPath + ", executablePath=" + executablePath +
                ", loginName="  + loginName + ", password=" + password +
                ", connectionServer="  + connectionServer + ", connectionServerPath=" + connectionServerPath + 
                ", targetServerPath=" + targetServerPath +
                "]";
    }

    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("ControlConnection");
        if (id != null)
            root.setAttribute("Id", id);

        Element node = doc.createElement("controlConnectionName");
        node.appendChild(doc.createTextNode(controlConnectionName));
        root.appendChild(node);

        node = doc.createElement("controlConnectionNumber");
        node.appendChild(doc.createTextNode(controlConnectionNumber));
        root.appendChild(node);

        node = doc.createElement("timeStored");
        node.appendChild(doc.createTextNode(timeStored));
        root.appendChild(node);
        
        node = doc.createElement("connectionType");
        node.appendChild(doc.createTextNode(connectionType));
        root.appendChild(node);
        
        node = doc.createElement("connectionParameter1");
        node.appendChild(doc.createTextNode(connectionParameter1));
        root.appendChild(node);
        
        node = doc.createElement("connectionParameter2");
        node.appendChild(doc.createTextNode(connectionParameter2));
        root.appendChild(node);

        node = doc.createElement("typeConfigPath");
        node.appendChild(doc.createTextNode(typeConfigPath));
        root.appendChild(node);

        node = doc.createElement("executablePath");
        node.appendChild(doc.createTextNode(executablePath));
        root.appendChild(node);

        node = doc.createElement("loginName");
        node.appendChild(doc.createTextNode(loginName));
        root.appendChild(node);

        node = doc.createElement("password");
        node.appendChild(doc.createTextNode(password));
        root.appendChild(node);
        
        node = doc.createElement("connectionServer");
        node.appendChild(doc.createTextNode(connectionServer));
        root.appendChild(node);
        
        node = doc.createElement("connectionServerPath");
        node.appendChild(doc.createTextNode(connectionServerPath));
        root.appendChild(node);
        
        node = doc.createElement("targetServerPath");
        node.appendChild(doc.createTextNode(targetServerPath));
        root.appendChild(node);
        
      
        return root;
    }
    
    private static String loadFile(String filePath, String encoding){
        File inputFile;
        FileInputStream is;
        String returnString = new String("");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            inputFile = new File(filePath);
            is = new FileInputStream(inputFile);
            long total =0;
            byte [] buffer = new byte[1024];
            while (true){
                int nRead = is.read(buffer,0,buffer.length);
                total += nRead;
                if (nRead <=0) break;
                bos.write(buffer,0, nRead);
            }
            is.close();
            bos.close();
            
        }catch (IOException e){
            //System.out.print ("Error Reading file: " + e + "\n");
            Debug.print ("Error Reading file: " + e + "\n");
        }catch (Exception e){
            //System.out.print ("Error Reading: " + e + "\n");
            Debug.print ("Error Reading file: " + e + "\n");
        }
        try{
            byte[] bytes = bos.toByteArray();
            if (encoding != null) returnString = new String(bytes,0, bytes.length, encoding);
            else returnString = new String(bytes);
        }catch (UnsupportedEncodingException enex){
            //Debug.println("Unable to Convert Source File");
        }
        return returnString;
    }
     private static void saveFile(ByteArrayInputStream bis, String filePath){
        
        File outputFile;
        FileOutputStream os;
        
        try {
            outputFile = new File(filePath);
            os = new FileOutputStream(outputFile);
            int c;
            while ((c = bis.read()) != -1){
                os.write(c);
            }
            os.close();
    
        }catch (IOException e){
            System.out.print ("Error Writing file: " + e + "\n");
        }catch (Exception e){
            System.out.print ("Error Writing: " + e + "\n");
        }
    }
    
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Command Line Exec Error = " + e.getMessage());
        }
        return("debug cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        //return(new String(stringBuffer));
    }
}



