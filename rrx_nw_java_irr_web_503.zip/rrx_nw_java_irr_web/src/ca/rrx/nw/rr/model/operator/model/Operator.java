package ca.rrx.nw.rr.model.operator.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import java.io.*;
import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.Constants;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class Operator implements java.io.Serializable {
    
    protected String operatorLoginName;
    protected Object operatorId;
    protected OperatorInformation operatorInformation;
    protected OperatorSessions operatorSessions; 
    protected OperatorEvents operatorEvents; 
    
    public Operator(){}
    
    
    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public String getFullName() {
        return(operatorInformation.getFirstName() + " " + operatorInformation.getLastName());
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public OperatorInformation getOperatorInformation() {
        return operatorInformation;
    }

    public  void setOperatorInformation(OperatorInformation operatorInformation) {
        this.operatorInformation = operatorInformation;
    }

    public OperatorSessions getOperatorSessions() {
        return operatorSessions;
    }

    public  void setOperatorSessions(OperatorSessions operatorSessions) {
        this.operatorSessions = operatorSessions;
    }

    public OperatorEvents getOperatorEvents() {
        return operatorEvents;
    }

    public  void setOperatorEvents(OperatorEvents operatorEvents) {
        this.operatorEvents = operatorEvents;
    }
    
        
    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        ////Debug.println("RouterInformation.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
    public String toString() {
        String ret = null;
        ret = "operatorLoginName= " + operatorLoginName + "\n";
        ret += "operatorInformation= " + operatorInformation.toString() + "\n";
        //ret += "operatorSessions= " + operatorSessions.toString() + "\n";
        //ret += "operatorEvents= " + operatorEvents.toString() + "\n";
        return ret;
        }
        
    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("operatorLoginName");
        /* if (id != null)
            root.setAttribute("Id", id);
        
        Element node = doc.createElement("operatorInformation");
        node.appendChild(doc.createNode(operatorInformation.toXml()));
        root.appendChild(node);
        
        node  = doc.createElement("operatorSessions");
        node.appendChild(doc.createNode(operatorSessions.toXml()));
        root.appendChild(node);
        
        node = doc.createElement("operatorEvents");
        node.appendChild(doc.createNode(operatorEvents.toXml()));
        root.appendChild(node);
        */
        return root;
    }
    
    
}

