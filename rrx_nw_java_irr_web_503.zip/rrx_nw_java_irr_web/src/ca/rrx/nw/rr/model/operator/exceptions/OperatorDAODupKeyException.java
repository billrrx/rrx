
package ca.rrx.nw.rr.model.operator.exceptions;

/**
 * OperatorDAODupKeyException is an exception that extends the
 * OperatorDAOAppException. This is thrown by the DAOs of the Operator
 * component when a row is already found with a given primary key
 */
public class OperatorDAODupKeyException extends OperatorDAOAppException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public OperatorDAODupKeyException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public OperatorDAODupKeyException() {
        super();
    }

}
