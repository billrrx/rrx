package ca.rrx.nw.rr.model.router.dao;

import ca.rrx.nw.rr.model.router.exceptions.RouterDAOSysException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOAppException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAODBUpdateException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOFinderException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAODupKeyException;

import ca.rrx.nw.rr.model.router.model.RouterModel;

import java.lang.reflect.InvocationTargetException;

public interface RouterDAO {

    public void create(Object daoObject) throws 
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public RouterModel load(String maintainerCode) throws   
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void store(Object daoObject) throws 
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException;
    
    public void remove(Object id) throws 
    RouterDAODBUpdateException,
    RouterDAOSysException;
    
    public Object findByPrimaryKey(Object id) throws 
    RouterDAOFinderException,
    RouterDAOSysException;
}
