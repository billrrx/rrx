package ca.rrx.nw.rr.model.operator.model;

import java.rmi.RemoteException;
import java.io.*;

import ca.rrx.nw.rr.model.operator.model.*;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;


public class OperatorModel implements java.io.Serializable {
    
    protected String operatorLoginName;
    protected OperatorInformation operatorInformation;
    protected OperatorSessions operatorSessions;
    protected Operators operators;
    protected Operators newOperators;
    
    public OperatorModel(String operatorLoginName, OperatorInformation operatorInformation,
                          OperatorSessions operatorSessions) {
        this.operatorLoginName = operatorLoginName;
        this.operatorInformation = operatorInformation;
        this.operatorSessions = operatorSessions;
        ////Debug.println("OperatorModel: = " + operatorInformation + "\n");
    }
    
    public OperatorModel(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    /**
     * Class constructor with no arguments, used by the web tier.
     */
    public OperatorModel() {}
    
    // get and set methods for the instance variables
    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public Operators getOperators() {
        return operators;
    }
    
    public void setOperators(Operators operators) {
        this.operators = operators;
    }
    
    public Operators getNewOperators() {
        return newOperators;
    }
    
    public void setNewOperators(Operators newOperators) {
        this.newOperators = newOperators;
    }
    
    //just need key and type - other from default irr - Bill R
    public String getOperatorRpslPersonObject(String serverIp, String serverPort, String nicHandle) {
        return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -T person " + nicHandle));
    }
    
    //just need key and type - other from default irr - Bill R
    public String getOperatorRpslMaintainerObject(String serverIp, String serverPort, String maintainerCode) {
        return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -r -T mntner " + maintainerCode));
    }
    
        //just need key and type - other from default irr - Bill R
    public String getOperatorRpslKeyCertObject(String serverIp, String serverPort, String maintainerCode) {
        return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -r -T key-cert " + maintainerCode));
    }
    
    //just need key and type - other from default irr - Bill R
    public String getOperatorRpslRoleObject(String serverIp, String serverPort, String nicHandle) {
       return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -T role " + nicHandle));
    }
    
    //just need key and type - other from default irr - Bill R
    public String getOperatorRpslRoleObject(String serverIp, String serverPort) {
       return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -T role " + operatorInformation.getNicHandle()));
    }

    public String getOperatorRpslRoleObject(String serverIp, String serverPort, boolean returnTemplate) {
       String results;

       results = getOperatorRpslRoleObject(serverIp, serverPort);

       if(!returnTemplate)
       {
           return (results);
       }
       else
       {
            // if results error, return template
            if(isError(results))
            {
                String template;

                template = executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -t role");
                return(template);
            }
            else
            {
                return(results);
            }
        }
    }


    private boolean isError(String testString)
    {
        RE regexpr;
        boolean matched;
        String searchPattern;
        String insideParens;
        String objectId;
        int lineCounter;

        boolean error;
        String[] lines;

        lineCounter = 0;
        lines = null;
        error = false;
        matched = false;

        lines = split(testString);


        // find the first non-empty line
        for(lineCounter = 0 ; lineCounter < lines.length ; lineCounter++)
        {
            lines[lineCounter] = lines[lineCounter].trim();

            if(lines[lineCounter].length() > 0)
            {
                break;
            }
        }

//        searchPattern       = new String("(^((" + objectSet + ")|-)+:+?)");

        // search for any number of characters followed by a semi-colon
        searchPattern       = new String(".*:");


        try
        {

            regexpr         = new RE(searchPattern);
            matched         = regexpr.match(lines[lineCounter]);

        }
        catch (RESyntaxException e)
        {
            //Debug.println("Invalid regexpr");
        }


        if (matched)
        {
            return(false);
        }
        else
        {
            return(true);
        }
    }


     //just need key and type - other from default irr - Bill R
    public String getRpslObject(String serverIp, String serverPort, String rpslKey, String rpslType) {
        return(executeCommandLine(Constants.WHOIS + serverIp + " -p " + serverPort + " -T " + rpslType + " " + rpslKey));
    }

    //placeHolder - Bill R
    public void updateRpslObject(String rpslObject) { 
        //  RIPEdb specific eg /usr/local/database/bin/update localhost 3502 bcnet-bc /usr/local/database/data/oran.rpsl
        //  updateCommandPath localhost updatePort sourceCode rpslObjectFilePath
    }

    public OperatorInformation getOperatorInformation() {
        return operatorInformation;
    }

    public  void setOperatorInformation(OperatorInformation operatorInformation) {
        this.operatorInformation = operatorInformation;
    }

    public OperatorSessions getOperatorSessions() {
        return operatorSessions;
    }

    public  void setOperatorSessions(OperatorSessions operatorSessions) {
        this.operatorSessions = operatorSessions;
    }

    public String toString() {
        String ret = null;
        ret = "operatorLoginName= " + operatorLoginName + "\n";
        ret += "operatorInformation= " + operatorInformation.toString() + "\n";
        ret += "operatorSessions= " + operatorSessions.toString() + "\n";
        return ret;
    }

    /** shallow copy */
    public void copy(OperatorModel other) {
        this.operatorLoginName = other.operatorLoginName;
        this.operatorInformation = other.operatorInformation;
        this.operatorSessions = other.operatorSessions;
    }

    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            //System.out.println("OperatorWebImpl: Command Line Exec Error = " + e.getMessage());
            //Debug.println("OperatorWebImpl: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }


    /**
     * Splits a string with lines separated by '\n' into multiple strings.
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        return((String[])temp.toArray(new String[]{}));
    }
}
