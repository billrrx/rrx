package ca.rrx.nw.rr.model.router.dao;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.router.dao.RouterDAO;
import ca.rrx.nw.rr.util.DatabaseNames;

import ca.rrx.nw.rr.model.router.model.*;

import ca.rrx.nw.rr.model.router.exceptions.*;

import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;



public class RouterDAOImpl implements RouterDAO {
    
    private transient Connection dbConnection = null;
    private transient DataSource datasource   = null;
    
    public RouterDAOImpl() throws RouterDAOSysException {
        try {
            InitialContext ic = new InitialContext();
        } catch (NamingException ne) {
            throw new RouterDAOSysException("Naming Exception while looking "
            + " up DataSource Connection " +
            JNDINames.IRR_DATASOURCE +
            ": \n" + ne.getMessage());
        }
    }
    
    public void create(Object daoObject) throws RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RouterInformation routerInformation = new RouterInformation();
        Configuration configuration = new Configuration();
        Template template = new Template();
        RpslSnap rpslSnap = new RpslSnap();
        ControlPort controlPort = new ControlPort();
        TransitPort transitPort = new TransitPort();
        ControlConnection controlConnection = new ControlConnection();
        UclpProfile uclpProfile = new UclpProfile();
        
        if (daoObject.getClass().getName() == routerInformation.getClass().getName()) {
            routerInformation = (RouterInformation) daoObject;
            //Debug.println("RouterDAOImpl: create: routerInformation = "+ routerInformation);
            insertRouterInformation(routerInformation);
        } 
        
        if (daoObject.getClass().getName() == configuration.getClass().getName()) {
            configuration = (Configuration) daoObject;
            //Debug.println("RouterDAOImpl: create: configuration = "+ configuration);
            insertConfiguration(configuration);
        }
        
        if (daoObject.getClass().getName() == template.getClass().getName()) {
            template = (Template) daoObject;
            //Debug.println("RouterDAOImpl: create: template = "+ template);
            insertTemplate(template);
        }
        if (daoObject.getClass().getName() == rpslSnap.getClass().getName()) {
            rpslSnap = (RpslSnap) daoObject;
            //Debug.println("RouterDAOImpl: create: rpslSnap = "+ rpslSnap);
            insertRpslSnap(rpslSnap);
        }
        if (daoObject.getClass().getName() == controlPort.getClass().getName()) {
            controlPort = (ControlPort) daoObject;
            //Debug.println("RouterDAOImpl: create: controlPort = "+ controlPort);
            insertControlPort(controlPort);
        } 
        if (daoObject.getClass().getName() == transitPort.getClass().getName()) {
            transitPort = (TransitPort) daoObject;
            //Debug.println("RouterDAOImpl: create: transitPort = "+ transitPort);
            insertTransitPort(transitPort);
        } 
        if (daoObject.getClass().getName() == controlConnection.getClass().getName()) {
            controlConnection = (ControlConnection) daoObject;
            //Debug.println("RouterDAOImpl: create: controlConnection = "+ controlConnection);
            insertControlConnection(controlConnection);
        } 
        if (daoObject.getClass().getName() == uclpProfile.getClass().getName()) {
            uclpProfile = (UclpProfile) daoObject;
            //Debug.println("RouterDAOImpl: create: uclpProfile = "+ uclpProfile);
            insertUclpProfile(uclpProfile);
        }
    }
    
    public RouterModel load(String maintainerCode) throws 
    RouterDAOSysException,
    RouterDAOFinderException, 
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RouterModel routerModel = new RouterModel(maintainerCode, selectRouters(maintainerCode));
        return(routerModel);
    }
    
    public void store(Object daoObject) throws RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        RouterInformation routerInformation = new RouterInformation();
        Configuration configuration = new Configuration();
        Template template = new Template();
        RpslSnap rpslSnap = new RpslSnap();
        ControlPort controlPort = new ControlPort();
        TransitPort transitPort = new TransitPort();
        ControlConnection controlConnection = new ControlConnection();
        UclpProfile uclpProfile = new UclpProfile();
        
        if (daoObject.getClass().getName() == routerInformation.getClass().getName()) {
            routerInformation = (RouterInformation) daoObject;
            //Debug.println("RouterDAOImpl: store: routerInformation = "+ routerInformation);
            updateRouterInformation(routerInformation);
        } 
        
        if (daoObject.getClass().getName() == configuration.getClass().getName()) {
            configuration = (Configuration) daoObject;
            //Debug.println("RouterDAOImpl: store: configuration = "+ configuration);
            updateConfiguration(configuration);
        }
        
        if (daoObject.getClass().getName() == template.getClass().getName()) {
            template = (Template) daoObject;
            //Debug.println("RouterDAOImpl: store: template = "+ template);
            updateTemplate(template);
        }    
        if (daoObject.getClass().getName() == rpslSnap.getClass().getName()) {
            rpslSnap = (RpslSnap) daoObject;
            //Debug.println("RouterDAOImpl: store: rpslSnap = "+ rpslSnap);
            updateRpslSnap(rpslSnap);
        }
        if (daoObject.getClass().getName() == controlPort.getClass().getName()) {
            controlPort = (ControlPort) daoObject;
            //Debug.println("RouterDAOImpl: store: controlPort = "+ controlPort);
            updateControlPort(controlPort);
        } 
        if (daoObject.getClass().getName() == transitPort.getClass().getName()) {
            transitPort = (TransitPort) daoObject;
            //Debug.println("RouterDAOImpl: store: transitPort = "+ transitPort);
            updateTransitPort(transitPort);
        } 
        if (daoObject.getClass().getName() == controlConnection.getClass().getName()) {
            controlConnection = (ControlConnection) daoObject;
            //Debug.println("RouterDAOImpl: store: controlConnection = "+ controlConnection);
            updateControlConnection(controlConnection);
        }
        if (daoObject.getClass().getName() == uclpProfile.getClass().getName()) {
            uclpProfile = (UclpProfile) daoObject;
            //Debug.println("RouterDAOImpl: store: uclpProfile = "+ uclpProfile);
            updateUclpProfile(uclpProfile);
        }

    }
    
    public void remove(Object daoObject) throws RouterDAODBUpdateException,
    RouterDAOSysException {
        
        RouterInformation routerInformation = new RouterInformation();
        Configuration configuration = new Configuration();
        Template template = new Template();
        RpslSnap rpslSnap = new RpslSnap();
        ControlPort controlPort = new ControlPort();
        TransitPort transitPort = new TransitPort();
        ControlConnection controlConnection = new ControlConnection();
        UclpProfile uclpProfile = new UclpProfile();
        
        if (daoObject.getClass().getName() == routerInformation.getClass().getName()) {
            routerInformation = (RouterInformation) daoObject;
            //Debug.println("RouterDAOImpl: remove: routerInformation = "+ routerInformation);
            deleteRouterInformation(routerInformation.getRouterProfileId());
        } 
        
        if (daoObject.getClass().getName() == configuration.getClass().getName()) {
            configuration = (Configuration) daoObject;
            //Debug.println("RouterDAOImpl: remove: configuration = "+ configuration);
            deleteConfiguration(configuration.getRouterConfigurationId());
        }
        
        if (daoObject.getClass().getName() == template.getClass().getName()) {
            template = (Template) daoObject;
            //Debug.println("RouterDAOImpl: remove: template = "+ template);
//            deleteTemplate(template);
            deleteTemplate(template.getRouterConfigurationId());
        }    
        if (daoObject.getClass().getName() == rpslSnap.getClass().getName()) {
            rpslSnap = (RpslSnap) daoObject;
            //Debug.println("RouterDAOImpl: remove: rpslSnap = "+ rpslSnap);
            deleteRpslSnap(rpslSnap);
        }
        if (daoObject.getClass().getName() == controlPort.getClass().getName()) {
            controlPort = (ControlPort) daoObject;
            //Debug.println("RouterDAOImpl: remove: controlPort = "+ controlPort);
            deleteControlPort(controlPort.getControlPortId());
        } 
        if (daoObject.getClass().getName() == transitPort.getClass().getName()) {
            transitPort = (TransitPort) daoObject;
            //Debug.println("RouterDAOImpl: remove: transitPort = "+ transitPort);
            deleteTransitPort(transitPort.getTransitPortId());
        } 
        if (daoObject.getClass().getName() == controlConnection.getClass().getName()) {
            controlConnection = (ControlConnection) daoObject;
            //Debug.println("RouterDAOImpl: remove: controlConnection = "+ controlConnection);
            deleteControlConnection(controlConnection.getControlConnectionId());
        }
        if (daoObject.getClass().getName() == uclpProfile.getClass().getName()) {
            uclpProfile = (UclpProfile) daoObject;
            //Debug.println("RouterDAOImpl: remove: uclpProfile = "+ uclpProfile);
            deleteUclpProfile(uclpProfile);
        }
        
    }
    
    public Object findByPrimaryKey(Object routerProfileID) throws
    RouterDAOFinderException,
    RouterDAOSysException {
        if (routerExists(routerProfileID))
            return (routerProfileID);
        throw new RouterDAOFinderException("primary key not found :"+routerProfileID);
    }
    
    private boolean routerExists(Object routerProfileID) throws RouterDAOSysException {
        PreparedStatement stmt = null;
        ResultSet result = null;
        boolean returnValue = false;
        String queryStr ="SELECT RouterProfileID FROM " +
        DatabaseNames.ROUTER_PROFILE_TABLE
        + " WHERE RouterProfileID = " + "'" + routerProfileID + "'";
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            if ( !result.next() ) {
                returnValue = false;
            } else {
                routerProfileID = new Integer(result.getInt(1));
                returnValue = true;
            }
        } catch(SQLException se) {
            throw new RouterDAOSysException(
            "SQLException while checking for an"
            + " existing user - id -> " + routerProfileID + " :\n" + se);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
        return returnValue;
    }
    
    private boolean isValidData(Object routerProfileID, RouterInformation info) {
        if ( (info.getMaintainerCode() == null) ||
        (info.getRouterProfileName() == null) ||
        (info.getDnsName() == null) ||
        (info.getLocalAs() == null) )
        return (false);
        else
            return (true);
    }
    

    //builds a memory set of all routers for RouterModel of maintainerCode
    private Routers selectRouters(String maintainerCode)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_PROFILE_TABLE
        + " WHERE MaintainerCode = " + "'" + maintainerCode + "'";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            Routers routers = new Routers(maintainerCode);
            
            while (resultSet.next()) {
                
                RouterInformation routerInformation = new RouterInformation();
                Router router = new Router();
                copyResultSetToProperties(routerInformation, resultSet);
                router.setRouterInformation(routerInformation);
                router.setRouterProfileId(routerInformation.getRouterProfileId());
                router.setRouterProfileName(routerInformation.getRouterProfileName());
                router.setConfigurations(selectConfigurations(routerInformation.getRouterProfileId()));
                router.setTemplates(selectTemplates(routerInformation.getRouterProfileId()));
                router.setRpslSnaps(selectRpslSnaps(routerInformation.getRouterProfileId()));
                router.setControlConnections(selectControlConnections(routerInformation.getRouterProfileId()));
                router.setControlPorts(selectControlPorts(routerInformation.getRouterProfileId()));
                router.setTransitPorts(selectTransitPorts(routerInformation.getRouterProfileId()));
                router.setUclpProfiles(selectUclpProfiles(routerInformation.getRouterProfileId()));
                routers.addRouter(router);
            }
            return(routers);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectRouters:SQLException while getting routers \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private Configurations selectConfigurations(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        String pointerType                         = "config";
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'"
        + " AND PointerType = " + "'" + pointerType + "'" ;
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            Configurations configurations = new Configurations();
            
            while (resultSet.next()) {
                
                
                Configuration configuration = new Configuration();
                copyResultSetToProperties(configuration, resultSet);
                
                configurations.addConfiguration(configuration);
                //Debug.println("RouterDAOImpl: selectConfigurations: configuration = "+ configuration);
            }
            return(configurations);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectConfigurations:SQLException while getting configurations \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private Templates selectTemplates(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        String pointerType                         = "template";
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'"
        + " AND PointerType = " + "'" + pointerType + "'" ;
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            Templates templates = new Templates();
            
            while (resultSet.next()) {
                
                
                Template template = new Template();
                copyResultSetToProperties(template, resultSet);
                
                templates.addTemplate(template);
                //Debug.println("RouterDAOImpl: selectTemplates: template = "+ template);
            }
            return(templates);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectTemplates:SQLException while getting templates \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private RpslSnaps selectRpslSnaps(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        String pointerType                         = "rpslSnap";
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'"
        + " AND PointerType = " + "'" + pointerType + "'" ;
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            RpslSnaps rpslSnaps = new RpslSnaps();
            
            while (resultSet.next()) {
                
                
                RpslSnap rpslSnap = new RpslSnap();
                copyResultSetToProperties(rpslSnap, resultSet);
                
                rpslSnaps.addRpslSnap(rpslSnap);
                //Debug.println("RouterDAOImpl: selectRpslSnaps: rpslSnap = "+ rpslSnap);
            }
            return(rpslSnaps);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectRpslSnaps:SQLException while getting rpslSnaps \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private ControlConnections selectControlConnections(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_CONNECTION_PROFILE_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            ControlConnections controlConnections = new ControlConnections();
            
            while (resultSet.next()) {
                
                
                ControlConnection controlConnection = new ControlConnection();
                copyResultSetToProperties(controlConnection, resultSet);
                controlConnections.addControlConnection(controlConnection);
                //Debug.println("RouterDAOImpl: selectControlConnections: controlConnection = "+ controlConnection);
            }
            return(controlConnections);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectControlConnections:SQLException while getting controlConnections \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    
    private ControlPorts selectControlPorts(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_CONTROL_PORT_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            ControlPorts controlPorts = new ControlPorts();
            
            while (resultSet.next()) {
                
                
                ControlPort controlPort = new ControlPort();
                copyResultSetToProperties(controlPort, resultSet);
                controlPorts.addControlPort(controlPort);
                //Debug.println("RouterDAOImpl: selectControlPorts: controlPort = "+ controlPort);
            }
            return(controlPorts);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectControlPorts:SQLException while getting controlPorts \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }    

    private TransitPorts selectTransitPorts(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_TRANSIT_PORT_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            TransitPorts transitPorts = new TransitPorts();
            
            while (resultSet.next()) {
                
                
                TransitPort transitPort = new TransitPort();
                copyResultSetToProperties(transitPort, resultSet);
                transitPorts.addTransitPort(transitPort);
                //Debug.println("RouterDAOImpl: selectTransitPorts: transitPort = "+ transitPort);
            }
            return(transitPorts);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectTransitPorts:SQLException while getting transitPorts \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }        
    
    private UclpProfiles selectUclpProfiles(Object routerProfileId)
    throws
    RouterDAOSysException,
    RouterDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {

        PreparedStatement preparedStatement        = null;
        ResultSet resultSet                        = null;
        
        
        String queryStrProfile = "SELECT * FROM " + DatabaseNames.ROUTER_UCLP_PROFILE_TABLE
        + " WHERE RouterProfileId = " + "'" + routerProfileId + "'";
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStrProfile);
            resultSet = preparedStatement.executeQuery();
            
            UclpProfiles uclpProfiles = new UclpProfiles();
            
            while (resultSet.next()) {
                
                
                UclpProfile uclpProfile = new UclpProfile();
                copyResultSetToProperties(uclpProfile, resultSet);
                uclpProfiles.addUclpProfile(uclpProfile);
                //Debug.println("RouterDAOImpl: selectUclpProfiles: uclpProfile = "+ uclpProfile);
            }
            return(uclpProfiles);
            
        } catch(SQLException ae) {
            throw new RouterDAOSysException("RouterDAOImpl.selectUclpProfiles:SQLException while getting uclpProfiles \n" + ae);
        } finally {
            closeResultSet(resultSet);
            closeStatement(preparedStatement);
            closeConnection();
        }
    }        
    
    
    private void updateRouterInformation(RouterInformation routerInformation) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
         
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_PROFILE_TABLE + " SET "
        + routerInformation.propertiesToSqlSetString(routerInformation) 
        + " WHERE RouterProfileId = " + "'" + routerInformation.getRouterProfileId() + "'";

        //Debug.println("RouterDAOImpl: updateRouterInformation: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_PROFILE_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "RouterInformation; id = " + routerInformation.getRouterProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateConfiguration(Configuration configuration) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_CONFIGURATION_TABLE + " SET "
        + configuration.propertiesToSqlSetString(configuration) 
        + " WHERE RouterConfigurationId = " + "'" + configuration.getRouterConfigurationId() + "'";

        //Debug.println("RouterDAOImpl: updateConfiguration: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_CONFIGURATION_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "Configuration; id = " + configuration.getRouterConfigurationId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateTemplate(Template template) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_CONFIGURATION_TABLE + " SET "
//        + template.propertiesToSqlSetString(template) + ","
        + template.propertiesToSqlSetString(template) 
        + " WHERE RouterConfigurationId = " + "'" + template.getRouterConfigurationId() + "'";

//        //Debug.println("RouterDAOImpl: updateTemplate: queryString = "+ queryStr);
        //System.out.println("RouterDAOImpl: updateTemplate: queryString = "+ queryStr);
        //Debug.println("RouterDAOImpl: updateTemplate: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_CONFIGURATION_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "Template; id = " + template.getRouterConfigurationId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateRpslSnap(RpslSnap rpslSnap) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_CONFIGURATION_TABLE + " SET "
        + rpslSnap.propertiesToSqlSetString(rpslSnap) + ","
        + " WHERE RouterConfigurationId = " + "'" + rpslSnap.getRouterConfigurationId() + "'";

        //Debug.println("RouterDAOImpl: updateRpslSnap: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_CONFIGURATION_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "RpslSnap; id = " + rpslSnap.getRouterConfigurationId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }

    private void updateControlPort(ControlPort controlPort) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_CONTROL_PORT_TABLE 
        + " SET "
        + controlPort.propertiesToSqlSetString(controlPort) 
        + " WHERE ControlPortId = " 
        + "'" + controlPort.getControlPortId() 
        + "'";

        //Debug.println("RouterDAOImpl: updateControlPort: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_CONTROL_PORT_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "ControlPort; id = " + controlPort.getControlPortId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }    

    private void updateControlConnection(ControlConnection controlConnection) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_CONNECTION_PROFILE_TABLE 
        + " SET "
        + controlConnection.propertiesToSqlSetString(controlConnection) 
        + " WHERE ControlConnectionId = " 
        + "'" + controlConnection.getControlConnectionId() 
        + "'";

        //Debug.println("RouterDAOImpl: updateControlConnection: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_CONNECTION_PROFILE_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "ControlConnection; id = " + controlConnection.getControlConnectionId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }    
    
    private void updateTransitPort(TransitPort transitPort) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_TRANSIT_PORT_TABLE + " SET "
        + transitPort.propertiesToSqlSetString(transitPort) 
        + " WHERE TransitPortId = " + "'" + transitPort.getTransitPortId() 
        + "'";

        //Debug.println("RouterDAOImpl: updateTransitPort: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_TRANSIT_PORT_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "TransitPort; id = " + transitPort.getTransitPortId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }    
    
    private void updateUclpProfile(UclpProfile uclpProfile) throws
    RouterDAODBUpdateException,
    RouterDAOAppException,
    RouterDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        String queryStr = "UPDATE " + DatabaseNames.ROUTER_UCLP_PROFILE_TABLE + " SET "
        + uclpProfile.propertiesToSqlSetString(uclpProfile) 
        + " WHERE UclpProfileId = " + "'" + uclpProfile.getUclpProfileId() 
        + "'";

        //Debug.println("RouterDAOImpl: updateUclpProfile: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR updating Router in ROUTER_UCLP_PROFILE_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while updating " +
            "UclpProfile; id = " + uclpProfile.getUclpProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }    
    
    private void insertRouterInformation(RouterInformation routerInformation)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_PROFILE_TABLE);
        //set this integer into the bean
        routerInformation.setRouterProfileId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_PROFILE_TABLE
        + " SET "
        + propertiesToSqlSetString(routerInformation);

        //Debug.println("RouterDAOImpl.insertRouterInformation: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertRouterInformation:ERROR in ROUTER_PROFILE_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertRouterInformation:SQLException while inserting new " +
            "RouterInformation=" + routerInformation + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void insertConfiguration(Configuration configuration)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_CONFIGURATION_TABLE);
        //set this integer into the bean
        configuration.setRouterConfigurationId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " SET "
        + propertiesToSqlSetString(configuration);

        //Debug.println("RouterDAOImpl.insertConfiguration: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertConfiguration:ERROR in ROUTER_CONFIGURATION_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertConfiguration:SQLException while inserting new " +
            "Configuration=" + configuration + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }

    private void insertTemplate(Template template)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_CONFIGURATION_TABLE);
        //set this integer into the bean
        template.setRouterConfigurationId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " SET "
        + propertiesToSqlSetString(template);

        //Debug.println("RouterDAOImpl.insertTemplate: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertTemplate:ERROR in ROUTER_CONFIGURATION_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertTemplate:SQLException while inserting new " +
            "Template=" + template + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void insertRpslSnap(RpslSnap rpslSnap)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_CONFIGURATION_TABLE);
        //set this integer into the bean
        rpslSnap.setRouterConfigurationId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " SET "
        + propertiesToSqlSetString(rpslSnap);

        //Debug.println("RouterDAOImpl.insertRpslSnap: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertRpslSnap:ERROR in ROUTER_CONFIGURATION_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertRpslSnap:SQLException while inserting new " +
            "RpslSnap=" + rpslSnap + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void insertControlPort(ControlPort controlPort)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_CONTROL_PORT_TABLE);
        //set this integer into the bean
        controlPort.setControlPortId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_CONTROL_PORT_TABLE
        + " SET "
        + propertiesToSqlSetString(controlPort);

        //Debug.println("RouterDAOImpl.insertControlPort: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertControlPort:ERROR in ROUTER_CONTROL_PORT_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertControlPort:SQLException while inserting new " +
            "ControlPort=" + controlPort + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }

    private void insertControlConnection(ControlConnection controlConnection)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_CONNECTION_PROFILE_TABLE);
        //set this integer into the bean
        controlConnection.setControlConnectionId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_CONNECTION_PROFILE_TABLE
        + " SET "
        + propertiesToSqlSetString(controlConnection);

        //Debug.println("RouterDAOImpl.insertControlConnection: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertControlPort:ERROR in ROUTER_CONNECTION_PROFILE_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertControlConnection:SQLException while inserting new " +
            "ControlPort=" + controlConnection + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void insertTransitPort(TransitPort transitPort)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_TRANSIT_PORT_TABLE);
        //set this integer into the bean
        transitPort.setTransitPortId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_TRANSIT_PORT_TABLE
        + " SET "
        + propertiesToSqlSetString(transitPort);

        //Debug.println("RouterDAOImpl.insertTransitPort: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertTransitPort:ERROR in ROUTER_TRANSIT_PORT_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertTransitPort:SQLException while inserting new " +
            "TransitPort=" + transitPort + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void insertUclpProfile(UclpProfile uclpProfile)
    throws
    RouterDAOSysException,
    RouterDAODupKeyException,
    RouterDAODBUpdateException,
    RouterDAOAppException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.ROUTER_UCLP_PROFILE_TABLE);
        //set this integer into the bean
        uclpProfile.setUclpProfileId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.ROUTER_UCLP_PROFILE_TABLE
        + " SET "
        + propertiesToSqlSetString(uclpProfile);

        //Debug.println("RouterDAOImpl.insertUclpProfile: queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            preparedStatement = createPreparedStatement(dbConnection, queryStr);
            int resultCount = preparedStatement.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new RouterDAODBUpdateException(
                "RouterDAOImpl.insertUclpProfile:ERROR in ROUTER_TRANSIT_PORT_TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new RouterDAOSysException(
            "RouterDAOImpl.insertUclpProfile:SQLException while inserting new " +
            "UclpProfile=" + uclpProfile + " :\n" + ae);
        } finally {
            closeStatement(preparedStatement);
            closeConnection();
        }
    }
    
    private void deleteRouterInformation (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_PROFILE_TABLE
        + " WHERE RouterProfileId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Router from ROUTER_PROFILE_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "Router; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteControlPort (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_CONTROL_PORT_TABLE
        + " WHERE ControlPortId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Router from ROUTER_CONTROL_PORT_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "ControlPort; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteTransitPort (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_TRANSIT_PORT_TABLE
        + " WHERE TransitPortId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Router from ROUTER_TRANSIT_PORT_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "TransitPortId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteUclpProfile (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_UCLP_PROFILE_TABLE
        + " WHERE UclpProfileId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing uclpProfile from ROUTER_UCLP_PROFILE_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "UclpProfileId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteControlConnection (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_CONNECTION_PROFILE_TABLE
        + " WHERE ControlConnectionId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Router from ROUTER_CONNECTION_PROFILE_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "ControlConnectionId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteConfiguration (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterConfigurationId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Router from ROUTER_CONFIGURATION_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "RouterConfigurationId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteTemplate (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterConfigurationId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing Template from ROUTER_CONFIGURATION_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "RouterConfigurationId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteRpslSnap (Object id) throws
    RouterDAODBUpdateException,
    RouterDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.ROUTER_CONFIGURATION_TABLE
        + " WHERE RouterConfigurationId = " + "'" + id + "'";
        PreparedStatement stmt = null;
        //Debug.println("queryString is: "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new RouterDAODBUpdateException
                ("ERROR deleteing RpslSnap from ROUTER_CONFIGURATION_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new RouterDAOSysException("SQLException while removing " +
            "RouterConfigurationId; id = " + id + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private Object getUniqueId(String tableName) throws 
    RouterDAOSysException,
    RouterDAODBUpdateException
    {
        Object nextId = null;
        getDBConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        try 
        {
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);
            
            ResultSetMetaData rmd  = resultSet.getMetaData();
            //Debug.println("RouterDAOImpl:getUniqueId: ColumnName1 = "+ rmd.getColumnName(1));
            //Debug.println("RouterDAOImpl:getUniqueId: ColumnName2 = "+ rmd.getColumnName(2));
            //Debug.println("RouterDAOImpl:getUniqueId: ColumnName3 = "+ rmd.getColumnName(3));
            
            String columnName = rmd.getColumnName(1);
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(" + columnName + ") FROM " + tableName);
            if(resultSet.next()) nextId = new Integer(resultSet.getInt(1) + 1);
            
        statement.close();    
        closeConnection();
        } 
        catch(SQLException se) 
        {
        throw new RouterDAOSysException("RouterDAOImpl.getUniqueRouterID:RouterDAOSysException=  \n" + se);
        }
        //Debug.println("RouterDAOImpl.getUniqueRouterID:tableName=" + tableName + " nextId=" + nextId);
        return(nextId);
    }
    
    private void getDBConnection() throws RouterDAOSysException {

        loadDriver();
        getConnection();
        ////Debug.println("RouterDAOImpl - inside getDBconnection = "+ datasource);

        return;
    }
    
    private void closeConnection() throws RouterDAOSysException {
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
            }
        } catch (SQLException se) {
            throw new RouterDAOSysException("SQL Exception while closing " +
            "DB connection : \n" + se);
        }
    }
    
    private void closeResultSet(ResultSet result) throws RouterDAOSysException {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException se) {
            throw new RouterDAOSysException("SQL Exception while closing " +
            "Result Set : \n" + se);
        }
    }
    
    private void closeStatement(PreparedStatement stmt) throws RouterDAOSysException {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException se) {
            throw new RouterDAOSysException("SQL Exception while closing " +
            "Statement : \n" + se);
        }
    }
    
    
    private PreparedStatement createPreparedStatement(java.sql.Connection con, String querry)
    throws SQLException {
        ArrayList targetStrings = new ArrayList();
        String processedQuerry = "";
        int startIndex = 0;
        if (startIndex != -1) {
            int index = startIndex;
            int literalStart = -1;
            while (index < querry.length()) {
                if (querry.charAt(index) == '\'') {
                    if (literalStart == -1 && index + 1 < querry.length()) {
                        literalStart = index +1;
                    } else {
                        String targetString = querry.substring(literalStart, index);
                        targetStrings.add(targetString);
                        literalStart = -1;
                        processedQuerry += "?";
                        index++;
                    }
                }
                if (index < querry.length() && literalStart == -1) {
                    processedQuerry += querry.charAt(index);
                }
                index++;
            }
            PreparedStatement stmt = con.prepareStatement(processedQuerry + " ");
            Iterator it = targetStrings.iterator();
            int counter =1;
            while (it.hasNext()) {
                String arg = (String)it.next();
                stmt.setString(counter++, arg);
            }
            return stmt;
        } else {
            PreparedStatement stmt = con.prepareStatement(querry);
            return stmt;
        }
    }
    private void loadDriver()
    {
        //see jdbc tutotials
        try {
            
            // The newInstance() call is a work around for some
            // broken Java implementations
            
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            //Debug.println("RouterDAOImpl: SQL Driver Loaded");
        }
        catch (Exception E) {
            //Debug.println("RouterDAOImpl: Unable to load mySQL JDBC2 driver.");
            E.printStackTrace();
        }
    }
    
    private void getConnection()
    {
        //see jdbc tutotials
        try {
            
            dbConnection = DriverManager.getConnection(Constants.DAO_SQL_KEY);
            //Debug.println("RouterDAOImpl: SQL Connection Processed");
        }
        catch (SQLException E) {
            //Debug.println("RouterDAOImpl: SQLException: " + E.getMessage());
            //Debug.println("RouterDAOImpl: SQLState:     " + E.getSQLState());
            //Debug.println("RouterDAOImpl: VendorError:  " + E.getErrorCode());
        }
    }
    
    //Object dest should be a bean-like object - Bill R
    private void copyResultSetToProperties(Object dest, ResultSet resultSet)
    throws 
    IllegalAccessException, 
    InvocationTargetException,
    NoSuchMethodException {
        
        if (dest == null)
            throw new IllegalArgumentException
            ("No destination bean specified");
        if (resultSet == null)
            throw new IllegalArgumentException("No origin resultSet specified");
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();
            
            for (int i = 0; i < numberOfColumns; i++) {
                String columnName = rsmd.getColumnName(i + 1);
                //note that the first char of database name is capitalized >>> convert to lowercase to match the bean property
                String propertyName = columnName.substring(0,1).toLowerCase() + columnName.substring(1);
                if (PropertyUtils.getPropertyDescriptor(dest, propertyName) != null) {
                    Object columnValue = resultSet.getObject(columnName);
                    try {
                        PropertyUtils.setSimpleProperty(dest, propertyName, columnValue);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
            
        }   catch (SQLException se) {
            throw new RouterDAOSysException("RouterDAOImpl.copyResultSetToProperties:SQL Exception while copying: \n" + se);
        }
    }
    
    private String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
            //do nothing-get rid of bean Class info-Bill R
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',"; 
            }
        }
        //chop off the last comma
        ////Debug.println("RouterDAOImpl.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString.substring(0,sqlSetString.length()-1));
    }
    
}


