
package ca.rrx.nw.rr.model.router.model;

import java.io.Serializable;
import ca.rrx.nw.rr.Constants;
/**
 * This class represents all the data needed to
 * identify an operator router.
 * This class is meant to be immutable.
 */
public class Router implements Serializable{
    
    private String routerProfileName;
    private Object routerProfileId;
    private RouterInformation routerInformation;
    private Configurations configurations;
    private Templates templates;
    private RpslSnaps rpslSnaps;
    private ControlPorts controlPorts;
    private TransitPorts transitPorts;
    private UclpProfiles uclpProfiles;
    private ControlConnections controlConnections;
    
    /**
     * Default Constructor
     */
    public Router(Object routerProfileId,RouterInformation routerInformation,Configurations configurations,
    Templates templates,RpslSnaps rpslSnaps,ControlPorts controlPorts,TransitPorts transitPorts,UclpProfiles uclpProfiles,ControlConnections controlConnections){
        
        this.routerProfileId = routerProfileId;
        this.routerInformation = routerInformation;
        this.configurations = configurations;
        this.templates = templates;
        this.rpslSnaps = rpslSnaps;
        this.controlPorts = controlPorts;
        this.transitPorts = transitPorts;
        this.uclpProfiles = uclpProfiles;
        this.controlConnections = controlConnections;
    }
    

    public Router() {}
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this. routerProfileId = routerProfileId;
    }
    
    public RouterInformation getRouterInformation() {
        return routerInformation;
    }
    
    public void setRouterInformation(RouterInformation routerInformation) {
        this. routerInformation = routerInformation;
    }
    
    public Configurations getConfigurations() {
        return configurations;
    }
    
    public void setConfigurations(Configurations configurations) {
        this. configurations = configurations;
    }
    
    public Templates getTemplates() {
        return templates;
    }
    
    public void setTemplates(Templates templates) {
        this. templates = templates;
    }
    
    public RpslSnaps getRpslSnaps() {
        return rpslSnaps;
    }
    
    public void setRpslSnaps(RpslSnaps rpslSnaps) {
        this. rpslSnaps = rpslSnaps;
    }
    
   public ControlPorts getControlPorts() {
        return controlPorts;
    }
    
    public void setControlPorts(ControlPorts controlPorts) {
        this. controlPorts = controlPorts;
    }
    
    public TransitPorts getTransitPorts() {
        return transitPorts;
    }
    
    public void setTransitPorts(TransitPorts transitPorts) {
        this. transitPorts = transitPorts;
    }
    
    public UclpProfiles getUclpProfiles() {
        return uclpProfiles;
    }
    
    public void setUclpProfiles(UclpProfiles uclpProfiles) {
        this. uclpProfiles = uclpProfiles;
    }
    
    public ControlConnections getControlConnections() {
        return controlConnections;
    }
    
    public void setControlConnections(ControlConnections controlConnections) {
        this. controlConnections = controlConnections;
    }
    
    
    public String toString(){
        return "[routerProfileId=" + routerProfileId
        + ", routerInformation=" + routerInformation
        + ", configurations=" + configurations
        + ", templates=" + templates
        + ", rpslSnaps=" + rpslSnaps
        + ", controlPorts=" + controlPorts
        + ", transitPorts=" + transitPorts
        + ", uclpProfiles=" + uclpProfiles
        + ", controlConnections=" + controlConnections
        + "]";
    }
    
}
