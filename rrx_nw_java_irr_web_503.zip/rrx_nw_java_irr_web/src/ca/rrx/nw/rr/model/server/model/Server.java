
package ca.rrx.nw.rr.model.server.model;

import java.util.List;
import java.io.Serializable;


public class Server implements Serializable{
    
    protected Object serverProfileId;
    protected String serverProfileName;
    protected String serverDnsName;
    protected String serverIpv4;
    protected String serverIpv6;
    protected String serverType;
    protected String queryPort;
    protected String updatePort;
    protected String floodPort;
    protected String mirrorPort;
    protected String authoritativeSourceCodes;
    protected String mirroredSourceCodes;
    protected String ftpServer;
    protected String ftpPath;
    protected String ftpDataFile;
    protected String ftpSerialFile;
    protected String rpslCode;
    protected String remarks;
    
   
    /**
     * Class constructor with no arguments
     */
    public Server() {}
    
  
    public Object getServerProfileId() {
        return serverProfileId;
    }
    
    public void setServerProfileId(Object serverProfileId) {
        this. serverProfileId = serverProfileId;
    }
    
    public String getServerProfileName() {
        return serverProfileName;
    }
    
    public void setServerProfileName(String serverProfileName) {
        this. serverProfileName = serverProfileName;
    }
        
    public String getServerDnsName() {
        return serverDnsName;
    }
    
    public void setServerDnsName(String serverDnsName) {
        this. serverDnsName = serverDnsName;
    }
    
    public String getServerIpv4() {
        return serverIpv4;
    }
    
    public void setServerIpv4(String serverIpv4) {
        this. serverIpv4 = serverIpv4;
    }
    
    public String getServerIpv6() {
        return serverIpv6;
    }
    
    public void setServerIpv6(String serverIpv6) {
        this. serverIpv6 = serverIpv6;
    }
    
    public String getServerType() {
        return serverType;
    }
    
    public void setServerType(String serverType) {
        this. serverType = serverType;
    }
    
    public String getQueryPort() {
        return queryPort;
    }
    
    public void setQueryPort(String queryPort) {
        this. queryPort = queryPort;
    }
    
    public String getUpdatePort() {
        return updatePort;
    }
    
    public void setUpdatePort(String updatePort) {
        this. updatePort = updatePort;
    }
    
    public String getFloodPort() {
        return floodPort;
    }
    
    public void setFloodPort(String floodPort) {
        this. floodPort = floodPort;
    }
    
    public String getMirrorPort() {
        return mirrorPort;
    }
    
    public void setMirrorPort(String mirrorPort) {
        this. mirrorPort = mirrorPort;
    }
    
    public String getAuthoritativeSourceCodes() {
        return authoritativeSourceCodes;
    }

    public void setAuthoritativeSourceCodes(String authoritativeSourceCodes) {
        this. authoritativeSourceCodes = authoritativeSourceCodes;
    }
    
    public String getMirroredSourceCodes() {
        return mirroredSourceCodes;
    }
    
    public void setMirroredSourceCodes(String mirroredSourceCodes) {
        this. mirroredSourceCodes = mirroredSourceCodes;
    }
    
    public String getFtpServer() {
        return ftpServer;
    }
    
    public void setFtpServer(String ftpServer) {
        this. ftpServer = ftpServer;
    }
    
    public String getFtpPath() {
        return ftpPath;
    }
    
    public void setFtpPath(String ftpPath) { 
        this. ftpPath = ftpPath;
    }
     
    public String getFtpDataFile() {
        return ftpDataFile;
    }
    
    public void setFtpDataFile(String ftpDataFile) {
        this. ftpDataFile = ftpDataFile;
    }
    
    public String getFtpSerialFile() {
        return ftpSerialFile;
    }
    
    public void setFtpSerialFile(String ftpSerialFile) {
        this. ftpSerialFile = ftpSerialFile;
    }
    
    public String getRpslCode() {
        return rpslCode;
    }
    
    public void setRpslCode(String rpslCode) {
        this. rpslCode = rpslCode;
    }
        
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String toString(){
        return "[serverProfileId=" + serverProfileId
        + ", serverProfileName=" + serverProfileName
        + ", serverDnsName=" + serverDnsName
        + ", serverIpv4=" + serverIpv4
        + ", serverIpv6=" + serverIpv6
        + ", serverType=" + serverType
        + ", queryPort=" + queryPort
        + ", updatePort=" + updatePort
        + ", floodPort=" + floodPort
        + ", mirrorPort=" + mirrorPort
        + ", authoritativeSourceCodes=" + authoritativeSourceCodes
        + ", mirroredSourceCodes=" + mirroredSourceCodes
        + ", ftpServer=" + ftpServer
        + ", ftpPath=" + ftpPath
        + ", ftpDataFile=" + ftpDataFile
        + ", ftpSerialFile=" + ftpSerialFile
        + ", rpslCode=" + rpslCode
        + ", remarks=" + remarks + "]";
    }
    
}    
