
package ca.rrx.nw.rr.model.rpsl.exceptions;

import java.lang.RuntimeException;

/**
 * RpslDAOSysException is an exception that extends the standard
 * RunTimeException Exception. This is thrown by the DAOs of the Rpsl
 * component when there is some irrecoverable error (like SQLException)
 */
public class RpslDAOSysException extends RuntimeException {

    /**
     * Constructor
     * @param str    a string that explains what the exception condition is
     */
    public RpslDAOSysException(String str) {
        super(str);
    }

    /**
     * Default constructor. Takes no arguments
     */
    public RpslDAOSysException() {
        super();
    }

}
