package ca.rrx.nw.rr.model.operator.model;

import org.w3c.dom.Element;
import org.w3c.dom.Document;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;


public class Address implements java.io.Serializable {

    protected String streetName1;
    protected String streetName2;
    //protected String streetName3; //reserved for later - in db already -Bill R
    protected String city;
    protected String stateProvince;
    protected String country;
    protected String postalCode;
    
    public Address (String streetName1, String streetName2,String city, 
    String stateProvince,String postalCode, String country){
                this.streetName1 = streetName1;
                this.streetName2 = streetName2;
                this.city = city;
                this.stateProvince = stateProvince;
                this.postalCode = postalCode;
                this.country = country;
    }

    public Address(){}

    public Object clone(){
        return new  Address (streetName1, streetName2, city, 
        stateProvince, postalCode,  country);
    }

    // get methods for the instance variables

    public String getStreetName1() {
        return streetName1;
    }
        
    public void setStreetName1(String streetName1){
        this.streetName1 = streetName1;
    }   
  
    public String getStreetName2() {
                // do not return a null for presentation
                if (streetName2 == null) return "";
                else return streetName2;
    }
    
    public void setStreetName2(String streetName2){
        this.streetName2 = streetName2;
    } 
/*    reserved for later - Bill R
    public String getStreetName3() {
                // do not return a null for presentation
                if (streetName3 == null) return "";
                else return streetName3;
    }
    
    public void setStreetName3(String streetName3){
        this.streetName3 = streetName3;
    } 
*/
    public String getCity() {
        return city;
    }
    
    public void setCity(String city){
        this.city = city;
    }
    
    public String getStateProvince() {
        return stateProvince;
    }
    
    public void setStateProvince(String stateProvince){
        this.stateProvince = stateProvince;
    }
   
    public String getPostalCode() {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode){
        this.postalCode = postalCode;
    }
  
    public String getCountry(){
        return country;
    }
    
    public void setCountry(String country){
        this.country = country;
    }
  
    public String toString(){
        return "[ streetName1=" + streetName1 + ", streetName2=" + streetName2 +
                ", city="  + city + ", stateProvince=" + stateProvince + ", postalCode=" + postalCode + ", country=" + country + "]";
    }

    public String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class")) {
                //do nothing-get rid of bean Class info-Bill R and nested Address object
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        sqlSetString = sqlSetString.substring(0,sqlSetString.length()-1);
        //Debug.println("OperatorAddress.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString);
    }      

    //rewrite with reflection - later - Bill R
    public Element toXml(Document doc, String id) {
        Element root = doc.createElement("Address");
        if (id != null)
            root.setAttribute("Id", id);

        Element node = doc.createElement("streetName1");
        node.appendChild(doc.createTextNode(streetName1));
        root.appendChild(node);

        node  = doc.createElement("streetName2");
        node.appendChild(doc.createTextNode(streetName2));
        root.appendChild(node);

        node = doc.createElement("city");
        node.appendChild(doc.createTextNode(city));
        root.appendChild(node);

        node = doc.createElement("stateProvince");
        node.appendChild(doc.createTextNode(stateProvince));
        root.appendChild(node);

        node = doc.createElement("postalCode");
        node.appendChild(doc.createTextNode(postalCode));
        root.appendChild(node);
        
        node = doc.createElement("country");
        node.appendChild(doc.createTextNode(country));
        root.appendChild(node);

        return root;
    }

}
