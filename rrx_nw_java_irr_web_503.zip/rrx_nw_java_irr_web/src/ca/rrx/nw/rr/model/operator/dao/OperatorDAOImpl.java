
package ca.rrx.nw.rr.model.operator.dao;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import ca.rrx.nw.rr.util.JNDINames;
import ca.rrx.nw.rr.model.operator.dao.OperatorDAO;
import ca.rrx.nw.rr.util.DatabaseNames;

import ca.rrx.nw.rr.model.operator.model.*;

import ca.rrx.nw.rr.model.operator.exceptions.*;

import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.util.Debug;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public class OperatorDAOImpl implements OperatorDAO {
    
    private transient Connection dbConnection = null;
    private transient DataSource datasource   = null;
    
    public OperatorDAOImpl() throws OperatorDAOSysException {
        try {
            InitialContext ic = new InitialContext();
            ////Debug.println("OperatorDAOImpl - before datasource = "+ ic);
        } catch (NamingException ne) {
            throw new OperatorDAOSysException("Naming Exception while looking "
            + " up DataSource Connection: \n" + ne.getMessage());
        }
    }
    
    
    public void create(Object daoObject) throws 
           OperatorDAOSysException,
           OperatorDAODupKeyException,
           OperatorDAODBUpdateException,
           OperatorDAOAppException,
           IllegalAccessException,
           InvocationTargetException,
           NoSuchMethodException
    {
        
        OperatorInformation operatorInformation = new OperatorInformation();
        OperatorSession operatorSession = new OperatorSession();
        OperatorEvent operatorEvent = new OperatorEvent();
        
        if (daoObject.getClass().getName() == operatorInformation.getClass().getName()) 
        {
            operatorInformation = (OperatorInformation) daoObject;
            if (operatorInformation.getOperatorId().equals("Approved"))
            {
            	//Debug.println("OperatorDAOImpl: store: Approved OperatorInformation = "+ operatorInformation);
            	insertOperator(operatorInformation);
            }
            else
            {
            	//Debug.println("OperatorDAOImpl: store: New operatorInformation = "+ operatorInformation);
            	insertOperatorNew(operatorInformation);
            }   	
        } 
        
        if (daoObject.getClass().getName() == operatorSession.getClass().getName()) {
            operatorSession = (OperatorSession) daoObject;
            //Debug.println("OperatorDAOImpl: store: operatorSession = "+ operatorSession);
            insertOperatorSession(operatorSession);
        }
        
        if (daoObject.getClass().getName() == operatorEvent.getClass().getName()) {
            operatorEvent = (OperatorEvent) daoObject;
            //Debug.println("OperatorDAOImpl: store: operatorEvent = "+ operatorEvent);
            insertOperatorEvent(operatorEvent);
        }
     

    }
    
    public OperatorModel load(String operatorLoginName) throws OperatorDAOSysException,
    OperatorDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        return(selectOperator(operatorLoginName));
    }
    
    public void store(Object daoObject) throws OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        OperatorInformation operatorInformation = new OperatorInformation();
        OperatorSession operatorSession = new OperatorSession();
        
      
         if (daoObject.getClass().getName() == operatorInformation.getClass().getName()) 
        {
            operatorInformation = (OperatorInformation) daoObject;
            if (operatorInformation.getOperatorId().equals("Approved"))
            {
            	//Debug.println("OperatorDAOImpl: store: Approved OperatorInformation = "+ operatorInformation);
            	updateOperatorInformationNew(operatorInformation);
            }
            else
            {
            	//Debug.println("OperatorDAOImpl: store: New operatorInformation = "+ operatorInformation);
            	updateOperatorInformation(operatorInformation);
            }   	
        } 
        
        if (daoObject.getClass().getName() == operatorSession.getClass().getName()) {
            operatorSession = (OperatorSession) daoObject;
            //Debug.println("OperatorDAOImpl: store: operatorSession = "+ operatorSession);
            updateOperatorSession(operatorSession);
        }
    }
    
    public void remove(Object daoObject) throws OperatorDAODBUpdateException,
    OperatorDAOSysException {
        OperatorInformation operatorInformation = new OperatorInformation();
        OperatorSession operatorSession = new OperatorSession();
        OperatorEvent operatorEvent = new OperatorEvent();
        

         if (daoObject.getClass().getName() == operatorInformation.getClass().getName()) 
        {
            operatorInformation = (OperatorInformation) daoObject;
            if (operatorInformation.getOperatorId().equals("Approved"))
            {
            	//Debug.println("OperatorDAOImpl: store: Approved OperatorInformation = "+ operatorInformation);
            	deleteOperatorInformationNew(operatorInformation);
            }
            else
            {
            	//Debug.println("OperatorDAOImpl: store: New operatorInformation = "+ operatorInformation);
            	deleteOperatorInformation(operatorInformation);
            }   	
        } 
        
        if (daoObject.getClass().getName() == operatorSession.getClass().getName()) {
            operatorSession = (OperatorSession) daoObject;
            //Debug.println("OperatorDAOImpl: remove: operatorSession = "+ operatorSession);
            deleteOperatorSession(operatorSession);
        }
        
        if (daoObject.getClass().getName() == operatorEvent.getClass().getName()) {
            operatorEvent = (OperatorEvent) daoObject;
            //Debug.println("OperatorDAOImpl: remove: operatorEvent = "+ operatorEvent);
            deleteOperatorEvent(operatorEvent);
        }
        
    }
    
    public String findByPrimaryKey(String OperatorLoginName) throws
    OperatorDAOFinderException,
    OperatorDAOSysException {
        if (userExists(OperatorLoginName))
            return (OperatorLoginName);
        throw new OperatorDAOFinderException("primary key not found :"+OperatorLoginName);
    }
    
    private boolean userExists (String OperatorLoginName) throws OperatorDAOSysException {
        PreparedStatement stmt = null;
        ResultSet result = null;
        boolean returnValue = false;
        String queryStr ="SELECT OperatorLoginName FROM " +
        DatabaseNames.OPERATOR_PROFILE_TABLE
        + " WHERE OperatorLoginName = " + "'" + OperatorLoginName.trim() + "'";
        
       //Debug.println("OperatorDAOImpl: userExists: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            if ( !result.next() ) {
                returnValue = false;
            } else {
                OperatorLoginName = result.getString(1);
                returnValue = true;
            }
        } catch(SQLException se) {
            throw new OperatorDAOSysException(
            "SQLException while checking for an"
            + " existing user - id -> " + OperatorLoginName + " :\n" + se);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
        return returnValue;
    }
    
    

    
    private OperatorModel selectOperator(String operatorLoginName) throws
    OperatorDAOSysException,
    OperatorDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        PreparedStatement stmtOperator = null;
        ResultSet resultOperator = null;
        
        PreparedStatement stmtSessions = null;
        ResultSet resultSessions = null;
        
        //Debug.println("OperatorDAOImpl: selectOperator: operatorLoginName = "+ operatorLoginName);
        
        String queryOperator = "SELECT * "
        + " FROM " + DatabaseNames.OPERATOR_PROFILE_TABLE
        + " WHERE OperatorLoginName = " + "'" + operatorLoginName.trim() + "'";
        
        //Debug.println("OperatorDAOImpl: selectOperator: queryOperator = "+ queryOperator);
        
        
        try {
            getDBConnection();
            Debug.println("OperatorDAOImpl: selectOperator: after getDBConnection() dbConnection = "+ dbConnection);
            stmtOperator = createPreparedStatement(dbConnection, queryOperator);
            resultOperator = stmtOperator.executeQuery();
            
            if ( !resultOperator.next() )
                throw new OperatorDAOFinderException(
                "No record for primary key " + operatorLoginName);
            
            //Debug.println("OperatorDAOImpl: selectOperator: resultOperator = "+ resultOperator);
            
          
            
            OperatorInformation operatorInformation = new OperatorInformation();
            copyResultSetToProperties(operatorInformation, resultOperator);
            ////Debug.println("OperatorDAOImpl: selectOperator: operatorInformation = "+ operatorInformation);
            
            Address address = new Address();
            copyResultSetToProperties(address, resultOperator);
            ////Debug.println("OperatorDAOImpl: selectOperator: address = "+ address);
            
            operatorInformation.setAddress(address);
            
            Object operatorId = operatorInformation.getOperatorId();
            
            String querySessions = "SELECT * "
            + " FROM " + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE
            + " WHERE OperatorID = " + "'" + operatorId + "'";
            
            ////Debug.println("OperatorDAOImpl: selectOperator: querySessions = "+ querySessions);
            
            stmtSessions = createPreparedStatement(dbConnection, querySessions);
            resultSessions = stmtSessions.executeQuery();
            
            ////Debug.println("OperatorDAOImpl: selectOperator: resultSessions = "+ resultSessions);
            
            OperatorSessions operatorSessions = new OperatorSessions(operatorId);
            
            while (resultSessions.next()) {
                
                
                OperatorSession operatorSession = new OperatorSession();
                copyResultSetToProperties(operatorSession, resultSessions);
                ////Debug.println("OperatorDAOImpl: selectOperator: operatorSession = "+ operatorSession);
                operatorSessions.addOperatorSession(operatorSession);
                
            }
            
            OperatorModel operatorModel = new OperatorModel(operatorLoginName, operatorInformation, operatorSessions);
            
            //this is for admins >>> populates the operators object for admin jsps
            
            if (operatorInformation.getRole().equalsIgnoreCase(Constants.ADMINISTRATOR_ROLE_VALUE)) {
                operatorModel.setOperators(selectOperators());
                operatorModel.setNewOperators(selectNewOperators());
            }
            
            return(operatorModel);
            
        } catch(SQLException ae) {
            throw new OperatorDAOSysException("SQLException while getting " +
            "Operator; id = " + operatorLoginName + " :\n" + ae);
        } finally {
            closeResultSet(resultOperator);
            closeStatement(stmtOperator);
            closeResultSet(resultSessions);
            closeStatement(stmtSessions);
            closeConnection();
        }
    }
    
    private Operators selectOperators() throws
    OperatorDAOSysException,
    OperatorDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        PreparedStatement stmtOperators = null;
        ResultSet resultOperators = null;
        
        PreparedStatement stmtSessions = null;
        ResultSet resultSessions = null;
        
        PreparedStatement stmtEvents = null;
        ResultSet resultEvents = null;
        
      
        String queryOperators = "SELECT * "
        + " FROM " + DatabaseNames.OPERATOR_PROFILE_TABLE;
        
        //Debug.println("OperatorDAOImpl: selectOperators: queryOperator = "+ queryOperators);
        
        
        try {
            getDBConnection();
            
            stmtOperators = createPreparedStatement(dbConnection, queryOperators);
            resultOperators = stmtOperators.executeQuery();
            
            if ( !resultOperators.next() )
                throw new OperatorDAOFinderException(
                "OperatorDAOImpl: selectOperators: No records for resultOperators");
            
           // //Debug.println("OperatorDAOImpl: selectOperators: resultOperators = "+ resultOperators);
            
            Operators operators = new Operators();
            
            while (resultOperators.next()) {
            
            Operator operator = new Operator();
                
            OperatorInformation operatorInformation = new OperatorInformation();
            copyResultSetToProperties(operatorInformation, resultOperators);
            ////Debug.println("OperatorDAOImpl: selectOperators: operatorInformation = "+ operatorInformation);
            
            Address address = new Address();
            copyResultSetToProperties(address, resultOperators);
            ////Debug.println("OperatorDAOImpl: selectOperators: address = "+ address);
            
            operatorInformation.setAddress(address);
            
            operator.setOperatorLoginName(operatorInformation.getOperatorLoginName());
            operator.setOperatorId(operatorInformation.getOperatorId());
            operator.setOperatorInformation(operatorInformation);
            
            Object operatorId = operatorInformation.getOperatorId();
            
            //---sessions----
            
            String querySessions = "SELECT * "
            + " FROM " + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE
            + " WHERE OperatorID = " + "'" + operatorId + "'";
            
            ////Debug.println("OperatorDAOImpl: selectOperators: querySessions = "+ querySessions);
            
            stmtSessions = createPreparedStatement(dbConnection, querySessions);
            resultSessions = stmtSessions.executeQuery();
            
            ////Debug.println("OperatorDAOImpl: selectOperators: resultSessions = "+ resultSessions);
            
            OperatorSessions operatorSessions = new OperatorSessions(operatorId);
            
            while (resultSessions.next()) {
                
                
                OperatorSession operatorSession = new OperatorSession();
                copyResultSetToProperties(operatorSession, resultSessions);
                ////Debug.println("OperatorDAOImpl: selectOperator: operatorSession = "+ operatorSession);
                operatorSessions.addOperatorSession(operatorSession);
                
            }
            
            operator.setOperatorSessions(operatorSessions);
            
            //---events----
            
            String queryEvents = "SELECT * "
            + " FROM " + DatabaseNames.OPERATOR_SESSION_LOG_TABLE
            + " WHERE OperatorID = " + "'" + operatorId + "'";
            
            ////Debug.println("OperatorDAOImpl: selectOperators: queryEvents = "+ queryEvents);
            
            stmtEvents = createPreparedStatement(dbConnection, queryEvents);
            resultEvents = stmtEvents.executeQuery();
            
            ////Debug.println("OperatorDAOImpl: selectOperators: resultEvents = "+ resultEvents);
            
            OperatorEvents operatorEvents = new OperatorEvents();
            
            while (resultEvents.next()) {
                
                
                OperatorEvent operatorEvent = new OperatorEvent();
                copyResultSetToProperties(operatorEvent, resultEvents);
                ////Debug.println("OperatorDAOImpl: selectOperators: operatorEvent = "+ operatorEvent);
                operatorEvents.addOperatorEvent(operatorEvent);
                
            }
            
            operator.setOperatorEvents(operatorEvents);
            
            //-------
          
            if (operatorInformation.getRole().equalsIgnoreCase(Constants.ADMINISTRATOR_ROLE_VALUE)) 
            {
                operators.addAdministrator(operator);
                operators.addOperator(operator);
                //Debug.println("OperatorDAOImpl: selectOperators: addAdministrator = "+ operator.getOperatorLoginName());
            } 
            else
            {             
                operators.addOperator(operator);
                ////Debug.println("OperatorDAOImpl: selectOperators: addOperator = "+ operator.getOperatorLoginName());
            }
            
          }
            return(operators);
            
        } catch(SQLException ae) {
            throw new OperatorDAOSysException("SQLException while getting " +
            "Operators " + " :\n" + ae);
        } finally {
            closeResultSet(resultOperators);
            closeStatement(stmtOperators);
            closeResultSet(resultSessions);
            closeStatement(stmtSessions);
            closeConnection();
        }
    }
    
    private Operators selectNewOperators() throws
    OperatorDAOSysException,
    OperatorDAOFinderException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
        PreparedStatement stmtNewOperators = null;
        ResultSet resultNewOperators = null;
        
        Operators newOperators = new Operators();
      
        String queryNewOperators = "SELECT * "
        + " FROM " + DatabaseNames.OPERATOR_PROFILE_NEW_TABLE;
        
        //Debug.println("OperatorDAOImpl: selectNewOperators: queryNewOperators = "+ queryNewOperators);
        
        
        try {
            getDBConnection();
            
            stmtNewOperators = createPreparedStatement(dbConnection, queryNewOperators);
            resultNewOperators = stmtNewOperators.executeQuery();
            
            if ( !resultNewOperators.next() )
                return(newOperators = null);
            
            //Debug.println("OperatorDAOImpl: selectNewOperators: resultNewOperators = "+ resultNewOperators);
            
            
            
            while (resultNewOperators.next()) {
            
            Operator newOperator = new Operator();
                
            OperatorInformation operatorInformation = new OperatorInformation();
            copyResultSetToProperties(operatorInformation, resultNewOperators);
            //Debug.println("OperatorDAOImpl: selectNewOperators: operatorInformation = "+ operatorInformation);
            
            Address address = new Address();
            copyResultSetToProperties(address, resultNewOperators);
            //Debug.println("OperatorDAOImpl: selectNewOperators: address = "+ address);
            
            operatorInformation.setAddress(address);

            newOperator.setOperatorInformation(operatorInformation);
            newOperator.setOperatorLoginName(operatorInformation.getOperatorLoginName());
            newOperators.addOperator(newOperator);

          }
            return(newOperators);
            
        } catch(SQLException ae) {
            throw new OperatorDAOSysException("SQLException while getting " +
            "NewOperators " + " :\n" + ae);
        } finally {
            closeResultSet(resultNewOperators);
            closeStatement(stmtNewOperators);
            closeConnection();
        }
    }
    
    private void deleteOperatorInformation (OperatorInformation operatorInformation) throws
    OperatorDAODBUpdateException,
    OperatorDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.OPERATOR_PROFILE_TABLE
        + " WHERE OperatorLoginName = " + "'" + operatorInformation.getOperatorLoginName().trim() + "'";
        PreparedStatement stmt = null;
        
        //Debug.println("OperatorDAOImpl: deleteOperatorInformation: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR deleteing Operator from OPERATOR_PROFILE_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while removing " +
            "Operator; id = " + operatorInformation.getOperatorLoginName() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }

    private void deleteOperatorInformationNew (OperatorInformation operatorInformation) throws
    OperatorDAODBUpdateException,
    OperatorDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.OPERATOR_PROFILE_NEW_TABLE
        + " WHERE OperatorLoginName = " + "'" + operatorInformation.getOperatorLoginName().trim() + "'";
        PreparedStatement stmt = null;
        
        //Debug.println("OperatorDAOImpl: deleteOperatorInformation: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR deleteing Operator from OPERATOR_PROFILE_NEW_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while removing " +
            "Operator; id = " + operatorInformation.getOperatorLoginName() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteOperatorSession (OperatorSession operatorSession) throws
    OperatorDAODBUpdateException,
    OperatorDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE
        + " WHERE SessionProfileId = " + "'" + operatorSession.getSessionProfileId() + "'";
        PreparedStatement stmt = null;
        
        //Debug.println("OperatorDAOImpl: deleteOperatorSession: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR deleteing OperatorSession from OPERATOR_SESSION_PROFILE_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while removing " +
            "OperatorSession; id = " + operatorSession.getSessionProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void deleteOperatorEvent (OperatorEvent operatorEvent) throws
    OperatorDAODBUpdateException,
    OperatorDAOSysException {
        String queryStr = "DELETE FROM " + DatabaseNames.OPERATOR_SESSION_LOG_TABLE
        + " WHERE OperatorEventId = " + "'" + operatorEvent.getOperatorEventId() + "'";
        PreparedStatement stmt = null;
        
        //Debug.println("OperatorDAOImpl: deleteOperatorEvent: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR deleteing OperatorEvent from OPERATOR_SESSION_LOG_TABLE!! resultCount = "+
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while removing " +
            "OperatorEvent; id = " + operatorEvent.getOperatorEventId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateOperatorInformation(OperatorInformation operatorInformation) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        Address address = operatorInformation.getAddress();
        
        String queryStr = "UPDATE " + DatabaseNames.OPERATOR_PROFILE_TABLE + " SET "
        + operatorInformation.propertiesToSqlSetString(operatorInformation) + ","
        + address.propertiesToSqlSetString(address)
        + " WHERE OperatorLoginName = " + "'" + operatorInformation.getOperatorLoginName().trim() + "'";

        //Debug.println("OperatorDAOImpl: updateOperatorInformation: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR updating Operator in OPERATOR_PROFILE_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while updating " +
            "OperatorInformation; id = " + operatorInformation.getOperatorLoginName() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateOperatorInformationNew(OperatorInformation operatorInformation) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        Address address = operatorInformation.getAddress();
        
        String queryStr = "UPDATE " + DatabaseNames.OPERATOR_PROFILE_NEW_TABLE + " SET "
        + operatorInformation.propertiesToSqlSetString(operatorInformation) + ","
        + address.propertiesToSqlSetString(address)
        + " WHERE OperatorLoginName = " + "'" + operatorInformation.getOperatorLoginName().trim() + "'";

        //Debug.println("OperatorDAOImpl: updateOperatorInformation: queryString = "+ queryStr);
        
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR updating Operator in OPERATOR_PROFILE_NEW_TABLE!! resultCount = " +
                resultCount);
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while updating " +
            "OperatorInformation; id = " + operatorInformation.getOperatorLoginName() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private void updateOperatorSession(OperatorSession operatorSession) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        
         
        String queryStr = "UPDATE " + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE + " SET "
        + operatorSession.propertiesToSqlSetString(operatorSession)
        + " WHERE SessionProfileId = " + "'" + operatorSession.getSessionProfileId() + "'";
        
       //Debug.println("OperatorDAOImpl: updateOperatorSession: queryString = "+ queryStr);
 
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR updating OperatorSession in OPERATOR_SESSION_PROFILE_TABLE!! resultCount = " +
                resultCount);
        
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while updating " +
            "OperatorSession; id = " + operatorSession.getSessionProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
     /*------------------------------------------------------------------------------   
     *  Approved New Operator - to OPERATOR_PROFILE Table -   
     *-----------------------------------------------------------------------------*/ 
    
    private void insertOperator(OperatorInformation operatorInformation) throws
            OperatorDAOSysException,
            OperatorDAODupKeyException,
            OperatorDAODBUpdateException,
            OperatorDAOAppException,
            IllegalAccessException,
            InvocationTargetException,
            NoSuchMethodException
    {
        
        //Debug.println("OperatorDAOImpl: insertOperator Approved:  = "+ operatorInformation.getOperatorLoginName());
        
        if (userExists(operatorInformation.getOperatorLoginName()))
            throw new OperatorDAODupKeyException("There is already user registered with username = "+
            operatorInformation.getOperatorLoginName());
       
    
        Address address = operatorInformation.getAddress();
        
        //get the next integer for the column 2 key
        Object uniqueId = getUniqueOperatorId(DatabaseNames.OPERATOR_PROFILE_TABLE);
        //set this integer into the bean
        operatorInformation.setOperatorId(uniqueId);
        //create the default operator session
        OperatorSession defaultOperatorSession = new OperatorSession();
        //set the session parameters
        defaultOperatorSession.setMaintainerCode(operatorInformation.getMaintainerCodes());
        defaultOperatorSession.setNicHandle(operatorInformation.getNicHandle());
        defaultOperatorSession.setOperatorId(operatorInformation.getOperatorId());
        defaultOperatorSession.setPrimaryServerProfileId(Constants.DEFAULT_PRIMARY_IRR_ID);
        defaultOperatorSession.setSecondaryServerProfileId(Constants.DEFAULT_PRIMARY_IRR_ID);
        defaultOperatorSession.setSessionProfileName(operatorInformation.getMaintainerCodes() + "-" + operatorInformation.getOperatorLoginName());
        defaultOperatorSession.setRelativeConfigPath("default");
        defaultOperatorSession.setRemarks("autogenerated default session");
        //save default session
        Object defaultSessionId = insertDefaultOperatorSession(defaultOperatorSession);
        //set the link 
        operatorInformation.setDefaultSessionId(defaultSessionId);
        
        PreparedStatement stmt = null;
        String queryStr = "INSERT INTO " + DatabaseNames.OPERATOR_PROFILE_TABLE 
        + " SET "
        + operatorInformation.propertiesToSqlSetString(operatorInformation) + ","
        + address.propertiesToSqlSetString(address);
        
        //Debug.println("OperatorDAOImpl: insertOperator APPROVED: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new OperatorDAODBUpdateException(
                "ERROR in OPERATOR_PROFILE TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new OperatorDAOSysException(
            "SQLException while inserting new : insertOperatorApproved " +
            "Operator; id = " + operatorInformation.getOperatorLoginName() + " :\n" + ae);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    
    private void insertOperatorSession(OperatorSession operatorSession) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE);
        //set this integer into the bean
        operatorSession.setSessionProfileId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE
        + " SET "
        + operatorSession.propertiesToSqlSetString(operatorSession);

        //Debug.println("OperatorDAOImpl.insertOperatorSession: queryString is: "+ queryStr);
         
     
 
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR inserting OperatorSession in OPERATOR_SESSION_PROFILE_TABLE!! resultCount = " +
                resultCount);
        
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while inserting " +
            "OperatorSession; id = " + operatorSession.getSessionProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    private Object insertDefaultOperatorSession(OperatorSession operatorSession) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE);
        //set this integer into the bean
        operatorSession.setSessionProfileId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.OPERATOR_SESSION_PROFILE_TABLE
        + " SET "
        + operatorSession.propertiesToSqlSetString(operatorSession);

        //Debug.println("OperatorDAOImpl.insertOperatorSession: queryString is: "+ queryStr);
         
     
 
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR inserting OperatorSession in OPERATOR_SESSION_PROFILE_TABLE!! resultCount = " +
                resultCount);
        
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while inserting " +
            "OperatorSession; id = " + operatorSession.getSessionProfileId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
        return(uniqueId);
    }    
    
    private void insertOperatorEvent(OperatorEvent operatorEvent) throws
    OperatorDAODBUpdateException,
    OperatorDAOAppException,
    OperatorDAOSysException,
    IllegalAccessException,
    InvocationTargetException,
    NoSuchMethodException
    {
        //get the next integer for the column 1 key
        Object uniqueId = getUniqueId(DatabaseNames.OPERATOR_SESSION_LOG_TABLE);
        //set this integer into the bean
        operatorEvent.setOperatorEventId(uniqueId);
        //init the preparedStatement
        PreparedStatement preparedStatement = null;
        //formulate the queryStr
        String queryStr = "INSERT INTO "
        + DatabaseNames.OPERATOR_SESSION_LOG_TABLE
        + " SET "
        + operatorEvent.propertiesToSqlSetString(operatorEvent);

        //Debug.println("OperatorDAOImpl.insertOperatorEvent: queryString = "+ queryStr);
        //note uniqueId is coming up null but works ok as sql seems to gen the numbers somehow
        //Debug.println("OperatorDAOImpl.insertOperatorEvent: operatorEvent = "+ operatorEvent);
 
        PreparedStatement stmt = null;
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            if (resultCount != 1)
                throw new OperatorDAODBUpdateException
                ("ERROR inserting operatorEvent in OPERATOR_SESSION_LOG_TABLE!! resultCount = " +
                resultCount);
        
        } catch(SQLException se) {
            throw new OperatorDAOSysException("SQLException while inserting " +
            "operatorEvent; id = " + operatorEvent.getOperatorEventId() + " :\n" + se);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    /*------------------------------------------------------------------------------   
     *  Add New Operator - to OPERATOR_PROFILE_NEW Table -  
     *-----------------------------------------------------------------------------*/ 
    
    private void insertOperatorNew(OperatorInformation operatorInformation) throws
            OperatorDAOSysException,
            OperatorDAODupKeyException,
            OperatorDAODBUpdateException,
            OperatorDAOAppException,
            IllegalAccessException,
            InvocationTargetException,
            NoSuchMethodException
    {
        
        //Debug.println("OperatorDAOImpl: insertOperatorNew:  = "+ operatorInformation.getOperatorLoginName());
        
        if (userNewExists(operatorInformation.getOperatorLoginName()))
            throw new OperatorDAODupKeyException("There is already user registered with username = "+
            operatorInformation.getOperatorLoginName());
       
    
        Address address = operatorInformation.getAddress();
        
        PreparedStatement stmt = null;
        String queryStr = "INSERT INTO " + DatabaseNames.OPERATOR_PROFILE_NEW_TABLE 
        + " SET "
        + operatorInformation.propertiesToSqlSetString(operatorInformation) + ","
        + address.propertiesToSqlSetString(address);
        
        //Debug.println("OperatorDAOImpl: insertOperatorNew: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            int resultCount = stmt.executeUpdate();
            
            if ( resultCount != 1 ) {
                throw new OperatorDAODBUpdateException(
                "ERROR in OPERATOR_PROFILE_NEW TABLE INSERT !! resultCount = " +
                resultCount);
            }
        } catch(SQLException ae) {
            throw new OperatorDAOSysException(
            "SQLException while inserting new : insertOperatorNew " +
            "Operator; id = " + operatorInformation.getOperatorLoginName() + " :\n" + ae);
        } finally {
            closeStatement(stmt);
            closeConnection();
        }
    }
    
    /*----------------------------------------------------------------------------------------------------   
     *  Check if User with same name already exists - OPERATOR_PROFILE_NEW Table   
     *----------------------------------------------------------------------------------------------------*/ 
    
    private boolean userNewExists (String OperatorLoginName) throws 
            OperatorDAOSysException 
    {
        PreparedStatement stmt = null;
        ResultSet result = null;
        boolean returnValue = false;
        String queryStr ="SELECT OperatorLoginName FROM " +
        DatabaseNames.OPERATOR_PROFILE_NEW_TABLE
        + " WHERE OperatorLoginName = " + "'" + OperatorLoginName.trim() + "'";
        
       //Debug.println("OperatorDAOImpl: userNewExists: queryString = "+ queryStr);
        
        try {
            getDBConnection();
            stmt = createPreparedStatement(dbConnection, queryStr);
            result = stmt.executeQuery();
            if ( !result.next() ) {
                returnValue = false;
            } else {
                OperatorLoginName = result.getString(1);
                returnValue = true;
            }
        } catch(SQLException se) {
            throw new OperatorDAOSysException(
            "OperatorDAOImpl: userNewExists: SQLException while checking for an"
            + " existing user - id -> " + OperatorLoginName + " :\n" + se);
        } finally {
            closeResultSet(result);
            closeStatement(stmt);
            closeConnection();
        }
        return returnValue;
    }
    
    private Object getUniqueId(String tableName) throws 
    OperatorDAOSysException,
    OperatorDAODBUpdateException
    {
        Object nextId = null;
        getDBConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        try 
        {
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);
            
            ResultSetMetaData rmd  = resultSet.getMetaData();
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName1 = "+ rmd.getColumnName(1));
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName2 = "+ rmd.getColumnName(2));
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName3 = "+ rmd.getColumnName(3));
            
            String columnName = rmd.getColumnName(1);
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(" + columnName + ") FROM " + tableName);
            if(resultSet.next()) nextId = new Integer(resultSet.getInt(1) + 1);
            
        statement.close();    
        closeConnection();
        } 
        catch(SQLException se) 
        {
        throw new OperatorDAOSysException("OperatorDAOImpl.getUniqueRouterID:OperatorDAOSysException=  \n" + se);
        }
        //Debug.println("OperatorDAOImpl.getUniqueId:tableName=" + tableName + " nextId=" + nextId);
        return(nextId);
    }
    
    private Object getUniqueOperatorId(String tableName) throws 
    OperatorDAOSysException,
    OperatorDAODBUpdateException
    {
        Object nextId = null;
        getDBConnection();
        Statement statement = null;
        ResultSet resultSet = null;
        try 
        {
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);
            
            ResultSetMetaData rmd  = resultSet.getMetaData();
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName1 = "+ rmd.getColumnName(1));
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName2 = "+ rmd.getColumnName(2));
            //Debug.println("OperatorDAOImpl:getUniqueId: ColumnName3 = "+ rmd.getColumnName(3));
            
            String columnName = rmd.getColumnName(2);
            statement = dbConnection.createStatement();
            resultSet = statement.executeQuery("SELECT MAX(" + columnName + ") FROM " + tableName);
            if(resultSet.next()) nextId = new Integer(resultSet.getInt(1) + 1);
            
        statement.close();    
        closeConnection();
        } 
        catch(SQLException se) 
        {
        throw new OperatorDAOSysException("OperatorDAOImpl.getUniqueRouterID:OperatorDAOSysException=  \n" + se);
        }
        //Debug.println("OperatorDAOImpl.getUniqueId:tableName=" + tableName + " nextId=" + nextId);
        return(nextId);
    }    
    
    private void getDBConnection() throws OperatorDAOSysException {

        loadDriver();
        getConnection();

        return;
    }
    
    private void closeConnection() throws OperatorDAOSysException {
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
            }
        } catch (SQLException se) {
            throw new OperatorDAOSysException("SQL Exception while closing " +
            "DB connection : \n" + se);
        }
    }
    
    private void closeResultSet(ResultSet result) throws OperatorDAOSysException {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException se) {
            throw new OperatorDAOSysException("SQL Exception while closing " +
            "Result Set : \n" + se);
        }
    }
    
    private void closeStatement(PreparedStatement stmt) throws OperatorDAOSysException {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException se) {
            throw new OperatorDAOSysException("SQL Exception while closing " +
            "Statement : \n" + se);
        }
    }
    
    
    private PreparedStatement createPreparedStatement(Connection con, String querry)
    throws SQLException {
        ArrayList targetStrings = new ArrayList();
        String processedQuerry = "";
        int startIndex = 0;
        if (startIndex != -1) {
            int index = startIndex;
            int literalStart = -1;
            while (index < querry.length()) {
                if (querry.charAt(index) == '\'') {
                    if (literalStart == -1 && index + 1 < querry.length()) {
                        literalStart = index +1;
                    } else {
                        String targetString = querry.substring(literalStart, index);
                        targetStrings.add(targetString);
                        literalStart = -1;
                        processedQuerry += "?";
                        index++;
                    }
                }
                if (index < querry.length() && literalStart == -1) {
                    processedQuerry += querry.charAt(index);
                }
                index++;
            }
            PreparedStatement stmt = con.prepareStatement(processedQuerry + " ");
            Iterator it = targetStrings.iterator();
            int counter =1;
            while (it.hasNext()) {
                String arg = (String)it.next();
                stmt.setString(counter++, arg);
            }
            return stmt;
        } else {
            PreparedStatement stmt = con.prepareStatement(querry);
            return stmt;
        }
    }
    private void loadDriver()
    {
        //see jdbc tutotials
        try {
            
            // The newInstance() call is a work around for some
            // broken Java implementations
            
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            Debug.println("OperatorDAOImpl: SQL Driver Loaded");
        }
        catch (Exception E) {
            Debug.println("OperatorDAOImpl: Unable to load mySQL JDBC2 driver.");
            E.printStackTrace();
        }
    }
    
    private void getConnection()
    {
        //see jdbc tutotials
        try {
            
            dbConnection = DriverManager.getConnection(Constants.DAO_SQL_KEY);
            Debug.println("Operator DAO Impl: SQL Connection Processed");
        }
        catch (SQLException E) {
            Debug.println("OperatorDAOImpl: SQLException: " + E.getMessage());
            Debug.println("OperatorDAOImpl: SQLState:     " + E.getSQLState());
            Debug.println("OperatorDAOImpl: VendorError:  " + E.getErrorCode());
        }
    }
    
    //Object dest should be a bean-like object - Bill R
    private void copyResultSetToProperties(Object dest, ResultSet resultSet)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        if (dest == null)
            throw new IllegalArgumentException
            ("No destination bean specified");
        if (resultSet == null)
            throw new IllegalArgumentException("No origin resultSet specified");
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int numberOfColumns = rsmd.getColumnCount();
            
            for (int i = 0; i < numberOfColumns; i++) {
                String columnName = rsmd.getColumnName(i + 1);
                //note that the first char of database name is capitalized >>> convert to lowercase to match the bean property
                String propertyName = columnName.substring(0,1).toLowerCase() + columnName.substring(1);
                if (PropertyUtils.getPropertyDescriptor(dest, propertyName) != null) {
                    Object columnValue = resultSet.getObject(columnName);
                    try {
                        PropertyUtils.setSimpleProperty(dest, propertyName, columnValue);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
            
        }   catch (SQLException se) {
            throw new OperatorDAOSysException("OperatorDAOImpl.copyResultSetToProperties:SQL Exception while copying: \n" + se);
        }
    }
    
    private String propertiesToSqlSetString(Object orig)
    throws IllegalAccessException, InvocationTargetException,
    NoSuchMethodException {
        
        String sqlSetString = " ";
        
        if (orig == null)
            throw new IllegalArgumentException("No origin bean specified");
        
        PropertyDescriptor origDescriptors[] = PropertyUtils.getPropertyDescriptors(orig);
        for (int i = 0; i < origDescriptors.length; i++) {
            String propertyName = origDescriptors[i].getName();
            Object value = PropertyUtils.getSimpleProperty(orig, propertyName);
            //note that the first char of bean property name is lowercase >>> convert to uppercase to match the column name
            String columnName = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            if (columnName.equals("Class") || columnName.equals("Address")) {
                //do nothing-get rid of bean Class info-Bill R and nested Address object
            }
            else {
                sqlSetString = sqlSetString + columnName + " = " + "'" + value + "',";
            }
        }
        //chop off the last comma
        sqlSetString = sqlSetString.substring(0,sqlSetString.length()-1);
        //Debug.println("OperatorDAOImpl.propertiesToSqlSetString:sqlSetString="+ sqlSetString);
        return(sqlSetString);
    }
}


