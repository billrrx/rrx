 
package ca.rrx.nw.rr.model.server.exceptions;

import java.lang.RuntimeException;
 
public class ServerDAOSysException extends RuntimeException
{

    /*--------------------------------------------------------------------
     * Constructor
     * @param str    a string that explains what the exception condition is
     *--------------------------------------------------------------------*/
     
    public ServerDAOSysException(String str) 
    {
        super(str);
    }

    /*--------------------------------------------------------------------
     * Default constructor. Takes no arguments
     *--------------------------------------------------------------------*/
     
    public ServerDAOSysException() 
    {
        super();
    }

}
