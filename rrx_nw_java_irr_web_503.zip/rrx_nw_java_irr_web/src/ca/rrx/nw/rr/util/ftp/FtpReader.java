
package ca.rrx.nw.rr.util.ftp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;



public class FtpReader
extends BufferedReader
{

  //
  // constructors
  //

  /**
   * Contruct an FtpReader for the specified FtpClient.
   **/
  FtpReader(Reader in, FtpClient client)
    throws IOException
    {
      super(in);
      m_client = client;
      while (!in.ready()) {
	try { Thread.sleep(50L); }
	catch (InterruptedException exc) {}
      }
    }

  /**
   * Close the underlying Reader and signal the FtpClient that
   * Reader processing has completed.
   **/
  public void close() 
    throws IOException
    {
      super.close();
      m_client.closeTransferSocket();
    }

  //
  // member variables
  //

  private FtpClient m_client;
  
}

/**
 * $Log: FtpReader.java,v $
 * Revision 1.2  2004/02/07 05:14:59  root
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2004/02/07 04:52:46  root
 * rrx canarie
 *
 * Revision 1.1.1.1  2004/01/11 02:04:43  root
 * rrx irr
 *
 * Revision 1.1.1.1  2004/01/02 05:25:03  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/27 04:13:31  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/26 02:51:45  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/21 00:09:48  root
 * rrx irr web services
 *
 * Revision 1.1.1.1  2003/12/15 04:20:23  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/10 18:31:48  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/09 07:51:24  root
 * imported rrx tree
 *
 * Revision 1.1.1.1  2003/12/07 23:32:18  root
 * import
 *
 * Revision 1.1.1.1  2002/06/19 22:26:42  user
 * Initial
 *
 * Revision 1.1.1.1  2001/11/26 03:03:14  user
 * Initial
 *
 * Revision 1.1  2001/11/19 17:25:14  user
 * *** empty log message ***
 *
 * Revision 1.4  1998/08/19 05:57:52  cheetham
 * All of RFC959 implemented except for passive.
 *
 * Revision 1.3  1998/08/18 03:49:22  cheetham
 * Added more comments and formatting for HTML.
 *
 * Revision 1.2  1998/08/14 05:54:52  cheetham
 * 90% of base implementation.
 *
 * Revision 1.1  1998/08/09 01:38:53  cheetham
 * Genesis.
 *
 **/
