
package ca.rrx.nw.rr.util.ftp;

import java.io.BufferedReader;
import java.io.IOException;



public class FtpResponse
{

  /**
   * Construct a new FtpResponse, whose contents will be
   * derived from the BufferedReader.
   **/
  FtpResponse(BufferedReader in)
    throws IOException
    {
      setMessage(in);
    }

  /**
   * Return the reply from the FTP server in its entirety.
   **/
  public String getMessage()
    {
      return m_message;
    }

  /**
   * Return the 3-digit return code that is also the first 3 characters
   * of the FTP reply.
   **/
  public String getReturnCode()
    {
      return m_returnCode;
    }

  /**
   * Return a String representation of this object.  Return the same
   * as getMessage().
   **/
  public String toString()
    {
      return m_message;
    }

  /**
   * Returns <CODE>true</CODE> if the first character of the return
   * code indicates a positive prelimary reply, as outlined in RFC959.
   **/
  public boolean isPositivePreliminary()
    {
      return m_returnCode.charAt(0) == REPLY_POSITIVE_PRELIMINARY;
    }

  /**
   * Returns <CODE>true</CODE> if the first character of the return
   * code indicates a positive completion reply, as outlined in RFC959.
   **/
  public boolean isPositiveCompletion()
    {
      return m_returnCode.charAt(0) == REPLY_POSITIVE_COMPLETION;
    }

  /**
   * Returns <CODE>true</CODE> if the first character of the return
   * code indicates a positive intermediary reply, as outlined in RFC959.
   **/
  public boolean isPositiveIntermediary()
    {
      return m_returnCode.charAt(0) == REPLY_POSITIVE_INTERMEDIARY;
    }

  /**
   * Returns <CODE>true</CODE> if the first character of the return
   * code indicates a transient negative reply, as outlined in RFC959.
   **/
  public boolean isTransientNegativeCompletion()
    {
      return m_returnCode.charAt(0) == REPLY_TRANSIENT_NEGATIVE_COMPLETION;
    }

  /**
   * Returns <CODE>true</CODE> if the first character of the return
   * code indicates a permanent negative reply, as outlined in RFC959.
   **/
  public boolean isPermanentNegativeCompletion()
    {
      return m_returnCode.charAt(0) == REPLY_PERMANENT_NEGATIVE_COMPLETION;
    }

  /**
   * Returns <CODE>true</CODE> if the second character of the return
   * code indicates a reply pertaining to syntax (or maybe just superfluous), 
   * as outlined in RFC959.
   **/
  public boolean isRegardingSyntax()
    {
      return m_returnCode.charAt(1) == REGARDING_SYNTAX;
    }

  /**
   * Returns <CODE>true</CODE> if the second character of the return
   * code indicates a reply pertaining to information, as outlined in RFC959.
   **/
  public boolean isRegardingInformation()
    {
      return m_returnCode.charAt(1) == REGARDING_INFORMATION;
    }

  /**
   * Returns <CODE>true</CODE> if the second character of the return
   * code indicates a reply pertaining to connection, as outlined in RFC959.
   **/
  public boolean isRegardingConnection()
    {
      return m_returnCode.charAt(1) == REGARDING_CONNECTION;
    }

  /**
   * Returns <CODE>true</CODE> if the second character of the return
   * code indicates a reply pertaining to authentication, as outlined in 
   * RFC959.
   **/
  public boolean isRegardingAuthentication()
    {
      return m_returnCode.charAt(1) == REGARDING_AUTHENTICATION;
    }

  /**
   * Returns <CODE>true</CODE> if the second character of the return
   * code indicates a reply pertaining to file system, as outlined in 
   * RFC959.
   **/
  public boolean isRegardingFileSystem()
    {
      return m_returnCode.charAt(1) == REGARDING_FILE_SYSTEM;
    }

  private void setMessage(BufferedReader in)
    throws IOException
    {
      StringBuffer buffer = new StringBuffer();
      while (true) {
	while (!in.ready()) {
	  try { Thread.sleep(10L); }
	  catch (InterruptedException exc) {}
	}
	String line = in.readLine();
	if (m_returnCode == null)
	  m_returnCode = line.substring(0, 3);
	buffer.append(line);
	buffer.append('\n');
	if (line.charAt(3) == ' ')
	  if (m_returnCode.equals( line.substring(0, 3) ))
	    break;
      }
      m_message = buffer.toString();
    }

  private String m_message;
  private String m_returnCode;

  static final public char REPLY_POSITIVE_PRELIMINARY = '1';
  static final public char REPLY_POSITIVE_COMPLETION = '2';
  static final public char REPLY_POSITIVE_INTERMEDIARY = '3';
  static final public char REPLY_TRANSIENT_NEGATIVE_COMPLETION = '4';
  static final public char REPLY_PERMANENT_NEGATIVE_COMPLETION = '5';

  static final public char REGARDING_SYNTAX = '0';
  static final public char REGARDING_INFORMATION = '1';
  static final public char REGARDING_CONNECTION = '2';
  static final public char REGARDING_AUTHENTICATION = '3';
  static final public char REGARDING_UNSPECIFIED = '4';
  static final public char REGARDING_FILE_SYSTEM = '5';

}

/**
 * $Log: FtpResponse.java,v $
 * Revision 1.2  2004/02/07 05:14:59  root
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2004/02/07 04:52:46  root
 * rrx canarie
 *
 * Revision 1.1.1.1  2004/01/11 02:04:43  root
 * rrx irr
 *
 * Revision 1.1.1.1  2004/01/02 05:25:03  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/27 04:13:31  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/26 02:51:45  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/21 00:09:48  root
 * rrx irr web services
 *
 * Revision 1.1.1.1  2003/12/15 04:20:23  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/10 18:31:48  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/09 07:51:24  root
 * imported rrx tree
 *
 * Revision 1.1.1.1  2003/12/07 23:32:18  root
 * import
 *
 * Revision 1.1.1.1  2002/06/19 22:26:42  user
 * Initial
 *
 * Revision 1.1.1.1  2001/11/26 03:03:14  user
 * Initial
 *
 * Revision 1.1  2001/11/19 17:25:14  user
 * *** empty log message ***
 *
 * Revision 1.5  1998/08/19 05:57:52  cheetham
 * All of RFC959 implemented except for passive.
 *
 * Revision 1.4  1998/08/18 03:49:23  cheetham
 * Added more comments and formatting for HTML.
 *
 * Revision 1.3  1998/08/14 05:54:52  cheetham
 * 90% of base implementation.
 *
 * Revision 1.2  1998/08/09 01:41:10  cheetham
 * Re-worked.  Now stores the entire message as it was received, as well as
 * the 3 character ftp return code embedded at the front of the message.
 *
 * Revision 1.1  1998/08/06 04:58:43  cheetham
 * Genesis.
 *
 **/
