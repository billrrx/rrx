
package ca.rrx.nw.rr.util;

public interface JNDINames {


    //
    // JNDI Names of data sources.
    //
    public static final String IRR_DATASOURCE =
        "java:comp/env/jdbc/IRRDataSource";

    //
    // JNDI Names of other resources.
    //
    public static final String MAIL_SESSION =
        "java:comp/env/mail/MailSession";

    //
    // JNDI Names of application properties.
    //
    //public static final String SECURITY_ADAPTER_CLASSNAME =
    //  "java:comp/env/securityAdapterClassName";

    public static final String SERVER_TYPE =
        "java:comp/env/server/ServerType";

    public static final String SEND_CONFIRMATION_MAIL =
        "java:comp/env/ejb/mail/SendConfirmationMail";
    
   public static final String OPERATOR_DAO_CLASS =
        "java:comp/env/operator/OperatorDAOClass";
   
   public static final String ROUTER_DAO_CLASS =
        "java:comp/env/router/RouterDAOClass";
   
      public static final String RPSL_DAO_CLASS =
        "java:comp/env/rpsl/RpslDAOClass";
 
     public static final String SERVER_DAO_CLASS =
        "java:comp/env/operator/ServerDAOClass";     

     
}
