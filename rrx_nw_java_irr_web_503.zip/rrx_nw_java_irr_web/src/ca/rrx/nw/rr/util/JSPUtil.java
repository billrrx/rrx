
package ca.rrx.nw.rr.util;

import java.util.Locale;
import java.util.Vector;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.text.BreakIterator;
import java.util.Locale;
import java.io.ByteArrayOutputStream;

import javax.servlet.http.HttpSession;

import ca.rrx.nw.rr.util.WebKeys;
import ca.rrx.nw.rr.util.Debug;

/**
 * This utility class for web tier components (namely Java
 * Server Pages and JavaBeans). This class provides a
 * central location to do specialized formatting in both
 * a default and a locale specfic manner.
 */
public final class JSPUtil extends Object {

    //access to eventCounter is only through the
    //accessor method getEventId()
    private static int eventCounter;

    /**
     * Converts a String SJIS or JIS URL encoded hex encoding to a Unicode String
     *
    */
    public static String convertJISEncoding(String target) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (target == null) return null;
        String paramString = target.trim();

        for (int loop =0; loop < paramString.length(); loop++) {
            int i = (int)paramString.charAt(loop);
            bos.write(i);
        }
        String convertedString = null;
        try {
            convertedString =  new String(bos.toByteArray(), "JISAutoDetect");
        } catch (java.io.UnsupportedEncodingException uex) {}
        return convertedString;
    }



    public static Vector parseKeywords(String keywordString){
        if (keywordString != null){
            Vector keywords = new Vector();
            BreakIterator breakIt = BreakIterator.getWordInstance();
            int index=0;
            int previousIndex =0;
            breakIt.setText(keywordString);
            try{
                while(index < keywordString.length()){
                    previousIndex = index;
                    index = breakIt.next();
                    String word = keywordString.substring(previousIndex, index);
                    if (!word.trim().equals("")) keywords.addElement(word);
                }
                return keywords;
            } catch (Throwable e){
                Debug.print(e, "Error while parsing search string");
            }

        }
        return null;
    }

    public static Vector parseKeywords(String keywordString, Locale locale){
        if (keywordString != null){
            Vector keywords = new Vector();
            BreakIterator breakIt = BreakIterator.getWordInstance(locale);
            int index=0;
            int previousIndex =0;
            breakIt.setText(keywordString);
            try{
                while(index < keywordString.length()){
                    previousIndex = index;
                    index = breakIt.next();
                    String word = keywordString.substring(previousIndex, index);
                    if (!word.trim().equals("")) keywords.addElement(word);
                }
                return keywords;
            } catch (Throwable e){
                Debug.print(e, "Error while parsing search string" );
            }

        }
        return null;
    }

    public static int getEventId(){
        return eventCounter++;
    }

    /**
     * Get the Locale specified in the session or return a default locale.
     */
    public static Locale getLocale(HttpSession session) {
        Locale locale = (Locale)session.getAttribute(WebKeys.LanguageKey);
        if (locale == null) locale = Locale.US;
        return locale;
    }

    /**
     * Get the Locale specified in the session or return a default locale.
     */
    public static Locale getLocaleFromLanguage(String language) {
        Locale locale = Locale.US;
        if (language.equals("English")) locale = Locale.US;
        else if (language.equals("Japanese")) locale = Locale.JAPAN;
        return locale;
    }

}











