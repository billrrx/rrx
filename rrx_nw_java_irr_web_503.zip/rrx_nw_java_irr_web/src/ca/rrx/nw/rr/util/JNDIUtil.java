
package ca.rrx.nw.rr.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import ca.rrx.nw.rr.util.Debug;


public final class JNDIUtil implements JNDINames {

    /**
     * a convenience method to get the boolean value corresponding
     * to the SEND_CONFIRMATION_MAIL property.
     */
    public static boolean sendConfirmationMail() {
        boolean boolVal = false;
        try {
            InitialContext ic = new InitialContext();
            Boolean bool = (Boolean)
                ic.lookup(JNDINames.SEND_CONFIRMATION_MAIL);
            if (bool != null) {
                boolVal = bool.booleanValue();
            }
        } catch (NamingException ne) {
            // If property is not present in the deployment
            // descriptor, conservatively assume that we do not send
            // confirmation mail for each order.
            Debug.print(ne);
        }
        return boolVal;
    }
}

