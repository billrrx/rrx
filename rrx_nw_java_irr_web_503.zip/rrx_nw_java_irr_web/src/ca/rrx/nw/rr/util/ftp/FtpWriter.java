
package ca.rrx.nw.rr.util.ftp;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;

public class FtpWriter
extends BufferedWriter
{

  //
  // constructors
  //

  /**
   * Contruct an FtpWriter for the specified FtpClient.
   **/
  FtpWriter(Writer out, FtpClient client)
    throws IOException
    {
      super(out, 1024);
      m_client = client;
    }

  /**
   * Close the underlying Writer and signal the FtpClient that
   * Writer processing has completed.
   **/
  public void close() 
    throws IOException
    {
      super.close();
      m_client.closeTransferSocket();
    }

  //
  // member variables
  //

  private FtpClient m_client;
  
}

/**
 * $Log: FtpWriter.java,v $
 * Revision 1.2  2004/02/07 05:14:59  root
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2004/02/07 04:52:46  root
 * rrx canarie
 *
 * Revision 1.1.1.1  2004/01/11 02:04:43  root
 * rrx irr
 *
 * Revision 1.1.1.1  2004/01/02 05:25:03  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/27 04:13:31  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/26 02:51:45  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/21 00:09:48  root
 * rrx irr web services
 *
 * Revision 1.1.1.1  2003/12/15 04:20:23  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/10 18:31:48  root
 * rrx irr
 *
 * Revision 1.1.1.1  2003/12/09 07:51:24  root
 * imported rrx tree
 *
 * Revision 1.1.1.1  2003/12/07 23:32:18  root
 * import
 *
 * Revision 1.1.1.1  2002/06/19 22:26:42  user
 * Initial
 *
 * Revision 1.1.1.1  2001/11/26 03:03:14  user
 * Initial
 *
 * Revision 1.1  2001/11/19 17:25:14  user
 * *** empty log message ***
 *
 * Revision 1.3  1998/08/19 05:57:52  cheetham
 * All of RFC959 implemented except for passive.
 *
 * Revision 1.2  1998/08/18 03:49:23  cheetham
 * Added more comments and formatting for HTML.
 *
 * Revision 1.1  1998/08/14 06:01:02  cheetham
 * Genesis.
 *
 **/
