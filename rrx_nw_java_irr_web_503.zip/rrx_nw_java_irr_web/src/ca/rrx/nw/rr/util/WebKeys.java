
package ca.rrx.nw.rr.util;

/**
 * This interface contains all the keys that are used to
 * store data in the different scopes of web-tier. These
 * values are the same as those used in the JSP
 * pages (useBean tags).
 */
public interface WebKeys {

    public static final String WebControllerKey = "webController";
    public static final String CurrentScreen = "currentScreen";
    public static final String PreviousScreen = "previousScreen";
    public static final String LanguageKey = "language";
    public static final String URLMappingsKey = "urlMappings";
    public static final String MissingFormDataKey = "missingFormData";
    public static final String SigninTargetURL = "signinTargetURL";
    public static final String ServerTypeKey = "serverType";
    public static final String RequestIdKey = "requestId";
}
