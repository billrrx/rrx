package ca.rrx.nw.rr.util.zip;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.Adler32;
import java.util.zip.CheckedInputStream;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class Zip
{
    public static void compress(File[] fs, File outFile) {
	BufferedInputStream origin = null;
	FileOutputStream dest = null;
	CheckedOutputStream checksum = null;
	ZipOutputStream out = null;
	try {
	    dest = new FileOutputStream(outFile);
	    checksum = new CheckedOutputStream(dest, new Adler32());
	    out = new ZipOutputStream(new BufferedOutputStream(checksum));
	    byte[] data = new byte[4096];
	    for (int i = 0; i < fs.length; i++) {
		FileInputStream fi = new FileInputStream(fs[i]);
		origin = new BufferedInputStream(fi, 4096);
		ZipEntry entry = new ZipEntry(fs[i].getName());
		out.putNextEntry(entry);
		int count;
		while ((count = origin.read(data, 0, 4096)) != -1)
		    out.write(data, 0, count);
		origin.close();
		fi.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    try {
		if (origin != null)
		    origin.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (out != null)
		    out.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (checksum != null)
		    checksum.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (dest != null)
		    dest.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	}
    }
    
    public static void compress(File[] fs, String inFile, File outFile) {
	BufferedInputStream origin = null;
	FileOutputStream dest = null;
	CheckedOutputStream checksum = null;
	ZipOutputStream out = null;
	try {
	    dest = new FileOutputStream(outFile);
	    checksum = new CheckedOutputStream(dest, new Adler32());
	    out = new ZipOutputStream(new BufferedOutputStream(checksum));
	    byte[] data = new byte[4096];
	    ZipEntry entry = new ZipEntry(inFile);
	    out.putNextEntry(entry);
	    for (int i = 0; i < fs.length; i++) {
		FileInputStream fi = new FileInputStream(fs[i]);
		origin = new BufferedInputStream(fi, 4096);
		int count;
		while ((count = origin.read(data, 0, 4096)) != -1)
		    out.write(data, 0, count);
		out.write(10);
		origin.close();
		fi.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    try {
		if (origin != null)
		    origin.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (out != null)
		    out.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (checksum != null)
		    checksum.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (dest != null)
		    dest.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	}
    }
    
    public static void decompress(File inFile, File outDir) {
	BufferedOutputStream dest = null;
	FileInputStream fis = null;
	CheckedInputStream checksum = null;
	ZipInputStream zis = null;
	try {
	    fis = new FileInputStream(inFile);
	    checksum = new CheckedInputStream(fis, new Adler32());
	    zis = new ZipInputStream(new BufferedInputStream(checksum));
	    ZipEntry entry;
	    while ((entry = zis.getNextEntry()) != null) {
		byte[] data = new byte[4096];
		FileOutputStream fos
		    = (new FileOutputStream
		       (String.valueOf(new StringBuffer
					   (outDir.getAbsolutePath()).append
					   ("/").append(entry.getName()))));
		dest = new BufferedOutputStream(fos, 4096);
		int count;
		while ((count = zis.read(data, 0, 4096)) != -1)
		    dest.write(data, 0, count);
		dest.flush();
		dest.close();
	    }
	    zis.close();
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    try {
		if (dest != null)
		    dest.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (fis != null)
		    fis.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (checksum != null)
		    checksum.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (zis != null)
		    zis.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	}
    }
    
    public static void decompress(String inFile, String outFile) {
	BufferedOutputStream dest = null;
	FileInputStream fis = null;
	CheckedInputStream checksum = null;
	ZipInputStream zis = null;
	try {
	    fis = new FileInputStream(inFile);
	    checksum = new CheckedInputStream(fis, new Adler32());
	    zis = new ZipInputStream(new BufferedInputStream(checksum));
	    ZipEntry entry;
	    while ((entry = zis.getNextEntry()) != null) {
		byte[] data = new byte[4096];
		FileOutputStream fos = new FileOutputStream(outFile);
		dest = new BufferedOutputStream(fos, 4096);
		int count;
		while ((count = zis.read(data, 0, 4096)) != -1)
		    dest.write(data, 0, count);
		dest.flush();
		dest.close();
	    }
	    zis.close();
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    try {
		if (dest != null)
		    dest.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (fis != null)
		    fis.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (checksum != null)
		    checksum.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	    try {
		if (zis != null)
		    zis.close();
	    } catch (Exception ex) {
		ex.printStackTrace();
	    }
	}
    }
}
