package ca.rrx.nw.rr.util;

/**
 * This interface stores the name of all the database tables.
 * The String constants in this class should be used by other
 * classes instead of hardcoding the name of a database table
 * into the source code.
 */
public interface DatabaseNames {

    //operator tables
    public static final String OPERATOR_PROFILE_TABLE   = "OperatorProfile";
    public static final String OPERATOR_SESSION_PROFILE_TABLE   = "OperatorSessionProfile";
    //rpsl tables 
    public static final String RPSL_FILTER_TABLE = "RpslFilter";
    //admin tables
    public static final String OPERATOR_PROFILE_NEW_TABLE   = "OperatorProfileNew";
    public static final String OPERATOR_SESSION_LOG_TABLE   = "OperatorSessionLog";
    //server tables
    public static final String SERVER_TABLE = "IRRServers";
    //router tables
    public static final String ROUTER_PROFILE_TABLE = "RouterProfile";
    public static final String ROUTER_CONFIGURATION_TABLE = "RouterConfiguration";
    public static final String ROUTER_CONNECTION_PROFILE_TABLE = "RouterConnectionProfile";
    public static final String ROUTER_CONTROL_PORT_TABLE = "RouterControlPort";
    public static final String ROUTER_TRANSIT_PORT_TABLE = "RouterTransitPort";
    public static final String ROUTER_UCLP_PROFILE_TABLE = "UclpProfile";

    
    
    //not used?
    public static final int MAX_USERID_LENGTH = 25;
    public static final int MAX_PASSWD_LENGTH = 25;
}
