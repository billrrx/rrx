
package ca.rrx.nw.rr;

import ca.rrx.nw.rr.util.Debug;

public final class Constants
{

    private Constants () {}

    /**
     * 
     */
    public static final String Package = "app";

    
    //PLEASE EDIT THESE Parameters... if necessary -  RRX Network
    
    public static final String DEFAULT_LOGO                 = "graphics/RON_logo.gif";
    
    public static final String DEFAULT_SERVER_IP            = "localhost"; //web server
    public static final String DEFAULT_PORT                 = "43001"; // default irr whois port
    
    public static final String URL_ROOT                     = "http://" + DEFAULT_SERVER_IP + ":8080";
    public static final String DAO_SQL_KEY                  = "jdbc:mysql://" + DEFAULT_SERVER_IP + "/IRRWEB?user=root&password=tomcat";
    public static final String SHELL_SQL_KEY                = "mysql --user=root --password=tomcat";
    //note currently assumes mySQL db has user tomcat at localhost.localdomain with no password required
    //modify this later for security reasons -  RRX Network
    public static final String FULL_BASE_DIR                = "/home/development/nbpf/rrx_nw_java_irr_503_fc21/build/web";
    public static final String TMP_BASE_DIR                 = FULL_BASE_DIR + "/tmp";
    public static final String MAINTAINER_BASE_DIR          = FULL_BASE_DIR + "/data/maintainer";
    public static final String OPERATOR_BASE_DIR            = FULL_BASE_DIR + "/data/operator"; 
    public static final String SERVER_BASE_DIR              = FULL_BASE_DIR + "/data/server";
    //this is for ca.rrx.nw.rr servers by server profile name
    public static final String RELATIVE_BASE_DIR            = "/";
    public static final String RELATIVE_ROOT_DIR            = "/";

     
    public static final String RTCONFIG_COMMAND                = "rtconfig";
    //used for command substitution in the router templates by reciprocating over ca.rrx.nw.rr entries
    public static final String PING_PATH                    = "ping -c 1 -q -s 0 -n ";
    //used for transit port verification assuming ICMP turned on ...
    public static final String WHOIS                        = "whois3 -B -G -h ";
    //this is the ca.rrx.nw.rr dbase custom whois not the standard one -  RRX NW    
    
    public static final String DEFAULT_PRIMARY_IRR_DNS      = "localhost";
    public static final String DEFAULT_PRIMARY_IRR_ID       = "1";
    public static final String DEFAULT_SECONDARY_IRR_DNS    = "::1";
    public static final String DEFAULT_MNT                  = "CANARIE-MNT";
    public static final String DEFAULT_SRC_DB               = "canarie";
    
    public static final String WHOIS_COMMAND                = "whois3";

    
    //PLEASE **DO NOT** EDIT THESE Parameters... generally -  RRX NW
    
    public static final String USER_KEY                         = "user"; 
    public static final String USERNAME_KEY                     = "MM_Username";
    public static final String LANGUAGE_KEY                     = "MM_Language";
    public static final String USERROLE_KEY                     = "MM_Role"; 
    public static final String USERMAINT_KEY                    = "MM_Maint";
    public static final String CURRENT_PAGE_KEY                 = "Operator Profile";
    
    public static final String ADMINISTRATOR_ROLE_VALUE         = "Administrator"; 
    public static final String OPERATOR_ROLE_VALUE              = "Operator";
    public static final String NEW_OPERATOR_KEY                 = "false";
    public static final String DISABLED_ROLE_VALUE              = "Disabled";
    public static final String USERSESSION_KEY                  = "MM_Session"; 

    public static final String REPORT_KEY                       = "report";
    public static final String REPORT_RPSL_CLASS_KEY            = "route";
    public static final String REPORT_RPSL_INV_ATTR_KEY         = "mnt-by";
    public static final String REPORT_RPSL_INV_VALUE_KEY        = "CANARIE-MNT";
    public static final String REPORT_TIER_KEY                  = "report_tier";
    public static final String REPORT_TIERMAINT_KEY             = "report_tiermaint";
    public static final String REPORT_MEMBERSHIP_KEY            = "report_membership_key";

    public static final String OPERATOR_PROFILE_KEY             = "operator_profile";
    public static final String THIS_OPERATOR_SESSION_KEY        = "thisOperatorSessionId";
    public static final String DEFAULT_OPERATOR_SESSION_KEY     = "defaultOperatorSessionId";
    public static final String SELECTED_OPERATOR_SESSION_KEY    = "selectedOperatorSession";
    
    public static final String LOGIN_EVENT_CODE                 = "Sign In";
    public static final String LOGOUT_EVENT_CODE                = "Sign Out";
    public static final String TIMEOUT_EVENT_CODE               = "Time Out";
    public static final String UNUSUAL_EVENT_CODE               = "Unusual Termination";
    
    public static final String REPORT_EDIT_KEY                  = "report_edit";
    public static final String REPORT_SUBMIT_CONFIRMATION_KEY   = "report_submit_confirmation";
    public static final String REPORT_RESULTS_KEY               = "report_results";

    public static final String POLICY_GENERATION_KEY            = "policy_generation";
    public static final String POLICY_SUBMIT_CONFIRMATION_KEY   = "policy_submit_confirmation";
    public static final String POLICY_RESULTS_KEY               = "policy_results";
 
    public static final String IRR_SUBMIT_CONFIRMATION_KEY      = "irr_confirmation";

    public static final String  RTR_CONFIG_KEY                  = "router_configuration";
   
    public static final String AQUERY_KEY                       = "advanced_query";
    public static final String AQUERY_EDIT_KEY                  = "advanced_query_edit";

    public static final String ALIST_KEY                        = "access_list";
    public static final String ALIST_SCRIPT1                    = "/bin/accesslist.sh";
    public static final String ALIST_SCRIPT2                    = "/bin/accesslist2.sh";
    public static final String ALIST_SCRIPT3                    = "/bin/accesslist3.sh";
    public static final String ALIST_SCRIPT4                    = "/bin/accesslist4.sh";
    public static final String ALIST_SCRIPT5                    = "/bin/accesslist5.sh";
    public static final String ALIST_SCRIPT6                    = "/bin/accesslist6.sh";

    public static final String IRRUPDATE_SCRIPT1                = "/bin/update.sh";

    public static final String POLICYGENERATION_SCRIPT1         = "/bin/policygeneration1.sh";

    public static final String RTRCONFIG_SCRIPT1                = "/bin/routerConfiguration1.sh";

    public static final String NEW_LINE                         = System.getProperty("line.separator");

    public static final String TOPINDEX_KEY                     = "top_index";
    public static final String TOPINDEXLOG_KEY                  = "top_index_log";
    
    public static final String CONFIGURATION_FILE_KEY           = "config_filename_key";
    public static final String CONFIGURATION_TIMESTAMP_KEY      = "config_timestamp_key";
    public static final String CONFIGURATION_RESULT_KEY         = "config_result_key";
    public static final String TEMPLATE_TIMESTAMP_KEY           = "template_timestamp_key";
    public static final String TEMPLATE_DEFAULT_CMD_KEY         = "template_default_cmd_key";
    
    public static final String PRIMARY_SERVER       		= "MM_PrimaryServer";
    public static final String SELECTED_SERVER       		= "MM_SelectedServer";
    public static final String ROUTER_KEY           		= "MM_RouterId";
    public static final String CONTROL_PORT_KEY     		= "MM_ControlPortId";
    public static final String CONTROL_CONNECTION_KEY		= "MM_ControlConnection";	  	
    
}
