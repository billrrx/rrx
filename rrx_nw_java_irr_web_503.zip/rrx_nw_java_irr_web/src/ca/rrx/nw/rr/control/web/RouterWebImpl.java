
package ca.rrx.nw.rr.control.web;

import java.util.Collection;
import java.util.Locale;

import ca.rrx.nw.rr.model.router.exceptions.RouterDAOSysException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOFinderException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAODBUpdateException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAODupKeyException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOAppException;
import ca.rrx.nw.rr.model.router.dao.RouterDAO;
import ca.rrx.nw.rr.model.router.dao.RouterDAOFactory;
import ca.rrx.nw.rr.model.router.dao.RouterDAOImpl;
import ca.rrx.nw.rr.model.router.model.RouterModel;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.control.exceptions.GeneralFailureException;
import java.lang.reflect.InvocationTargetException;


public class RouterWebImpl implements java.io.Serializable {
    
    protected RouterDAO routerDao;
    private RouterModel routerModel;
    
    public RouterWebImpl() {
        try {
            
            if (routerDao == null) routerDao = RouterDAOFactory.getDAO();
            
            
        } catch (RouterDAOSysException se) {
            throw new GeneralFailureException(se.getMessage());
        }
    }
    
    public RouterModel getModel(String maintainerCode) {
        try {
            ////Debug.println("RouterWebImpl: getModel: before - the_key = "+ maintainerCode);
             if (routerModel == null) routerModel = routerDao.load(maintainerCode);
            ////Debug.println("RouterWebImpl: getModel: after - the_key = "+ maintainerCode);
        } catch (RouterDAOFinderException fe) {
            throw new GeneralFailureException(fe.getMessage());
        }
                catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
        return routerModel;
    }
    
    public void update(Object daoObject) {
        try {
            ////Debug.println("RouterWebImpl: updateModel: before");
            routerDao.store(daoObject);
            ////Debug.println("RouterWebImpl: updateModel: after");
        } catch (RouterDAODBUpdateException ue) {
            throw new GeneralFailureException(ue.getMessage());
        }
          catch (RouterDAOAppException ae) {
            throw new GeneralFailureException(ae.getMessage());
        }
                        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
    }
   
   public void add(Object daoObject) 
    {
        try 
        {
            //Debug.println("RouterWebImpl: add: before"); 
            routerDao.create(daoObject);
            //Debug.println("RouterWebImpl: add: after");
        } 
        catch (RouterDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (RouterDAODupKeyException dk) 
        {
            throw new GeneralFailureException(dk.getMessage());
        }
        catch (RouterDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
   } 
           
        public void delete(Object daoObject) 
        {
        try 
        {
            //Debug.println("RouterWebImpl: delete : before"); 
            routerDao.remove(daoObject);
            //Debug.println("RouterWebImpl: delete : after");
        } 
        catch (RouterDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (RouterDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }

    } 
        
    
}
