
package ca.rrx.nw.rr.control.web;

import java.util.Collection;
import java.util.Locale;
//import javax.ejb.FinderException;

import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOSysException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOFinderException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAODBUpdateException;
import ca.rrx.nw.rr.model.rpsl.exceptions.RpslDAOAppException;
import ca.rrx.nw.rr.model.rpsl.dao.RpslDAO;
import ca.rrx.nw.rr.model.rpsl.dao.RpslDAOFactory;
import ca.rrx.nw.rr.model.rpsl.dao.RpslDAOImpl;
import ca.rrx.nw.rr.model.rpsl.model.RpslModel;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.control.exceptions.GeneralFailureException;
import java.lang.reflect.InvocationTargetException;


public class RpslWebImpl implements java.io.Serializable {
    
    protected RpslDAO rpslDao;
    private RpslModel rpslModel;
    
    public RpslWebImpl() {
        try {
            //Debug.println("RpslWebImpl: constructor: before = ");
            if (rpslDao == null) rpslDao = RpslDAOFactory.getDAO();
            //Debug.println("RpslWebImpl: constructor: after = ");
        } catch (RpslDAOSysException se) {
            throw new GeneralFailureException(se.getMessage());
        }
    }
    
    public RpslModel getModel(Object operatorId) {
        try {
            //Debug.println("RpslWebImpl: getModel: before - operatorId = "+ operatorId);
            rpslModel = rpslDao.load(operatorId);
            //Debug.println("RpslWebImpl: getModel: after - operatorId = "+ operatorId);
        } catch (RpslDAOFinderException fe) {
            throw new GeneralFailureException(fe.getMessage());
        }
                catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
        return rpslModel;
    }
    
    public void add(Object daoObject) {
        try {
            ////Debug.println("RpslWebImpl: updateModel: before");
            rpslDao.create(daoObject);
            ////Debug.println("RpslWebImpl: updateModel: after");
        } catch (RpslDAODBUpdateException ue) {
            throw new GeneralFailureException(ue.getMessage());
        }
          catch (RpslDAOAppException ae) {
            throw new GeneralFailureException(ae.getMessage());
        }
                        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
    }
    
     public void delete(Object rpslFilterId) 
     {
        try 
        {
            //Debug.println("RpslWebImpl:Before Remove");           
            rpslDao.remove(rpslFilterId);
            //Debug.println("RpslWebImpl: After Remove");             
        } 
        catch (RpslDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (RpslDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }   
     }
    
}
