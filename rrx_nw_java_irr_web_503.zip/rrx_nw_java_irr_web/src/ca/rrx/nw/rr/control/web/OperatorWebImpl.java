package ca.rrx.nw.rr.control.web;

import java.util.Collection;
import java.util.Locale;


import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOSysException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOFinderException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAODBUpdateException;
import ca.rrx.nw.rr.model.operator.exceptions.OperatorDAOAppException;
import ca.rrx.nw.rr.model.operator.dao.OperatorDAO;
import ca.rrx.nw.rr.model.operator.dao.OperatorDAOFactory;
import ca.rrx.nw.rr.model.operator.dao.OperatorDAOImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.control.exceptions.GeneralFailureException;

import java.lang.reflect.InvocationTargetException;

public class OperatorWebImpl implements java.io.Serializable {
    
    protected OperatorDAO         operatorDao         = null;
    private   boolean             loggedIn            = false;
    private   OperatorModel       operatorModel       = null;
    private   OperatorInformation operatorInformation = null;
    
    public OperatorWebImpl() {
        try {
          //  //Debug.println("OperatorWebImpl: constructor: before = ");
            if (operatorDao == null) operatorDao = OperatorDAOFactory.getDAO();
          //  //Debug.println("OperatorWebImpl: constructor: after = ");
        } catch (OperatorDAOSysException se) {
            throw new GeneralFailureException(se.getMessage());
        }
    }
    
    public OperatorModel getModel(String operatorLoginName) {
        try {
            //Debug.println("OperatorWebImpl: getModel: before load of "+ operatorLoginName);
            //Debug.println("OperatorWebImpl: getModel: before load operatorDao = "+ operatorDao);
            if (operatorModel == null) operatorModel = operatorDao.load(operatorLoginName);
            //Debug.println("OperatorWebImpl: getModel: after load of "+ operatorLoginName);
        } 
        catch (OperatorDAOFinderException fe) {
            throw new GeneralFailureException(fe.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
        return operatorModel;
    }
    
   
        public void update(Object daoObject) {
        try {
            //Debug.println("OperatorWebImpl: update: before");
            operatorDao.store(daoObject);
            //Debug.println("OperatorWebImpl: update: after");
        } catch (OperatorDAODBUpdateException ue) {
            throw new GeneralFailureException(ue.getMessage());
        }
          catch (OperatorDAOAppException ae) {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
    }
   
        public void add(Object daoObject)
        {
           try 
           {
              //Debug.println("OperatorWebImpl: add: before");
              operatorDao.create(daoObject);
              //Debug.println("OperatorWebImpl: add: after");
           }
           catch (OperatorDAODBUpdateException ue) 
           {
              throw new GeneralFailureException(ue.getMessage());
           }
           catch (OperatorDAOAppException ae)
           {
              throw new GeneralFailureException(ae.getMessage());
           }
           catch (IllegalAccessException ae) 
           {
              throw new GeneralFailureException(ae.getMessage());
           }
           catch (InvocationTargetException te) 
           {
              throw new GeneralFailureException(te.getMessage());
           }
           catch (NoSuchMethodException me) 
           {
              throw new GeneralFailureException(me.getMessage());
           }
        }
        
      public void delete(Object daoObject) 
     {
        try 
        {
 //Debug.println("OperatorWebImpl:Before Remove");           
            operatorDao.remove(daoObject);
 //Debug.println("OperatorWebImpl: After Remove");             
        } 
        catch (OperatorDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (OperatorDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }   
     }
}
