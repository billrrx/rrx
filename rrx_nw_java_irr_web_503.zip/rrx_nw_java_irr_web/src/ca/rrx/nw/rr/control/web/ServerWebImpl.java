
package ca.rrx.nw.rr.control.web;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Locale;
//import javax.ejb.FinderException;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.model.server.exceptions.ServerDAOSysException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAOFinderException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAODBUpdateException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAODupKeyException;
import ca.rrx.nw.rr.model.server.exceptions.ServerDAOAppException;
import ca.rrx.nw.rr.model.server.dao.ServerDAO;
import ca.rrx.nw.rr.model.server.dao.ServerDAOFactory;
import ca.rrx.nw.rr.model.server.dao.ServerDAOImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.control.exceptions.GeneralFailureException;


public class ServerWebImpl implements java.io.Serializable
{

    protected ServerDAO   serverDao;
    private   ServerModel serverModel = null;

    public ServerWebImpl()
    {
        try
        {
           
            if (serverDao == null) serverDao = ServerDAOFactory.getDAO();
            
        }
        catch (ServerDAOSysException se)
        {
            throw new GeneralFailureException(se.getMessage());
        }
    }

    
    public ServerModel getModel(Object serverProfileId) 
    {
        try 
        {
             if (serverModel == null) serverModel = serverDao.load(serverProfileId);
        } 
        catch (ServerDAOFinderException fe) 
        {
            throw new GeneralFailureException(fe.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
        return serverModel;
    }
    

    public void add(Server server) 
    {
        try 
        {
            serverDao.create(server);
        } 
        catch (ServerDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (ServerDAODupKeyException dk) 
        {
            throw new GeneralFailureException(dk.getMessage());
        }
        catch (ServerDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
    } 
      

    public void update(Server server) 
    {
        try 
        {
            serverDao.store(server);
        } 
        catch (ServerDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (ServerDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (IllegalAccessException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }
        catch (InvocationTargetException te) 
        {
            throw new GeneralFailureException(te.getMessage());
        }
        catch (NoSuchMethodException me) 
        {
            throw new GeneralFailureException(me.getMessage());
        }
     }   

        
     public void delete(Object serverProfileId) 
     {
        try 
        {
 //Debug.println("ServerWebImpl:Before Remove");           
            serverDao.remove(serverProfileId);
 //Debug.println("ServerWebImpl: After Remove");             
        } 
        catch (ServerDAODBUpdateException de) 
        {
            throw new GeneralFailureException(de.getMessage());
        }
        catch (ServerDAOAppException ae) 
        {
            throw new GeneralFailureException(ae.getMessage());
        }   
     }
     
          

            
  
 }
