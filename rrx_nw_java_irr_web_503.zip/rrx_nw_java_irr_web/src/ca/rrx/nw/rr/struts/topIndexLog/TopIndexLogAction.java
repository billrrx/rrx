package ca.rrx.nw.rr.struts.topIndexLog;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;



public final class TopIndexLogAction extends Action
{


    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String pageId;
        ActionForward af;

        pageId = ((TopIndexLogForm) form).getPageId();

      // Save our logged-in user in the session,
      // because we use it again later.
        HttpSession session = request.getSession();

        
        session.setAttribute(Constants.CURRENT_PAGE_KEY, pageId);

        if((String)session.getAttribute(Constants.USERNAME_KEY) != null) 
        {
            if(session.getAttribute(Constants.USERNAME_KEY).equals("public"))
            {
                if((pageId.equals("report")) || (pageId.equals("aQuery"))
                    || (pageId.equals("help")) || (pageId.equals("main")))
                {
                    return (mapping.findForward("base_template"));
                }
                else
                {
                    return (mapping.findForward("session_timeout"));
                }
            }
            else
            {
            }
//            if((pageId.equals("report")) || (pageId.equals("aQuery"))
//                || (pageId.equals("help")) || (pageId.equals("main")))
//            {
//            }
//            else
//            {
//                return (mapping.findForward("session_timeout"));
//            }
        }
        else
        {
            return (mapping.findForward("session_timeout"));
        }

        session.setAttribute(Constants.TOPINDEX_KEY, form);

        //Debug.println("PageTest" + pageId);

        //System.out.println("test123" + pageId);

        if (servlet.getDebug() >= 1)
        {
            servlet.log("TopIndexLogAction: TopIndexLog '" + pageId + 
                      "' in session " + session.getId());
        }

        /*
        // this jumps to the right page, but resets drop-down
        af = new ActionForward();
        af.setPath(pageSelect);
        af.setRedirect(true);
        return(af);
        */

        /*
        // this works, but requires entry in struts-config.xml
        return (mapping.findForward("report_success"));
        */

        /*
        // this jumps to the correct page but resets drop-down
        return (mapping.findForward("base_template"));
        */

//        return (mapping.findForward("report_success"));
        return (mapping.findForward("base_template"));



        // Forward control to the success URI specified in struts-config.xml
//        return (mapping.findForward("report_success"));
//        return (mapping.findForward("template.jsp"));
//        mapping.setPath(pageSelect);
//        return (mapping.findforward(pageSelect));
    }
}