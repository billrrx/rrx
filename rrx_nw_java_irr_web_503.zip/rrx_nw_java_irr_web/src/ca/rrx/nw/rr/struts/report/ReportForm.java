package ca.rrx.nw.rr.struts.report;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


/**

 */
public final class ReportForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    /**
     * Set of objects to search for
     */
    private String objectSet;

    /**
     * Set of objects to search for
     */
    private String membership;
    private String rpslObject;
    private String rpslClassName;
    private String rpslInverseAttributeName;
    private String rpslFilterExpression;
    private String serverProfileName;
    private String mymaints1;

    private String results;
    private String command;
    private String commandIndex;

    {
        objectSet       = null;
        membership      = null;
        rpslObject      = null;
        mymaints1       = null;

        results         = null;
        command         = null;
        commandIndex    = null;
        command         = null;
        membership      = null;
    }

    // ----------------------------------------------------------- Properties

    public String getObjectSet()
    {
        return (this.objectSet);
    }

    public void setObjectSet(String o)
    {
        this.objectSet = o;
    }

    public String getMembership()
    {
        return (this.membership);
    }

    public void setMembership(String m)
    {
        this.membership = m;
    }

    public String getRpslObject()
    {
        return (this.rpslObject);
    }

    public void setRpslObject(String r)
    {
        this.rpslObject = r;
    }
    
    public String getRpslClassName()
    {   if (rpslClassName == null) return("route");
        return (this.rpslClassName);
    }

    public void setRpslClassName(String r)
    {
        this.rpslClassName = r;
    }

    public String getRpslInverseAttributeName()
    {   if (rpslInverseAttributeName == null) return("mnt-by");
        return (this.rpslInverseAttributeName);
    }

    public void setRpslInverseAttributeName(String r)
    {
        this.rpslInverseAttributeName = r;
    }
    
    public String getRpslFilterExpression()
    {   if (rpslFilterExpression == null) return("-none-");
        return (this.rpslFilterExpression);
    }

    public void setRpslFilterExpression(String r)
    {
        this.rpslFilterExpression = r;
    }
    
        public String getServerProfileName()
    {   if (serverProfileName == null) return("default");
        return (this.serverProfileName);
    }

    public void setServerProfileName(String r)
    {
        this.serverProfileName = r;
    }

    public String getMymaints1()
    {
        return (this.mymaints1);
    }

    public void setMymaints1(String m)
    {
        this.mymaints1 = m;
    }

    /**
     * Return the results.
     */
    public String getResults()
    {
        return (this.results);
    }

    /**
     * Set the results.
     *
     * @param tm The new results
     */
    public void setResults(String res)
    {
        this.results = res;
    }

    /**
     * Return the generated command.
     */
    public String getCommand()
    {
        return (this.command);
    }


    /**
     * Set the command.
     *
     * @param tm The new comand
     */
    public void setCommand(String cmd)
    {
        this.command = cmd;
    }



    public String getCommandIndex()
    {
        return (this.commandIndex);
    }


    public void setCommandIndex(String ci)
    {
        this.commandIndex = ci;
    }

    // --------------------------------------------------------- Public Methods


    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.objectSet      = null;
        this.membership     = null;
        this.rpslObject     = null;
        this.mymaints1      = null;
//        this.mymaints2 = null;
        this.results        = null;
        this.commandIndex   = null;
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((tier == null) || (tier.length() < 1))
        {
            errors.add("tier", new ActionError("error.tier.required"));
        }

        if ((tiermaint == null) || (tiermaint.length() < 1))
        {
            errors.add("tiermaint", new ActionError("error.tiermaint.required"));
        }
*/
        return errors;
    }
}