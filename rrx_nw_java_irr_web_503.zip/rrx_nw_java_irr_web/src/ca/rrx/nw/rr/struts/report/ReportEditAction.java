package ca.rrx.nw.rr.struts.report;

import ca.rrx.nw.rr.Constants;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class ReportEditAction extends Action
{

    private String command;

    {
        command = null;
    }


    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String results;
        String rpslEdit;
        String commandIndex;
        HttpSession session;
        ReportEditForm reportEditForm;

        results         = null;
        commandIndex    = null;
        rpslEdit        = ((ReportEditForm) form).getRpslEdit();
        session         = request.getSession();


       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        reportEditForm         = (ReportEditForm)session.getAttribute("reportEditForm");

        if(request.getParameter("submitIrr") != null)
        {
            commandIndex = "submitIrr";
        }
        else if(request.getParameter("submitSaveToFile") != null)
        {
            commandIndex = "submitSaveToFile";
        }
        else if(request.getParameter("submitLogout") != null)
        {
            commandIndex = "submitLogout";
        }

        // Save form to session
        session.setAttribute(Constants.REPORT_EDIT_KEY, form);

        if (servlet.getDebug() >= 1)
        {
            servlet.log("ReportEditAction: Report '" + commandIndex + 
                      "' in session " + session.getId());
        }

/*
        if(commandIndex.equals("submitIrr"))
        {
            return (mapping.findForward("report_submit_confirmation"));
        }
*/

        if(request.getParameter("submitIrr") != null)
        {
//            reportEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            reportEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            session.setAttribute("rpslToSubmit", request.getParameter("rpslToSubmit"));
            return (mapping.findForward("irr_submit_confirmation"));
        }

        if(commandIndex.equals("submitSaveToFile"))
        {
            reportEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            // write to file
            // redirect to reportEdit.jsp, w/c opens new window if created?
            return (mapping.findForward("report_edit"));

        }
        else if(commandIndex.equals("submitLogout"))
        {
            return (mapping.findForward("signout_success"));
        }

        // Forward control to URI specified in struts-config.xml
        return (mapping.findForward("report_edit"));
    }
}