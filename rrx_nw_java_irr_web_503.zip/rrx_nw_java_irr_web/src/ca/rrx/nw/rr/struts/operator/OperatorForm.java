package ca.rrx.nw.rr.struts.operator;


import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;


public final class OperatorForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List defaultSessionProfileNames;
    protected List thisSessionProfileNames;
    protected List stateProvinceNames;
    protected List countryNames;
    protected List languageNames;

    protected String currentMaintainerId;
    
    protected String operatorLoginName;
    protected Object operatorId;
    protected Object defaultSessionId;
    protected String maintainerCodes;
    protected String password;
    protected String nicHandle;
    protected String firstName;
    protected String lastName;
    protected String streetName1;
    protected String streetName2;
    //protected String streetName3;
    protected String city;
    protected String stateProvince;
    protected String postalCode;
    protected String country;
    protected String telephone;
    protected String defaultSession;
    protected String thisSession;
    protected String email;
    protected String languageSelected;
    protected String lang;
    protected String remarks;
    protected String rpslPerson;
    protected String rpslMaintainer;
    protected String rpslKeyCert;
    protected String rpslRole;

    protected String command;
    protected String commandIndex;
    protected String rpslToSubmit;    // contains either person, maintainer or role rpsl
    protected String results;

    // ----------------------------------------------------------- Properties

    
    public List getDefaultSessionProfileNames() {
        return defaultSessionProfileNames;
    }
    
    public void setDefaultSessionProfileNames(List defaultSessionProfileNames) {        
        this. defaultSessionProfileNames = new ArrayList();
        this. defaultSessionProfileNames.addAll(defaultSessionProfileNames);
    }
    
   
    public List getThisSessionProfileNames(){
        return thisSessionProfileNames;
    }
    
    public void setThisSessionProfileNames(List thisSessionProfileNames) {
        this. thisSessionProfileNames = new ArrayList();
        this. thisSessionProfileNames.addAll(thisSessionProfileNames);
    }
    
    public List getStateProvinceNames(){
        return stateProvinceNames;
    }
    
    public void setStateProvinceNames(List stateProvinceNames) {
        this. stateProvinceNames = stateProvinceNames;
    }
        
    public List getCountryNames(){
        return countryNames;
    }
    
    public void setCountryNames(List countryNames) {
        this. countryNames = countryNames;
    }
        
    public List getLanguageNames(){
        languageNames = new ArrayList();
        languageNames.add("EN");
        languageNames.add("FR");
        return languageNames;
    }
    
    public void setLanguageNames(List languageNames) {
        this. languageNames = languageNames;
    }
    
    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public Object getDefaultSessionId() {
        return defaultSessionId;
    }
    
    public void setDefaultSessionId(Object defaultSessionId) {
        this.defaultSessionId = defaultSessionId;
    }
    
    public String getMaintainerCodes() {
        return maintainerCodes;
    }
    
    public void setMaintainerCodes(String maintainerCodes) {
        this.maintainerCodes = maintainerCodes;
    }
    
    public String getCurrentMaintainerId() {
        return currentMaintainerId;
    }
    
    public void setCurrentMaintainerId(String currentMaintainerId) {
        this.currentMaintainerId = currentMaintainerId;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getNicHandle(){
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle){
        this.nicHandle = nicHandle;
    }
    
    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }   
    
    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }   
    
    public String getStreetName1() {
        return streetName1;
    }
        
    public void setStreetName1(String streetName1){
        this.streetName1 = streetName1;
    }
    
    public String getStreetName2() {
        return streetName2;
    }
        
    public void setStreetName2(String streetName2){
        this.streetName2 = streetName2;
    }   
/*        
    public String getStreetName3() {
        return streetName3;
    }
        
    public void setStreetName3(String streetName3){
        this.streetName3 = streetName3;
    }   
*/    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city){
        this.city = city;
    }
    
    public String getStateProvince() {
        return stateProvince;
    }
    
    public void setStateProvince(String stateProvince){
        this.stateProvince = stateProvince;
    }
   
    public String getPostalCode() {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode){
        this.postalCode = postalCode;
    }
  
    public String getCountry(){
        return country;
    }
    
    public void setCountry(String country){
        this.country = country;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }   
   
    public String getTelephone(){
        return telephone;
    }
        
    public void setTelephone(String telephone){
        this.telephone = telephone;
    }   
    
    public String getDefaultSession(){
            return defaultSession;
    }
        
    public void setDefaultSession(String defaultSession){
        this.defaultSession = defaultSession;
    }   
    
    public String getThisSession(){
        return thisSession;
    }
        
    public void setThisSession(String thisSession){
        this.thisSession = thisSession;
    }   
      
    public String getLang() {
        return lang;
    }
    
    public void setLang(String lang) {
        this.lang = lang;
    }
    
    public String getLanguageSelected() {
        return languageSelected;
    }
    
    public void setLanguageSelected(String languageSelected) {
        this.languageSelected = languageSelected;
    }
    
    public String getRemarks(){
        return remarks;
    }
            
    public void setRemarks(String remarks){
        this.remarks = remarks;
    }
    
    public String getRpslPerson(){
        return rpslPerson;
    }
            
    public void setRpslPerson(String rpslPerson){
        this.rpslPerson = rpslPerson;
    }   

    public String getRpslMaintainer(){
        return rpslMaintainer;
    }
            
    public void setRpslMaintainer(String rpslMaintainer){
        this.rpslMaintainer = rpslMaintainer;
    }
    
    public String getRpslKeyCert(){
        return rpslKeyCert;
    }
            
    public void setRpslKeyCert(String rpslKeyCert){
        this.rpslKeyCert = rpslKeyCert;
    }

    public String getRpslRole(){
        return rpslRole;
    }
            
    public void setRpslRole(String rpslRole){
        this.rpslRole = rpslRole;
    }

    public String getResults(){
        return (this.results);
    }

    public void setResults(String results){
        this.results = results;
    }


    public String getCommand(){
        return (this.command);
    }

    public void setCommand(String command){
        this.command = command;
    }


    public String getRpslToSubmit(){
        return (this.rpslToSubmit);
    }

    public void setRpslToSubmit(String rpslToSubmit){
        this.rpslToSubmit = rpslToSubmit;
    }

    public String getCommandIndex(){
        return (this.commandIndex);
    }

    public void setCommandIndex(String commandIndex){
        this.commandIndex = commandIndex;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.firstName = null;
        this.lastName = null;
        this.streetName1 = null;
        this.streetName2 = null;
      //  this.streetName3 = null;
        this.city = null;
        this.stateProvince = null;
        this.postalCode = null;
        this.country = null;
        this.telephone = null;
        this.defaultSession = null;
        this.thisSession = null;
        this.password = null;
        this.email = null;
        this.languageSelected = null;
        this.lang = null;
        this.remarks = null;
        this.rpslPerson = null;
        this.rpslRole = null;

        this.results = null;
        this.command = null;
        this.commandIndex = null;
    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((firstName == null) || (firstName.length() < 1))
        {
            errors.add("firstName", new ActionError("error.firstName.required"));
        }

        if ((lastName == null) || (lastName.length() < 1))
        {
            errors.add("lastName", new ActionError("error.lastName.required"));
        }


       if ((streetName1 == null) || (streetName1.length() < 1))
        {
            errors.add("streetName1", new ActionError("error.streetName1.required"));
        }

        if ((city == null) || (city.length() < 1))
        {
            errors.add("city", new ActionError("error.city.required"));
        }

        if ((stateProvince == null) || (stateProvince.length() < 1))
        {
            errors.add("stateProvince", new ActionError("error.stateProvince.required"));
        }

        if ((postalCode == null) || (postalCode.length() < 1))
        {
            errors.add("postalCode", new ActionError("error.postalCode.required"));
        }

        if ((country == null) || (country.length() < 1))
        {
            errors.add("country", new ActionError("error.country.required"));
        }

        if ((telephone == null) || (telephone.length() < 1))
        {
            errors.add("telephone", new ActionError("error.telephone.required"));
        }

        if ((defaultSession == null) || (defaultSession.length() < 1))
        {
            errors.add("defaultSession", new ActionError("error.defaultSession.required"));
        }
        
        if ((thisSession == null) || (thisSession.length() < 1))
        {
            errors.add("thisSession", new ActionError("error.thisSession.required"));
        }

       if ((password == null) || (password.length() < 1))
        {
            errors.add("password", new ActionError("error.password.required"));
        }
        
        if ((email == null) || (email.length() < 1))
        {
            errors.add("email", new ActionError("error.email.required"));
        }
        
        if ((languageSelected == null) || (languageSelected.length() < 1))
        {
            errors.add("languageSelected", new ActionError("error.languageSelected.required"));
        }
        
        if ((language == null) || (language.length() < 1))
        {
            errors.add("language", new ActionError("error.language.required"));
        }
        
        if ((rpslPerson == null) || (rpslPerson.length() < 1))
        {
            errors.add("rpslPerson", new ActionError("error.rpslPerson.required"));
        }
        
      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("OperatorForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("OperatorForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("OperatorForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("OperatorForm error: " + pce);
        }
        return null;
    }
}