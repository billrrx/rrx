package ca.rrx.nw.rr.struts.policy;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.util.Collection;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;


import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class PolicyGenerationAction extends Action
{

    private String filepath = Constants.FULL_BASE_DIR + "/tmp/";

    // --------------------------------------------------------- Public Methods

    /**
     * Process the specified HTTP request, and create the corresponding HTTP
     * response (or forward to another web component that will create it).
     * Return an <code>ActionForward</code> instance describing where and how
     * control should be forwarded, or <code>null</code> if the response has
     * already been completed.
     *
     * @param mapping The ActionMapping used to select this instance
     * @param actionForm The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String routerManufacturer;
        String fromToAutNumSelect;
        String rtrOneIp;
        String p_type;
        String toFromAutNumSelect;
        String rtrTwoIp;
        String toFromAutNumTextArea1;
        String toFromAutNumTextArea2;

        String newline;
        String filename;
        int randomNumber;
        Integer randInt;
        String temp;
        String templateFilename;
        String templateFileContents;    // @RtConfig template
        String autNumFilename;          // name of file containing rpsl objects used to generate policy
        String autNumFileContents;      // two aut-num rpsl objects combined into one string
        String policyResultsFilename;   // name of file holding the results of policy generation
        String policyResultsFullFilename;

        String results;             // stores results of executed command
        String commandIndex;        // string indicating which command was executed
        String command;             // stores command to be executed

        Iterator it;
        HttpSession session;
        int counter;

        templateFilename            = null;
        policyResultsFullFilename   = null;
        policyResultsFilename       = null;
        autNumFilename              = null;
        filename                    = null;
        templateFileContents        = null;
        autNumFileContents          = null;

        results             = null;
        commandIndex        = null;
        command             = null;

        routerManufacturer      = ((PolicyGenerationForm) form).getRouterManufacturer();
        fromToAutNumSelect      = ((PolicyGenerationForm) form).getFromToAutNumSelect();
        rtrOneIp                = ((PolicyGenerationForm) form).getRtrOneIp();
        p_type                  = ((PolicyGenerationForm) form).getP_type();
        toFromAutNumSelect      = ((PolicyGenerationForm) form).getToFromAutNumSelect();
        rtrTwoIp                = ((PolicyGenerationForm) form).getRtrTwoIp();
        toFromAutNumTextArea1   = ((PolicyGenerationForm) form).getToFromAutNumTextArea1();
        toFromAutNumTextArea2   = ((PolicyGenerationForm) form).getToFromAutNumTextArea2();

        // save form to session
        session = request.getSession();

       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        session.setAttribute(Constants.POLICY_GENERATION_KEY, form);

        if(request.getParameter("submit1") != null)
        {
            commandIndex    = "submit1";
        }
        else if(request.getParameter("submit2") != null)
        {
            commandIndex    = "submit2";
        }
        else if(request.getParameter("submit3") != null)
        {
            commandIndex    = "submit3";
        }
        else
        {
            // either drop down menu was changed
            if(request.getParameter("autNumChanged").equals("fromToAutNum"))
            {
                // $fix$ hardcoded WHOIS_COMMAND(skip for now, page not currently included)
                command = Constants.WHOIS_COMMAND + " -T aut-num" + " " + fromToAutNumSelect;
                commandIndex    = "fromToAutNumSelect";
            }
            else if(request.getParameter("autNumChanged").equals("toFromAutNum"))
            {
                // $fix$ hardcoded WHOIS_COMMAND (skip for now, page not currently included)
                command = Constants.WHOIS_COMMAND + " -T aut-num" + " " + toFromAutNumSelect;
                commandIndex    = "toFromAutNumSelect";
            }
        }


        if(commandIndex.equals("submit1"))
        {
            randomNumber = (int)(Math.random() * 100000);
            randInt = new Integer(randomNumber);
            filename = "irrPolGen_autnum_" + randInt.toString() + ".txt";

            if((rtrOneIp == null) || (rtrOneIp.trim().equals("")))
            {
                rtrOneIp = "1.1.1.1";
            }

            if((rtrTwoIp == null) || (rtrTwoIp.trim().equals("")))
            {
                rtrTwoIp = "2.2.2.2";
            }

            autNumFilename = filepath + filename;

            autNumFileContents = toFromAutNumTextArea1 
                + Constants.NEW_LINE + Constants.NEW_LINE + Constants.NEW_LINE 
                + toFromAutNumTextArea2 + Constants.NEW_LINE;

            // write both aut-num objects to file
            writeTemplateFile(autNumFilename, autNumFileContents);

            templateFilename = filepath + "irrPolGen_template_" + randInt.toString() + ".txt";
            //$FIX THIS$ - should read RtConfig template from files instead of generating (skip for now, page not currently included)
            templateFileContents = "@RtConfig " + p_type + " " + fromToAutNumSelect + " " + rtrOneIp + " " + toFromAutNumSelect + " " + rtrTwoIp;
            writeTemplateFile(templateFilename, templateFileContents);


            // generate command for invoking RtConfig
            // $VERIFY$ - check the syntax
            command = Constants.FULL_BASE_DIR + Constants.POLICYGENERATION_SCRIPT1
                            + " " + autNumFilename + " " + routerManufacturer + " " + templateFilename;

///usr/bin/RtConfig -f $AUTFILE$ -p 43 -protocol bird -config $ROUTERMFTR$ < $TEMPLATEFILE$

            // invoke RtConfig with specified template file
            results = exec(command);


            filename = "irrPolGen_results_" + randInt.toString() + ".txt";

            policyResultsFullFilename = filepath + filename;
            writeTemplateFile(policyResultsFullFilename, results);

            ((PolicyGenerationForm)form).setCommand(command);
            ((PolicyGenerationForm)form).setCommandIndex(commandIndex);
            ((PolicyGenerationForm)form).setPolicyResultsFilename(filename);
            ((PolicyGenerationForm)form).setResults(results);

            ((PolicyGenerationForm)form).setToFromAutNumResults(toFromAutNumTextArea2);
            ((PolicyGenerationForm)form).setFromToAutNumResults(toFromAutNumTextArea1);
        }
        else if (commandIndex.equals("submit2"))
        {
            // confirm for submission to irr, using fromToAutNum
            ((PolicyGenerationForm)form).setAutNumSubmitToIrr(toFromAutNumTextArea1);

            ((PolicyGenerationForm)form).setCommand(command);
            ((PolicyGenerationForm)form).setCommandIndex(commandIndex);
            return (mapping.findForward("policy_generation_submit_confirmation"));
        }
        else if (commandIndex.equals("submit3"))
        {
            // confirm for submission to irr, using toFromAutNum
            ((PolicyGenerationForm)form).setAutNumSubmitToIrr(toFromAutNumTextArea2);

            ((PolicyGenerationForm)form).setCommand(command);
            ((PolicyGenerationForm)form).setCommandIndex(commandIndex);
            return (mapping.findForward("policy_generation_submit_confirmation"));
        }
        else
        {
            // one of the aut-num drop-downs changed
            results = exec(command);

            if (commandIndex.equals("fromToAutNumSelect"))
            {
                ((PolicyGenerationForm)form).setToFromAutNumResults(toFromAutNumTextArea2);

                ((PolicyGenerationForm)form).setFromToAutNumResults(results);
            }
            else if (commandIndex.equals("toFromAutNumSelect"))
            {
                ((PolicyGenerationForm)form).setFromToAutNumResults(toFromAutNumTextArea1);

                ((PolicyGenerationForm)form).setToFromAutNumResults(results);
            }
        }

        ((PolicyGenerationForm)form).setCommand(command);
        ((PolicyGenerationForm)form).setCommandIndex(commandIndex);

        // Forward control to the success URI specified in struts-config.xml
        return (mapping.findForward("policy_generation_success"));
    }


    private void writeTemplateFile(String filename, String templateFileContents)
    {
        try
        {
            File file;
            FileOutputStream fos;
            StringBuffer stringBuffer;
            String temp;

            temp = templateFileContents;
            file = new File(filename);
            fos = new FileOutputStream(file);

            fos.write(temp.getBytes());
        }
        catch(IOException e)
        {
            //Debug.println("ERROR: PolicyGenerationAction.java");
        }
    }


    /**
     * Accepts a string that is executed as an external command.
     *
     */
    public String exec(String cmd)
    {
        StringBuffer stringBuffer;
        String newline;

        stringBuffer    = new StringBuffer();
        newline         = System.getProperty("line.separator");


        try
        {
            Process process;
            InputStream in;
            BufferedReader reader;
            String line;
            int c;

            process = Runtime.getRuntime().exec(cmd);
            in      = process.getInputStream();
            reader  = new BufferedReader(new InputStreamReader(in));
            c       = 0;

            do
            {
                line = reader.readLine();

                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }

                c++;
            }
            while(line != null);

            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Error in PolicyGenerationAction.java");
        }

        return(new String(stringBuffer));
    }


    /**
     * Accepts a string with lines separated by '\n' and places each
     * line into a separate element of a string array.
     *
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        trimArray(temp);

        return((String[])temp.toArray(new String[]{}));
    }


    /**
     * Accepts an ArrayList of strings and removes empty lines
     * from the start and end of the List.
     *
     */
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;

        idxRemove = new int[100];
        count = 0;

        if(!t.isEmpty())
        {
            for(int i = 0 ; i < t.size() ; i++)
            {
               String s;

               s = t.get(i).toString().trim();

               if(s.length() == 0)
               {  
                   idxRemove[count] = i;
                   count++;
               }
               else
               {
                   break;
               }
            }

            for(int i = count ; i > 0 ; i--)
            {
                  t.remove(0);
            }
        }
    }
}