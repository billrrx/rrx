package ca.rrx.nw.rr.struts.operator;

import ca.rrx.nw.rr.Constants;

import java.io.IOException;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.Address;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

import ca.rrx.nw.rr.util.Debug;

public final class OperatorAction extends Action
{
         
    public ActionForward perform(ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException
    {
        OperatorWebImpl operatorWebImpl;
        ServerWebImpl serverWebImpl;
        
        //get the session
        HttpSession session  = request.getSession();


       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        //get the session beans from the session - Bill R
        
        if (session.getAttribute("operatorWebImpl") != null) {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null) {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }
        //set to copy of bean
        OperatorForm operatorForm = ((OperatorForm) form);
        OperatorForm operatorFormBean;
        operatorFormBean = (OperatorForm)session.getAttribute("operatorForm");
        
        Locale locale        = (Locale)session.getAttribute("language");

        String operatorLoginName = "operator";
        Object operatorId = new Integer(0);
        Object operatorSessionId = new Integer(0);
        String operatorSessionName = "session";
        
        if ((String)session.getAttribute("MM_Username") != null) operatorLoginName = (String)session.getAttribute("MM_Username");
        OperatorModel operatorModel = operatorWebImpl.getModel(operatorLoginName);
        OperatorInformation operatorInformation = operatorModel.getOperatorInformation();
       
        operatorSessionId = operatorInformation.getDefaultSessionId();
        
        OperatorSessions operatorSessions = operatorModel.getOperatorSessions();
        operatorId = operatorSessions.getOperatorId();
        OperatorSession currentOperatorSession = operatorSessions.getOperatorSessionById(operatorSessionId);
        String currentOperatorSessionName = currentOperatorSession.getSessionProfileName();
        
        ServerModel serverModel = serverWebImpl.getModel(currentOperatorSession.getPrimaryServerProfileId());
        Servers servers = serverModel.getServers();
        Server primaryServer = servers.getServerById(currentOperatorSession.getPrimaryServerProfileId());
        Server secondaryServer = servers.getServerById(currentOperatorSession.getSecondaryServerProfileId());
        
        String submitUpdate = request.getParameter("submitUpdate");
        String submitSession = request.getParameter("submitSession");
        String languageSelected = request.getParameter("languageSelected");
        String submitIrr = request.getParameter("submitIrr");
        String submitIrrKeyCert = request.getParameter("submitIrrKeyCert");

        if  (submitUpdate != null)
        {   
            OperatorInformation modifiedInformation = operatorModel.getOperatorInformation();
            Address modifiedAddress =  modifiedInformation.getAddress();
            
            //overwrite the fresh ones with the form stuff - Bill R
            //Debug.println("OperatorAction- languageSelected: " + languageSelected);
            operatorForm.setLang(languageSelected);
            copyNotNullObjectProperties(modifiedInformation, operatorForm);
            copyNotNullObjectProperties(modifiedAddress, operatorForm);
            
            //update the database
            operatorWebImpl.update(modifiedInformation);

            //flag beans model to null so reloads the database on findForward
            operatorModel = null;
            
            return (mapping.findForward("operator_profile_success"));
        }
        
      
        //set the default operator session
        if  ((submitSession != null) && submitSession.equals("Set"))
        {
            
            //get the new default session name
            String newDefaultSessionName = request.getParameter("defaultSession");
            
            //get the new default session id
            Object newDefaultSessionId =  operatorSessions.getSessionProfileId(newDefaultSessionName);
            //Debug.println("OperatorAction: submitSession: newDefaultSessionName = " + newDefaultSessionName + "newDefaultSessionId = " + newDefaultSessionId);
            //not necessary but makes easier reading
            OperatorInformation modifiedInformation = operatorModel.getOperatorInformation();
          
            //set the parameter in the model from the form
            modifiedInformation.setDefaultSessionId(newDefaultSessionId);
            
            //update the database
            operatorWebImpl.update(modifiedInformation);
            
            //flag beans model to null so reloads the database on findForward
            operatorModel = null;
            
            //change bean for rest of this session
            session.setAttribute(Constants.DEFAULT_OPERATOR_SESSION_KEY, newDefaultSessionId);
    
            
            return (mapping.findForward("operator_profile_success"));
        }
        //load this operator session only
        if ((submitSession != null) && submitSession.equals("Load"))
        {
            //get the new this session name
            String newThisSessionName = request.getParameter("thisSession");

            //get the new this session id
            Object newThisSessionId =  operatorSessions.getSessionProfileId(newThisSessionName);
            currentOperatorSession = operatorSessions.getOperatorSessionById(newThisSessionId);
            primaryServer = servers.getServerById(currentOperatorSession.getPrimaryServerProfileId());
            secondaryServer = servers.getServerById(currentOperatorSession.getSecondaryServerProfileId());
           //change value beans for this session
           session.setAttribute(Constants.THIS_OPERATOR_SESSION_KEY, newThisSessionId);
           session.setAttribute(Constants.USERSESSION_KEY, newThisSessionName);
           session.setAttribute(Constants.USERMAINT_KEY, currentOperatorSession.getMaintainerCode());
           session.setAttribute(Constants.PRIMARY_SERVER, primaryServer.getServerProfileName());
           
            return (mapping.findForward("operator_profile_success"));
        }
        //send the contents of the rpslPerson to irr
        if ((submitIrr != null) && submitIrr.equals("Submit Person to IRR"))
        {
//            session.setAttribute("operator_profile_rpslPerson",rpslPerson);
//            operatorModel.updateRpslObject(operatorForm.getRpslPerson());

//            ((OperatorForm)form).setCommandIndex("person");
//            ((OperatorForm)form).setRpslToSubmit(((OperatorForm)form).getRpslPerson());
//            ((OperatorForm)form).setRpslToSubmit("test123");
//            operatorFormBean.setRpslToSubmit("test123");
            // Save form to session
            session.setAttribute(Constants.OPERATOR_PROFILE_KEY, form);
            session.setAttribute("rpslToSubmit", request.getParameter("rpslPerson"));
//            session.setAttribute(Constants.OPERATOR_PROFILE_KEY, form);
//            return (mapping.findForward("operator_profile_success"));
            return (mapping.findForward("irr_submit_confirmation"));



//            return (mapping.findForward("profile_submit_confirmation"));
        }

        //send the contents of the rpslMaintainer to irr
        if ((submitIrr != null) && submitIrr.equals("Submit Maintainer to IRR"))
        {
//            operatorModel.updateRpslObject(operatorForm.getRpslRole())
//            ((OperatorForm)form).setCommandIndex("maintainer");
//            ((OperatorForm)form).setRpslToSubmit(((OperatorForm)form).getRpslMaintainer());
            // Save form to session
            session.setAttribute(Constants.OPERATOR_PROFILE_KEY, form);
            session.setAttribute("rpslToSubmit", request.getParameter("rpslMaintainer"));
//            return (mapping.findForward("profile_submit_confirmation"));
            return (mapping.findForward("irr_submit_confirmation"));
        }
        
        //send the contents of the rpslKeyCert to irr
        if (submitIrrKeyCert != null)
        {
//            ((OperatorForm)form).setCommandIndex("maintainer");
//            ((OperatorForm)form).setRpslToSubmit(((OperatorForm)form).getRpslKeyCert());
            // Save form to session
            session.setAttribute(Constants.OPERATOR_PROFILE_KEY, form);
            session.setAttribute("rpslToSubmit", request.getParameter("rpslKeyCert"));
//            return (mapping.findForward("profile_submit_confirmation"));
            return (mapping.findForward("irr_submit_confirmation"));
        }

        //send the contents of the rpslRole to irr
        if ((submitIrr != null) && submitIrr.equals("Submit Role to IRR"))
        {
//            operatorModel.updateRpslObject(operatorForm.getRpslRole())
//            ((OperatorForm)form).setCommandIndex("role");
//            ((OperatorForm)form).setRpslToSubmit(((OperatorForm)form).getRpslRole());
            // Save form to session
            session.setAttribute(Constants.OPERATOR_PROFILE_KEY, form);
            session.setAttribute("rpslToSubmit", request.getParameter("rpslRole"));
//            return (mapping.findForward("profile_submit_confirmation"));
            return (mapping.findForward("irr_submit_confirmation"));
        }
        
         if  (languageSelected != null)
        {
            if(request.getParameter("languageSelected") != null)
            {
                if(request.getParameter("languageSelected").equals("EN"))
                {
                    locale = new Locale("en", "CA");
                    session.setAttribute("userLocale",locale);
                }
                else if(request.getParameter("languageSelected").equals("FR"))
                {
                    locale = new Locale("fr", "CA");
                    session.setAttribute("userLocale",locale);
                }
                operatorForm = (OperatorForm) session.getAttribute("operatorForm");
                operatorForm.setLang(request.getParameter("languageSelected"));
            }
             return (mapping.findForward("operator_profile_success"));
        }       
        
        if (servlet.getDebug() >= 1)
        {
            servlet.log("OperatorAction: Operator '" + operatorLoginName +
            "' in session " + session.getId());
        }
        
        
        return (mapping.findForward("operator_profile_success"));
        

    }
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {

                String name = fromObjectDescriptors[i].getName();



                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);

                Debug.print("OperatorAction: name=" + name);
                //Debug.println(" [" + value + "]");

                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        }
    }
}