package ca.rrx.nw.rr.struts.admin;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;

import java.util.Locale;
import java.util.Calendar;
import java.util.GregorianCalendar;

import java.text.NumberFormat;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.Operator;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;

import ca.rrx.nw.rr.control.web.ServerWebImpl;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;


public final class AdminMaintAction extends Action
{

    public ActionForward perform(ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException
    {
        OperatorWebImpl 	operatorWebImpl;
        ServerWebImpl 		serverWebImpl;
        
        //get the session
        HttpSession 		session  	= request.getSession();


        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        //get the session beans from the session - Bill R
        if (session.getAttribute("operatorWebImpl") != null)
        {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null) 
        {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        }
        else
        {  //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }
        //set to copy of bean
        AdminMaintForm 	adminMaintForm	= ((AdminMaintForm) form);
        Locale 			locale        		= (Locale)session.getAttribute("language");

        String 			operatorLoginName 	= "operator";
        Object 			operatorId 		= new Integer(0);
        Object 			operatorSessionId 	= new Integer(0);
        String 			operatorSessionName 	= "session";
        
        if ((String)session.getAttribute("MM_Username") != null)
        {
            operatorLoginName = (String)session.getAttribute("MM_Username");
        }
        else
        {
            return (mapping.findForward("main"));
        }

        OperatorModel 		operatorModel 		= operatorWebImpl.getModel(operatorLoginName);
        OperatorInformation 	operatorInformation 	= operatorModel.getOperatorInformation();
       
			operatorSessionId 	= operatorInformation.getDefaultSessionId();
        
        OperatorSessions 	operatorSessions 	= operatorModel.getOperatorSessions();
        			operatorId 		= operatorSessions.getOperatorId();
        OperatorSession 	currentOperatorSession 	= operatorSessions.getOperatorSessionById(operatorSessionId);
        String 			currentOperatorSessionName = currentOperatorSession.getSessionProfileName();
        

        String           	submitBackup           = request.getParameter("submitBackup");
        
        Operator 		selectedOperator;
        OperatorInformation 	selectedOperatorInformation;
        
        if (operatorModel.getOperators().getOperatorByFullName(request.getParameter("operatorFullName")) != null)
        {
            selectedOperator = operatorModel.getOperators().getOperatorByFullName(request.getParameter("operatorFullName"));
            selectedOperatorInformation = selectedOperator.getOperatorInformation();
        }
        else
        {
            selectedOperator = new Operator();
            selectedOperatorInformation = new  OperatorInformation();  
        }
        /* ---------------------------------------------------
        *   Action Processing  - Maintainer Code Commands - RRX NW
        *---------------------------------------------------*/


        
        if  (submitBackup != null) //backs up the sql database for the irr web interface
        { 
            
        String shellFilePath = Constants.FULL_BASE_DIR + "/data/database/shellCmds/rrxBackup.sh";
        
        String zipFileName = generateFileName(generateTimeStamp()) + ".zip";
        
        String zipFilePath = Constants.FULL_BASE_DIR + "/data/database/backupDataZip/" + zipFileName;
        
        String zipFileUrl = "/data/database/backupDataZip/" + generateFileName(generateTimeStamp()) + ".zip";
        
        String dataBaseReplicasPath = Constants.FULL_BASE_DIR + "/data/database/backupData/*.*";
        
        String dataBaseBackupCmdPath = Constants.FULL_BASE_DIR + "/data/database/sqlCmds/IRRWEB_backupDB.sql";

        String backupCommands = "#!/bin/sh\n" 
                                + "# do not modify - this is written from AdminMaintAction.java - change the source if necessary \n"
                                + "# if errors out on write permission check SELinux, try: audit2allow -a -M policy  RRX Network April 2015\n"
                                + "rm -f " + dataBaseReplicasPath + "\n" 
                                + Constants.SHELL_SQL_KEY + " < " + dataBaseBackupCmdPath + "\n"
                                + "zip " + zipFilePath + " " + dataBaseReplicasPath + "\n";

        writeFile(shellFilePath, backupCommands);

        String setExecuteMode = executeCommandLine("chmod +x " + shellFilePath);

        String backupMessage = executeCommandLine("sh -c " + shellFilePath);
        
        ActionForward actionForward = new ActionForward();
        
        actionForward.setPath(zipFileUrl);
        
        actionForward.setName(zipFileName);
        
        actionForward.setRedirect(true);
        
        return actionForward;
            
        //return (mapping.findForward("administrator_maint_success"));
        }
        
     
        
        //**********
        
        if (servlet.getDebug() >= 1)
        {
            servlet.log("AdminMaintAction: Administrator '" + operatorLoginName +
            "' in session " + session.getId());
        }
        
        
        return (mapping.findForward("administrator_maint_success"));
        

    }
    
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            //System.out.println("OperatorWebImpl: Command Line Exec Error = " + e.getMessage());
            //Debug.println("OperatorWebImpl: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
    
    private String generateTimeStamp()
    {
        Calendar c;
        String newTimestamp;
        NumberFormat nf;
        String year;
        String month;
        String day;
        String hour;
        String minute;
        String second;

        int yearInt;
        int monthInt;
        int dayInt;
        int hourInt;
        int minuteInt;
        int secondInt;

        nf = NumberFormat.getInstance();
        c = new GregorianCalendar();

        yearInt     = c.get(Calendar.YEAR);
        monthInt    = c.get(Calendar.MONTH) + 1;
        dayInt      = c.get(Calendar.DAY_OF_MONTH);
        hourInt     = c.get(Calendar.HOUR_OF_DAY);
        minuteInt   = c.get(Calendar.MINUTE);
        secondInt   = c.get(Calendar.SECOND);

        nf.setMinimumIntegerDigits(2);

        year   = (new Integer(yearInt)).toString();
        month   = nf.format(monthInt);
        day     = nf.format(dayInt);
        hour    = nf.format(hourInt);
        minute  = nf.format(minuteInt);
        second  = nf.format(secondInt);

        newTimestamp = year +  ":" + month +  ":" + day + "-" + hour + ":" + minute + ":" +  second;

        return (newTimestamp);
    }



	private String generateFileName(String rawFileName)
    {
        String filename;
        StringBuffer newFilename;
        String searchPattern;
        String insideParens;

        int index;
        index = 0;
        insideParens = null;
        newFilename = new StringBuffer();

        filename = rawFileName;

        filename = filename.replace(' ','_');
        filename = filename.replace(':','_');
        filename = filename.replace('/','_');

        // search for characters followed by a '.' (revision)
        searchPattern       = new String("(((\\w)|-)+(\\.)+?)");

        try
        {
            RE regexpr;
            boolean matched;
            String replacement;
            int indexEnd;

            indexEnd        = 0;
            replacement     = null;
            regexpr         = new RE(searchPattern); // look for any word followed by a '.'
            matched         = regexpr.match(filename);

            if(matched)
            {
                String start;
                String end;

                insideParens = regexpr.getParen(1);

                index       = filename.indexOf(insideParens);
                indexEnd    = filename.indexOf(".");

                replacement = "" + insideParens.substring(0, insideParens.length());

                start = filename.substring(0, index);
                end = filename.substring(indexEnd + 1, filename.length());

                filename = start + replacement + end;
                
            }
            else
            {
            }
        }
        catch (RESyntaxException e)
        {
            System.out.println("error");
        }

        return (filename);
    }
        
    private void writeFile(String filename, String templateFileContents)
    {
        try
        {
            File file;
            FileOutputStream fos;
            StringBuffer stringBuffer;
            String temp;

            temp = templateFileContents;
            file = new File(filename);
            fos = new FileOutputStream(file);

            fos.write(temp.getBytes());
            
            fos.close();
            
        }
        catch(IOException e)
        {
            Debug.println("ERROR: AdminMaintAction:writeFile: " + e.getMessage());
        }
    }
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("AdminMaintAction:copyObjectProperties ", t);
            throw new ServletException("AdminMaintAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("AdminMaintAction:copyObjectProperties ", t);
            throw new ServletException("AdminMaintAction:copyObjectProperties ", t);
        }
    }
}