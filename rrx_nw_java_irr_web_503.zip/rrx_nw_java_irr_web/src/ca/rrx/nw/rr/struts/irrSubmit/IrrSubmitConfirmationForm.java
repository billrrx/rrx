package ca.rrx.nw.rr.struts.irrSubmit;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
//import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class IrrSubmitConfirmationForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List defaultSessionProfileNames;
    protected List thisSessionProfileNames;
    protected List stateProvinceNames;
    protected List countryNames;
    protected List languageNames;

    protected String currentMaintainerId;
    
    protected String operatorLoginName;
    protected Object operatorId;
    protected Object defaultSessionId;
    protected String maintainerCodes;
    protected String password;
    protected String nicHandle;
    protected String firstName;
    protected String lastName;
    protected String streetName1;
    protected String streetName2;
    //protected String streetName3;
    protected String city;
    protected String stateProvince;
    protected String postalCode;
    protected String country;
    protected String telephone;
    protected String defaultSession;
    protected String thisSession;
    protected String email;
    protected String languageSelected;
    protected String lang;
    protected String remarks;
    protected String rpslPerson;
    protected String rpslMaintainer;
    protected String rpslRole;

    protected String command;
    protected String commandIndex;
    protected String rpslToSend;    // contains either person, maintainer or role rpsl
    protected String results;
    protected String irrSubmitMessage;
    // ----------------------------------------------------------- Properties

    {
        irrSubmitMessage = "";
    }

    public IrrSubmitConfirmationForm()
    {
    }
    
    public List getDefaultSessionProfileNames() {
        return defaultSessionProfileNames;
    }
    
    public void setDefaultSessionProfileNames(List defaultSessionProfileNames) {        
        this. defaultSessionProfileNames = new ArrayList();
        this. defaultSessionProfileNames.addAll(defaultSessionProfileNames);
    }
    
   
    public List getThisSessionProfileNames(){
        return thisSessionProfileNames;
    }
    
    public void setThisSessionProfileNames(List thisSessionProfileNames) {
        this. thisSessionProfileNames = new ArrayList();
        this. thisSessionProfileNames.addAll(thisSessionProfileNames);
    }
    
    public List getStateProvinceNames(){
        return stateProvinceNames;
    }
    
    public void setStateProvinceNames(List stateProvinceNames) {
        this. stateProvinceNames = stateProvinceNames;
    }
        
    public List getCountryNames(){
        return countryNames;
    }
    
    public void setCountryNames(List countryNames) {
        this. countryNames = countryNames;
    }
        
    public List getLanguageNames(){
        languageNames = new ArrayList();
        languageNames.add("EN");
        languageNames.add("FR");
        return languageNames;
    }
    
    public void setLanguageNames(List languageNames) {
        this. languageNames = languageNames;
    }
    
    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public Object getDefaultSessionId() {
        return defaultSessionId;
    }
    
    public void setDefaultSessionId(Object defaultSessionId) {
        this.defaultSessionId = defaultSessionId;
    }
    
    public String getMaintainerCodes() {
        return maintainerCodes;
    }
    
    public void setMaintainerCodes(String maintainerCodes) {
        this.maintainerCodes = maintainerCodes;
    }
    
    public String getCurrentMaintainerId() {
        return currentMaintainerId;
    }
    
    public void setCurrentMaintainerId(String currentMaintainerId) {
        this.currentMaintainerId = currentMaintainerId;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getNicHandle(){
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle){
        this.nicHandle = nicHandle;
    }
    
    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }   
    
    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }   
    
    public String getStreetName1() {
        return streetName1;
    }
        
    public void setStreetName1(String streetName1){
        this.streetName1 = streetName1;
    }
    
    public String getStreetName2() {
        return streetName2;
    }
        
    public void setStreetName2(String streetName2){
        this.streetName2 = streetName2;
    }   
/*        
    public String getStreetName3() {
        return streetName3;
    }
        
    public void setStreetName3(String streetName3){
        this.streetName3 = streetName3;
    }   
*/    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city){
        this.city = city;
    }
    
    public String getStateProvince() {
        return stateProvince;
    }
    
    public void setStateProvince(String stateProvince){
        this.stateProvince = stateProvince;
    }
   
    public String getPostalCode() {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode){
        this.postalCode = postalCode;
    }
  
    public String getCountry(){
        return country;
    }
    
    public void setCountry(String country){
        this.country = country;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }   
   
    public String getTelephone(){
        return telephone;
    }
        
    public void setTelephone(String telephone){
        this.telephone = telephone;
    }   
    
    public String getDefaultSession(){
            return defaultSession;
    }
        
    public void setDefaultSession(String defaultSession){
        this.defaultSession = defaultSession;
    }   
    
    public String getThisSession(){
        return thisSession;
    }
        
    public void setThisSession(String thisSession){
        this.thisSession = thisSession;
    }   
      
    public String getLang() {
        return lang;
    }
    
    public void setLang(String lang) {
        this.lang = lang;
    }
    
    public String getLanguageSelected() {
        return languageSelected;
    }
    
    public void setLanguageSelected(String languageSelected) {
        this.languageSelected = languageSelected;
    }
    
    public String getRemarks(){
        return remarks;
    }
            
    public void setRemarks(String remarks){
        this.remarks = remarks;
    }
    
    public String getRpslPerson(){
        return rpslPerson;
    }
            
    public void setRpslPerson(String rpslPerson){
        this.rpslPerson = rpslPerson;
    }   

    public String getRpslMaintainer(){
        return rpslMaintainer;
    }
            
    public void setRpslMaintainer(String rpslMaintainer){
        this.rpslMaintainer = rpslMaintainer;
    }


    public String getRpslRole(){
        return rpslRole;
    }
            
    public void setRpslRole(String rpslRole){
        this.rpslRole = rpslRole;
    }

    public String getResults(){
        return (this.results);
    }

    public void setResults(String results){
        this.results = results;
    }


    public String getCommand(){
        return (this.command);
    }

    public void setCommand(String command){
        this.command = command;
    }


    public String getRpslToSend(){
        return (this.rpslToSend);
    }

    public void setRpslToSend(String rpslToSend){
        this.rpslToSend = rpslToSend;
    }

    public String getCommandIndex(){
        return (this.commandIndex);
    }

    public void setCommandIndex(String commandIndex){
        this.commandIndex = commandIndex;
    }

    public String getIrrSubmitMessage()
    {
        return(irrSubmitMessage);
    }

    public void setIrrSubmitMessage(String msg)
    {
        irrSubmitMessage = msg;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.firstName = null;
        this.lastName = null;
        this.streetName1 = null;
        this.streetName2 = null;
      //  this.streetName3 = null;
        this.city = null;
        this.stateProvince = null;
        this.postalCode = null;
        this.country = null;
        this.telephone = null;
        this.defaultSession = null;
        this.thisSession = null;
        this.password = null;
        this.email = null;
        this.languageSelected = null;
        this.lang = null;
        this.remarks = null;
        this.rpslPerson = null;
        this.rpslRole = null;

        this.results = null;
        this.command = null;
        this.commandIndex = null;
    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();

        return errors;
    }
}