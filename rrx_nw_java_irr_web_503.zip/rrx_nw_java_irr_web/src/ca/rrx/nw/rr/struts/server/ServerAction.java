package ca.rrx.nw.rr.struts.server;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.*;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.*;

// for default operator server profile
import ca.rrx.nw.rr.control.web.RpslWebImpl;
import ca.rrx.nw.rr.model.rpsl.model.*;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

// for java based ftp of irr dbs
import ca.rrx.nw.rr.util.ftp.FtpClient;
import ca.rrx.nw.rr.util.ftp.FtpReader;
import ca.rrx.nw.rr.util.ftp.FtpResponse;
import ca.rrx.nw.rr.util.ftp.FtpWriter;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.io.PrintStream;
import java.io.File;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

    /*---------------------------------------------------

     *---------------------------------------------------*/

public final class ServerAction extends Action
{
    
    public ActionForward perform(ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException
    {
        
        // Switch for Debug Mode (true/false)
        
        boolean debugMode = false;
        
        // Variable Declaration and Initalization
        
        String           submitNew                                  = request.getParameter("submitNew");
        String           submitSave                                 = request.getParameter("submitSave");
        String           submitSaveAs                               = request.getParameter("submitSaveAs");
        String           submitDelete                               = request.getParameter("submitDelete");
        String           serverProfileName                          = request.getParameter("serverProfileName");
        
        String           submitAuthoritativeSourceCodeAdd           = request.getParameter("submitAuthoritativeSourceCodeAdd");
        String           submitAuthoritativeSourceCodeDelete        = request.getParameter("submitAuthoritativeSourceCodeDelete");
        String           submitMirroredSourceCodeAdd                = request.getParameter("submitMirroredSourceCodeAdd");
        String           submitMirroredSourceCodeDelete             = request.getParameter("submitMirroredSourceCodeDelete");
        String           submitFtpDataFileRetrieve                  = request.getParameter("submitFtpDataFileRetrieve");
        String           submitFtpSerialFileRetrieve                = request.getParameter("submitFtpSerialFileRetrieve");
        String           submitFtpDataFileParse                     = request.getParameter("submitFtpDataFileParse");
        ServerForm       serverForm				    = (ServerForm) form;
        
        OperatorWebImpl  operatorWebImpl;
        String           operatorLoginName;
        ServerWebImpl    serverWebImpl;
        RpslWebImpl      rpslWebImpl;
        
        // init local parameters
        
        Locale           locale           = getLocale(request);
        MessageResources messageResources = getResources();
        
        // Session Paramaters and Beans
        
        HttpSession session  = request.getSession();
        
        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        //get the session beans from the session - Bill R
        
        if (session.getAttribute("operatorWebImpl") != null) {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null) {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }
        
        if (session.getAttribute("rpslWebImpl") != null) {
            rpslWebImpl = (RpslWebImpl) session.getAttribute("rpslWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            rpslWebImpl = new RpslWebImpl();
        }
        
        //get the operatorLoginName from the session
        
        if ((String)session.getAttribute("MM_Username") != null) operatorLoginName = (String)session.getAttribute("MM_Username");
        
        
        
        // Operator related Information
        
        
        OperatorModel       operatorModel       = operatorWebImpl.getModel((String)session.getAttribute("MM_Username"));
        OperatorInformation operatorInformation = operatorModel.getOperatorInformation();
        OperatorSessions    operatorSessions    = operatorModel.getOperatorSessions();
        OperatorSession     currentSession      = operatorSessions.getOperatorSessionById(operatorInformation.getDefaultSessionId());
        String              maintainerCode      = currentSession.getMaintainerCode();
        
        //get the defaultServerProfileId - change to currentServerProfileId
        Object defaultServerProfileId           = new Integer(1);
        
        // Get the Server
        ServerModel         serverModel         = serverWebImpl.getModel(defaultServerProfileId);
        Servers             servers             = serverModel.getServers();
        Server              server;
        List                sNames              = servers.getServerProfileNames();
        
        if (sNames.isEmpty())
        {
            return (mapping.findForward("server_new"));
        }
        
        //get current profile information - From List of Router Names
        
        Object currentServerProfileId = serverModel.getServers().getServerByName(sNames.get(0)).getServerProfileId();
        
        if (request.getParameter("serverProfileName") != null)
        {
            currentServerProfileId  = serverModel.getServers().getServerByName(request.getParameter("serverProfileName")).getServerProfileId();
        }
        
        serverModel = serverWebImpl.getModel(currentServerProfileId);
        
        
        if (debugMode)
            
        {
            //Debug.println("ServerAction - Initialization:serverForm:currentProfileId="+ currentServerProfileId);
            
        }
        server = serverModel.getServers().getServerByName(request.getParameter("serverProfileName"));
        
        /* ---------------------------------------------------
         *   Action Processiong  -  FTP Commands - Bill R
         *   The objective of this code is to get the xxxx.tar.gz db file for this
         *   server then to expand the file to text format and parse for valid
         *   inverse filter tags and other data as required... the tags
         *   are loaded into operator 0 session profile rpsl filters
         *   as the default set for the irr server db
         *
         *  note: local xxxx.db and related serial files are stored under /usr/operator/tomcat/administrator/server/N
         *        where N is the server profile number
         *
         *
         *---------------------------------------------------*/
        if ( submitFtpDataFileRetrieve != null)
        {
 
            //in progress - billr
            
            FtpClient ftpClient = new FtpClient();
            FtpResponse ftpResponse;
            FtpReader ftpReader;
            FtpWriter ftpWriter;
            
            
            //hardcoded for testing only - Bill R
            String ftpServer = request.getParameter("ftpServer");
            String ftpPath = request.getParameter("ftpPath");
            String ftpDataFile = request.getParameter("ftpDataFile");
            String ftpSerialFile = request.getParameter("ftpSerialFile");
            //note 60 is temporary diag for GAIT server
            //String localFile = new String("/usr/operator/tomcat/administrator/servers/60/canet3.db.gz");
            
            String localFile = new String(Constants.SERVER_BASE_DIR + "/" + server.getServerProfileName() + "/" + ftpDataFile);

            String unzippedLocalFile = localFile.substring(0,localFile.length() - 3);
 

            ////Debug.println("ServerAction - submitFtpParameters:unzippedLocalFile = "+ unzippedLocalFile);
            
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpServer = "+ ftpServer);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpPath = "+ ftpPath);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpDataFile = "+ ftpDataFile);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpSerialFile = "+ ftpSerialFile);
            ////Debug.println("ServerAction - submitFtpDataFileParse:localFile = "+ localFile);
            
            // connect to server
            ftpClient.connect(ftpServer);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Failed to connect to ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // send user name ...
            ftpClient.userName("anonymous");
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveIntermediary()) {
                //Debug.println("Anonymous ftp not supported on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // ... and password
            ftpClient.password("irr@canet3.net");
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Password not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // set type to IMAGE
            ftpClient.representationType(ftpClient.IMAGE_TYPE);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Image type not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            
            try {
                ftpClient.changeWorkingDirectory(ftpPath);
            } catch (IOException e) {
                Throwable t = e.fillInStackTrace();
                if (t == null)
                    t = e;
                //Debug.println("ChangeWorkingDirectory not accepted on ftpServer = " + ftpServer);
                throw new ServletException("ServerAction:ftpClient.changeWorkingDirectory = ", t);
            }
            
            // create port to which server can send data
            ftpClient.dataPort();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Data port not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // request file ...
            ftpReader = ftpClient.retrieve(ftpDataFile);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositivePreliminary()) {
                //Debug.println("File not received from ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            
            // explicit close to let FtpReader know we're done
            ftpReader.close();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("File not closed from ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // logout from server
            ftpClient.logout();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Logout not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
         
            //expand the downloaded file via the command line
            String gunzipCommandStatus = executeCommandLine("gunzip -c " + localFile + " > " + unzippedLocalFile);
            
            //write a routine here to check status >>> display on status page
            
         return (mapping.findForward("server_success"));
        }   
        
        if ( submitFtpSerialFileRetrieve != null)
        {
            //in progress - billr
            
            FtpClient ftpClient = new FtpClient();
            FtpResponse ftpResponse;
            FtpReader ftpReader;
            FtpWriter ftpWriter;
            
            
            //hardcoded for testing only - Bill R
            String ftpServer = request.getParameter("ftpServer");
            String ftpPath = request.getParameter("ftpPath");
            String ftpDataFile = request.getParameter("ftpDataFile");
            String ftpSerialFile = request.getParameter("ftpSerialFile");
            //replace path with constant
            String localFile = new String(Constants.SERVER_BASE_DIR + "/" + server.getServerProfileName() + "/" + ftpSerialFile);

 

            ////Debug.println("ServerAction - submitFtpParameters:unzippedLocalFile = "+ unzippedLocalFile);
            
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpServer = "+ ftpServer);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpPath = "+ ftpPath);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpDataFile = "+ ftpDataFile);
            ////Debug.println("ServerAction - submitFtpDataFileParse:ftpSerialFile = "+ ftpSerialFile);
            ////Debug.println("ServerAction - submitFtpDataFileParse:localFile = "+ localFile);
            
            // connect to server
            ftpClient.connect(ftpServer);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Failed to connect to ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // send user name ...
            ftpClient.userName("anonymous");
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveIntermediary()) {
                //Debug.println("Anonymous ftp not supported on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // ... and password
            ftpClient.password("irr@canet3.net");
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Password not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // set type to IMAGE
            ftpClient.representationType(ftpClient.IMAGE_TYPE);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Image type not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            
            try {
                ftpClient.changeWorkingDirectory(ftpPath);
            } catch (IOException e) {
                Throwable t = e.fillInStackTrace();
                if (t == null)
                    t = e;
                //Debug.println("ChangeWorkingDirectory not accepted on ftpServer = " + ftpServer);
                throw new ServletException("ServerAction:ftpClient.changeWorkingDirectory = ", t);
            }
            
            // create port to which server can send data
            ftpClient.dataPort();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Data port not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // request file ...
            ftpReader = ftpClient.retrieve(ftpDataFile);
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositivePreliminary()) {
                //Debug.println("File not received from ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            
            // explicit close to let FtpReader know we're done
            ftpReader.close();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("File not closed from ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
            // logout from server
            ftpClient.logout();
            ftpResponse = ftpClient.getResponse();
            if (!ftpResponse.isPositiveCompletion()) {
                //Debug.println("Logout not accepted on ftpServer = " + ftpServer);
                return (mapping.findForward("server_success"));
            }
         
                        
            //write a routine here to display serial status >>> display on message line
            
         return (mapping.findForward("server_success"));
        }   
        
        if ( submitFtpDataFileParse != null)
        {
            
            
            //hardcoded for testing only - Bill R
            String ftpServer = request.getParameter("ftpServer");
            String ftpPath = request.getParameter("ftpPath");
            String ftpDataFile = request.getParameter("ftpDataFile");
            String ftpSerialFile = request.getParameter("ftpSerialFile");
            //replace path with constant
            String localFile = new String(Constants.SERVER_BASE_DIR + "/" + server.getServerProfileName() + "/" + ftpDataFile);
            
            //Debug.println("ServerAction - submitFtpDataFileParse:ftpServer = "+ ftpServer);
            //Debug.println("ServerAction - submitFtpDataFileParse:ftpPath = "+ ftpPath);
            //Debug.println("ServerAction - submitFtpDataFileParse:ftpDataFile = "+ ftpDataFile);
            //Debug.println("ServerAction - submitFtpDataFileParse:ftpSerialFile = "+ ftpSerialFile);
            //Debug.println("ServerAction - submitFtpDataFileParse:localFile = "+ localFile);
            
     
            //String unzippedLocalFile = localFile.substring(0,localFile.length() - 3);
 

            //Debug.println("ServerAction - submitFtpParameters:unzippedLocalFile = "+ unzippedLocalFile);
            
            //String localFileContents      = loadFile(unzippedLocalFile, "ASCII");
            String localFileContents      = loadFile(localFile, "ASCII");
            
            //Debug.println("ServerAction - submitFtpParameters:localFileContents.length() = "+ localFileContents.length());
            
            //split into lines
            
            String[] localFileContentsArray = split(localFileContents);
            
            //Debug.println("ServerAction - submitFtpParameters:localFileContentsArray[0] = "+ localFileContentsArray[0]);
            
            //get default operator id = 0 rpsl filters - inverse lookup tags
            
            Object defaultOperatorId = new Integer(0);
            Object defaultSessionProfileId = new Integer(0);
            RpslModel rpslModel = rpslWebImpl.getModel(defaultOperatorId);
            RpslFilters rpslFilters = rpslModel.getRpslFilters();
            RpslFilter rpslFilter = null;
            
            
            //get the rpsl defs
            RpslDefs rpslDefs = rpslModel.getRpslDefs();
            
            java.util.List classNames = rpslDefs.getClassNames();
            
            Object[] classNamesArray = classNames.toArray(); //for grep
            
            String currentClassName = null;
            String currentAttributeName = null;
            
            RE tagRegExp = null;
            RE testRegExp = null;
            RE splitRegExp = null;
            RE embeddedRegExp = null;
            
            String currentTag = null;
            String previousTag = null;
            String currentLine = null;
            boolean tagFlag = false;
            boolean classFlag = false;
            
            List classInverseAttributeNames = null;
            List existingFilters = null;
            
            //regular expression matching
            
            try  {
                tagRegExp = new RE("(^.*):"); //look for ???... : tag pattern
            } catch (RESyntaxException e) {
                Throwable t = e.fillInStackTrace();
                if (t == null)
                    t = e;
                //Debug.println("RESyntaxException tagRegExp not accepted ");
                throw new ServletException("ServerAction:ftpClient.RESyntaxException = ", t);
            }
            
            int localFileContentsArrayLength = localFileContentsArray.length;
            
            //Debug.println("ServerAction - submitFtpParameters:localFileContentsArrayLength = "+ localFileContentsArrayLength);
            
            for (int i = 0 ; i < localFileContentsArrayLength; i++) {
                
                currentLine = localFileContentsArray[i];
                
                //check if the current line is a continuation line with a space at column 1
                ////Debug.println("ServerAction - submitFtpParameters:currentLine:before = "+ currentLine);
                ////Debug.println("ServerAction - submitFtpParameters:currentTag =Previous Tag = "+ currentTag);
                
                if (currentLine.startsWith(" ")) {
                    
                    //put the previous tag at the start of this continuation line
                    currentLine = currentTag + ":" + currentLine;
                    
                }
                
                ////Debug.println("ServerAction - submitFtpParameters:currentLine = after "+ currentLine);
                
                tagFlag = tagRegExp.match(currentLine);
                
                if (tagFlag) {
                    
                    previousTag = currentTag;
                    currentTag = tagRegExp.getParen(1);     //inside first parenthesis
                    if (currentTag.length() > 15) 
                    {
                     currentTag = previousTag;
                    }    
                    ////Debug.println("ServerAction - submitFtpParameters:currentTag = "+ currentTag);
                    
                    try  {
                        testRegExp = new RE(currentTag); //look for class name
                    } catch (RESyntaxException e) {
                        Throwable t = e.fillInStackTrace();
                        if (t == null)
                            t = e;
                        //Debug.println("RESyntaxException testRegExp not accepted ");
                        throw new ServletException("ServerAction:ftpClient.RESyntaxException = ", t);
                    }
                    
                    String[] classResultArray = testRegExp.grep(classNamesArray);
                    
                    // if there was a class tag...
                    if (classResultArray.length > 0) {
                        
                        ////Debug.println("ServerAction - submitFtpParameters:currentTag = "+ currentTag);
                        currentClassName = classResultArray[0];
                        ////Debug.println("ServerAction - submitFtpParameters:classResultArray[0] = "+ classResultArray[0]);
                        
                        classInverseAttributeNames = rpslDefs.getInverseAttributeNames(currentClassName);
                        
                    } else {
                        
                        Object[] classInverseAttributeNamesArray = classInverseAttributeNames.toArray(); //for grep
                        
                        String[] attributeResultArray = testRegExp.grep(classInverseAttributeNamesArray);
                        
                        // if there was an attribute tag...
                        if (attributeResultArray.length == 1) {
                            
                            currentAttributeName = attributeResultArray[0];
                            
                            //get the filterExpressions
                            
                            //get the substring to the end of line after the tag plus colon
                            String filterExpressions = currentLine.substring(currentAttributeName.length() + 1);
                            
                            //trim whitespace from both ends
                            filterExpressions = filterExpressions.trim();
                            
                            //form the regexp for comma splittting line to string array
                            try  {
                                splitRegExp = new RE(","); //look for comma split pattern
                            } catch (RESyntaxException e) {
                                Throwable t = e.fillInStackTrace();
                                if (t == null)
                                    t = e;
                                //Debug.println("RESyntaxException splitRegExp not accepted ");
                                throw new ServletException("ServerAction:ftpClient.RESyntaxException = ", t);
                            }
                            
                            //form the regexp for embedded character detection
                            try  {
                                embeddedRegExp = new RE(" "); //look for embedded whitespace characters - others types can be added here as required
                            } catch (RESyntaxException e) {
                                Throwable t = e.fillInStackTrace();
                                if (t == null)
                                    t = e;
                                //Debug.println("RESyntaxException splitRegExp not accepted ");
                                throw new ServletException("ServerAction:ftpClient.RESyntaxException = ", t);
                            }
                            
                            String[] filterExpressionArray = splitRegExp.split(filterExpressions);
                            
                            if (filterExpressionArray.length > 0) {
                                
                                for (int j = 0 ; j < filterExpressionArray.length; j++) {
                                    
                                    String filterExpression = filterExpressionArray[j];

                                    //get the existing filter expressions for the params
                                    rpslModel = rpslWebImpl.getModel(defaultOperatorId);
                                    rpslFilters = rpslModel.getRpslFilters();
                                    existingFilters = rpslFilters.getFilterExpressions(defaultSessionProfileId, 
                                    server.getServerProfileId(), currentClassName, currentAttributeName);
                                    ////Debug.println("ServerAction: submitFtpParameters:existingFilters:defaultSessionProfileId = " + defaultSessionProfileId);
                                    ////Debug.println("ServerAction: submitFtpParameters:existingFilters:server.getServerProfileId() = " + server.getServerProfileId());
                                    ////Debug.println("ServerAction: submitFtpParameters:existingFilters:currentClassName = " + currentClassName);
                                    ////Debug.println("ServerAction: submitFtpParameters:existingFilters:currentAttributeName = " + currentAttributeName);
                                    ////Debug.println("ServerAction: submitFtpParameters:existingFilters = " + existingFilters);
                                    
                                    //trim filter expression ends of whitespace
                                    filterExpression = filterExpression.trim();
                                    ////Debug.println("ServerAction: submitFtpParameters:filterExpression = " + filterExpression);
                                    //check to see if the trimmed filter expression contain embedded spaces and skip if so
                                    if (!embeddedRegExp.match(filterExpression)) {

                                        //if the list doesn't include this filterExpression then add it to the database
                                        if (!existingFilters.contains(filterExpression)) {

                                        rpslFilter = new RpslFilter();
                                        rpslFilter.setRpslFilterId((Object) new Integer(rpslFilters.getRpslFilters().size() + 1));
                                        rpslFilter.setOperatorId(defaultOperatorId);
                                        rpslFilter.setSessionProfileId(defaultSessionProfileId);
                                        rpslFilter.setServerProfileId(server.getServerProfileId());
                                        rpslFilter.setRpslObjectType(currentClassName);
                                        rpslFilter.setRpslAttributeType(currentAttributeName);
                                        rpslFilter.setFilterExpression(filterExpression);

                                        ////Debug.println("ServerAction: submitFtpParameters:rpslFilter = " + rpslFilter);

                                        rpslFilters.addRpslFilter(rpslFilter); //update memory model
                                        rpslWebImpl.add(rpslFilter);  //update database
                                        }
                                    }
                                    
                                }
                                
                            }
                        }
                        
                    }
                }
                
            }
            
            if (debugMode)
                
            {
                //Debug.println("ServerAction - submitFtpParameters="+ request.getParameter("ftpParameters"));
            }

            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
            
            
            return (mapping.findForward("server_success"));
        }
        
        /* ---------------------------------------------------
         *   Action Processiong  -  Source Code Commands - Bill R
         *---------------------------------------------------*/
        
        
        if ( submitAuthoritativeSourceCodeAdd != null)
        {
            server.setAuthoritativeSourceCodes(server.getAuthoritativeSourceCodes() + " " + request.getParameter("authoritativeSourceCodeText"));
            if (debugMode)
                
            {
                //Debug.println("ServerAction - submitAuthoritativeSourceCodeAdd="+ request.getParameter("authoritativeSourceCodeText"));
            }
            return (mapping.findForward("server_success"));
        }
        
        if ( submitMirroredSourceCodeAdd != null)
        {
            server.setMirroredSourceCodes(server.getMirroredSourceCodes() + " " + request.getParameter("mirroredSourceCodeText"));
            if (debugMode)
                
            {
                //Debug.println("ServerAction - submitMirroredSourceCodeAdd="+ request.getParameter("mirroredSourceCodeText"));
            }
            return (mapping.findForward("server_success"));
        }
        
        if ( submitAuthoritativeSourceCodeDelete != null)
        {
            List authoritativeSourceCodesList = (List) session.getAttribute("authoritativeSourceCodesBean");
            authoritativeSourceCodesList.remove(request.getParameter("authoritativeSourceCode"));
            String authoritativeSourceCodesString = new String();
            Iterator authoritativeSourceCodesListIterator = authoritativeSourceCodesList.listIterator();
            while (authoritativeSourceCodesListIterator.hasNext()) {
                authoritativeSourceCodesString = authoritativeSourceCodesString + authoritativeSourceCodesListIterator.next() + " ";
            }
            server.setAuthoritativeSourceCodes(authoritativeSourceCodesString.trim());
            if (debugMode)
                
            {
                //Debug.println("ServerAction - submitAuthoritativeSourceCodeDelete="+ request.getParameter("authoritativeSourceCode"));
            }
            return (mapping.findForward("server_success"));
        }
        
        if ( submitMirroredSourceCodeDelete != null)
        {
            List mirroredSourceCodesList = (List) session.getAttribute("mirroredSourceCodesBean");
            mirroredSourceCodesList.remove(request.getParameter("mirroredSourceCode"));
            String mirroredSourceCodesString = new String();
            Iterator mirroredSourceCodesListIterator = mirroredSourceCodesList.listIterator();
            while (mirroredSourceCodesListIterator.hasNext()) {
                mirroredSourceCodesString = mirroredSourceCodesString + mirroredSourceCodesListIterator.next() + " ";
            }
            server.setMirroredSourceCodes(mirroredSourceCodesString.trim());
            if (debugMode)
                
            {
                //Debug.println("ServerAction - submitAuthoritativeSourceCodeDelete="+ request.getParameter("mirroredSourceCode"));
            }
            return (mapping.findForward("server_success"));
        }
        
        
       /*---------------------------------------------------
        *   Action Processiong  -  Server Update - Save Modofications
        *---------------------------------------------------*/
        
        if  (submitSave != null)
        {
            //get the model object from the form
            
            Server modifiedServer =  server;
            
            //copy merge the properties from the form to the original
            if (debugMode)
                
            {
                //Debug.println("ServerAction - Save:serverForm="+ serverForm.getServerDnsName());
            }
            serverForm.setServerProfileId(modifiedServer.getServerProfileId());
            serverForm.setAuthoritativeSourceCodes(modifiedServer.getAuthoritativeSourceCodes());
            serverForm.setMirroredSourceCodes(modifiedServer.getMirroredSourceCodes());
            copyObjectProperties(modifiedServer, serverForm);
            
            if (debugMode)
                
            {
                //Debug.println("ServerAction - Update:modifiedServer="+ modifiedServer.toString());
            }
            //update database
            serverWebImpl.update(modifiedServer);
            
            //flag beans model to null so reloads the database on findForward
            serverModel = null;
            
            //return to same page
            return (mapping.findForward("server_success"));
        }
        
       /*---------------------------------------------------
        *   Action Processiong  -  Server Delete
        *---------------------------------------------------*/
        
        if (submitDelete != null)
        {
            
            if (debugMode)
                
            {
                //Debug.println("ServerAction - Delete:serverForm: currentServerProfileId = "+ currentServerProfileId);
            }
            
            // delete server from database
            serverWebImpl.delete(currentServerProfileId);
            
            //flag beans model to null so reloads the database on findForward
            serverModel = null;
            
            //return to same page
            return (mapping.findForward("server_success"));
            
            
        }
        
       /*---------------------------------------------------
        *   Action Processiong  -  New Server
        *---------------------------------------------------*/
        
        if (submitNew != null)
        {
            if (debugMode)
                
            {
                //Debug.println("ServerAction - New:serverForm="+ submitNew);
            }
            return (mapping.findForward("server_new"));
            
        }
        
        
        
       /* ---------------------------------------------------
        *   Action Processiong  -  Page Refresh (Ok) For Select - mod Bill R.
        *---------------------------------------------------*/
        
        if ( serverProfileName != null)
        {
            session.setAttribute(Constants.SELECTED_SERVER, serverForm.getServerProfileName());
            if (debugMode)
                
            {
                //Debug.println("ServerAction - Refresh(Ok):serverForm="+ serverForm.getServerProfileName());
            }
            return (mapping.findForward("server_success"));
            
            
        }
        
        
        
        if (servlet.getDebug() >= 1)
        {
            servlet.log("ServerAction: Server '" + currentServerProfileId +
            "' in session " + session.getId());
        }
        
        
      /* ---------------------------------------------------
       *   Action Processiong  -  Page Refresh (Ok) For Select - mod Bill R.
       *---------------------------------------------------*/
        
        return (mapping.findForward("server_success"));
        
    }
    
    /*---------------------------------------------------
     *   Copy Form Properties to Server Model
     *---------------------------------------------------*/
    
    private void copyObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            PropertyUtils.copyProperties(toObject, fromObject);
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        }
    }
    
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("OperatorWebImpl: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
    
    
    /**
     * Accepts a string with lines separated by '\n' and places each
     * line into a separate element of a string array.
     *
     * @param
     *
     * @return
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;
        
        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();
        
        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }
        
        trimArray(temp);
        
        return((String[])temp.toArray(new String[]{}));
    }
    
        /**
         * Removes leading empty Strings from an ArrayList of String
         * objects.
         *
         * @param t
         *
         */
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;
        
        idxRemove = new int[100];
        count = 0;
        
        if(!t.isEmpty())
        {
            
            for(int i = 0 ; i < t.size() ; i++)
            {
                String s;
                
                s = t.get(i).toString().trim();
                
                if(s.length() == 0)
                {
                    idxRemove[count] = i;
                    count++;
                }
                else
                {
                    break;
                }
            }
            
            for(int i = count ; i > 0 ; i--)
            {
                t.remove(0);
            }
        }
    }
    
    private static String loadFile(String filePath, String encoding)
    {
        File inputFile;
        FileInputStream is;
        String returnString;
        ByteArrayOutputStream bos;
        
        returnString = new String("");
        bos = new ByteArrayOutputStream();
        
        try
        {
            long total;
            byte [] buffer;
            
            inputFile   = new File(filePath);
            is          = new FileInputStream(inputFile);
            total       = 0;
            buffer      = new byte[1024];
            
            while (true)
            {
                int nRead;
                
                nRead = is.read(buffer,0,buffer.length);
                
                total += nRead;
                
                if (nRead <=0)
                {
                    break;
                }
                
                bos.write(buffer,0, nRead);
            }
            
            is.close();
            bos.close();
        }
        catch (IOException e)
        {
            //System.out.print ("Error Reading file: " + e + "\n");
            return ("Error Reading file: " + e + "\n");
        }
        catch (Exception e)
        {
            //System.out.print ("Error Reading: " + e + "\n");
            return ("Error Reading: " + e + "\n");
        }
        
        try
        {
            byte[] bytes = bos.toByteArray();
            
            if (encoding != null)
            {
                returnString = new String(bytes,0, bytes.length, encoding);
            }
            else
            {
                returnString = new String(bytes);
            }
        }
        catch (UnsupportedEncodingException enex)
        {
            ////Debug.println("Unable to Convert Source File");
            return ("Unable to Convert Source File");
        }
        
        return (returnString);
    }
}