package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.model.router.model.*;
import ca.rrx.nw.rr.control.web.RouterWebImpl;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.*;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;


public final class NewRouterTransitPortAction extends Action
{

     public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {

      // Switch for Debug Mode (true/false)
        
        boolean debugMode = false; 
         

       // Variable Declaration

       
           
              
        String           submitOK           = request.getParameter("submitOK");
        String           submitReset        = request.getParameter("submitReset");
        String           submitCancel       = request.getParameter("submitCancel");
        
        NewRouterTransitPortForm           newRouterTransitPortForm    = (NewRouterTransitPortForm) form;
       
        OperatorWebImpl                    operatorWebImpl;
        String                             operatorLoginName;
        RouterWebImpl                      routerWebImpl;
                              
        // init local parameters
        
        Locale           locale           = getLocale(request);
        MessageResources messageResources = getResources();
        
        // Session Paramaters and Beans
        
        HttpSession session               = request.getSession();

        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        //get the session beans from the session 
        
        if (session.getAttribute("operatorWebImpl") != null)
        {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        }
        else
        {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("routerWebImpl") != null)
        {
            routerWebImpl = (RouterWebImpl) session.getAttribute("routerWebImpl");
        }
        else
        {  //diag only - should error out here if there is no bean in the session
            routerWebImpl = new RouterWebImpl();
        }
          
        //get the operatorLoginName from the session
 
        if ((String)session.getAttribute("MM_Username") != null) operatorLoginName = (String)session.getAttribute("MM_Username");
                     

       // Operator related Information

                           
        OperatorModel       operatorModel            = operatorWebImpl.getModel((String)session.getAttribute("MM_Username"));
        OperatorInformation operatorInformation      = operatorModel.getOperatorInformation();
        OperatorSessions    operatorSessions         = operatorModel.getOperatorSessions();
        String              maintainerCode           = operatorInformation.getMaintainerCodes();

        // Router Information
        
        RouterModel         routerModel              = routerWebImpl.getModel(maintainerCode);
        Routers             routers                  = routerModel.getRouters();
        
        List                rNames                   = routers.getRouterProfileNames();
        // temp
        Object              currentRouterProfileId    = new Integer(1); 
              
        if ((Object)session.getAttribute("MM_RouterId") != null) currentRouterProfileId = (Object)session.getAttribute("MM_RouterId");
      
  
     if (debugMode)
       
{
        	//Debug.println("RouterTransitPortProfileAction - Initialization:routerTransitProfileForm:currentProfileId="+ currentRouterProfileId);
        }
       
       /*---------------------------------------------------
        *   Action Processiong  -  Add New Router Transit Port     
        *---------------------------------------------------*/
        
        if  (submitOK != null)
        {
            //  Construct New Objects
            if (debugMode)
       
    {
            	//Debug.println("NewRouterTransitPortAction - OK:AddRouterTransitPortForm=");
            }  
            TransitPort       newTransitPort       = new TransitPort();    
                      
            //overwrite the fresh ones with the form stuff 
           
            newRouterTransitPortForm.setRouterProfileId(currentRouterProfileId);
            copyNotNullObjectProperties(newTransitPort, newRouterTransitPortForm);
            //need to scan transit orts for this router and generate new port number
            newTransitPort.setTransitPortNumber("1");
            //need to generate new date
            
            newTransitPort.setTimeStored(new Date().toString());
            
            if (debugMode)
       
    {         
            	//Debug.println("NewRouterTransitPortAction - OK:newTransitPort=" + newTransitPort);
            }          
            //update the database
            routerWebImpl.add(newTransitPort);
           
           //flag session beans model to null so reloads the database on findForward
            
           routerWebImpl = new RouterWebImpl();
           session.setAttribute("routerWebImpl", routerWebImpl);
                     
            //return to the confirmation Page
            return (mapping.findForward("router_transit_port_profile_success"));
         
        } 

       /*---------------------------------------------------
        *   Action Processiong  -  Reset a Form   
        *---------------------------------------------------*/
        
        if ( submitReset != null)
        {
            if (debugMode)
       
    {
            	//Debug.println("NewRouterTransitPortAction - Reset:NewRouterTransitPortForm="+ newRouterTransitPortForm.getRouterProfileName());
            }
            return (mapping.findForward("router_transit_port_profile_new"));
        } 
        
      
        
       /*-------------------------------------------------------------------
        *   Action Processiong  -  Cancel na Action and return to Main Menu    
        *-------------------------------------------------------------------*/
        
          if (submitCancel != null) 
        {
            if (debugMode)
       
    {
            	//Debug.println("NewRouterTransitPortAction - Cancel:newRouterTransitPortForm="+ submitCancel);
            }
            return (mapping.findForward("router_profile_success"));   
        }
  
              
        if (servlet.getDebug() >= 1)
        {
            servlet.log("NewTransitPortAction: Router Transit Port'" + currentRouterProfileId +
 "' in session " + session.getId());
        }

   
        return (mapping.findForward("router_transit_port_profile_new"));
     
    }

    /*---------------------------------------------------
     *   Copy Form Properties to Router Model     
     *---------------------------------------------------*/   
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("NewTransitPortAction: No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("NewTransitPortAction: No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("NewTransitPortAction:copyObjectProperties ", t);
            throw new ServletException("NewTransitPortAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("NewTransitPortAction:copyObjectProperties ", t);
            throw new ServletException("NewTransitPortAction:copyObjectProperties ", t);
        }
    }
    
}