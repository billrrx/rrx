package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;


public final class NewRouterControlPortForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

      // --------------------------------------------------- Instance Variables

    protected List routerProfileNames;

    protected String routerProfileName;
    
    protected List controlPortNames;

  
    private Object controlPortId;
    private Object routerProfileId;
    private String controlPortName;
    private String controlPortNumber;
    private String timeStored;
    private String disabled;
    private String circuit;
    private String designatedIpv4;
    private String designatedIpv4MaskLength;
    private String transportProtocol;
    private String uclpProfileId;
    private String ipv6ProfileId;
    private String connectionProfileId;
    private String remarks;
    
    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getControlPortNames(){
        return controlPortNames;
    }
    
    public void setControlPortNames(List controlPortNames) {
        this. controlPortNames = controlPortNames;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }

//----------------  
    
    public Object getControlPortId() {
        return controlPortId;
    }
    
    public void setControlPortId(Object controlPortId) {
        this. controlPortId = controlPortId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getControlPortName() {
        return controlPortName;
    }
    
    public void setControlPortName(String controlPortName) {
        this. controlPortName = controlPortName;
    }

    public String getControlPortNumber() {
        return controlPortNumber;
    }
    
    public void setControlPortNumber(String controlPortNumber) {
        this.controlPortNumber = controlPortNumber;
    }

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }

    public String getDisabled() {
        return disabled;
    }
    
    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public String getDesignatedIpv4() {
        return designatedIpv4;
    }

    public String getCircuit() {
        return circuit;
    }
    
    public void setCircuit(String circuit) {
        this.circuit = circuit;
    }    
    
    public void setDesignatedIpv4(String designatedIpv4) {
        this.designatedIpv4 = designatedIpv4;
    }

    public String getDesignatedIpv4MaskLength() {
        return designatedIpv4MaskLength;
    }

    public void setDesignatedIpv4MaskLength(String designatedIpv4MaskLength) {
        this.designatedIpv4MaskLength = designatedIpv4MaskLength;
    }

    public String getTransportProtocol(){
        return transportProtocol;
    }
    
    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }
    
 
    public String getUclpProfileId(){
        return uclpProfileId;
    }
    
    public void setUclpProfileId(String uclpProfileId) {
        this.uclpProfileId = uclpProfileId;
    }
    
   
    public String getIpv6ProfileId(){
        return ipv6ProfileId;
    }
    
    public void setIpv6ProfileId(String ipv6ProfileId) {
        this.ipv6ProfileId = ipv6ProfileId;
    }
    
    public String getConnectionProfileId() {
        return connectionProfileId;
    }
    
    public void setConnectionProfileId(String connectionProfileId) {
        this.connectionProfileId = connectionProfileId;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


   

  // --------------------------------------------------------- Public Methods
    
    /**
     * RESET all properties to their default values.
     *

    */

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

      	this.controlPortId      	=  null;
	
       	this.routerProfileId    	=  null;
       	this.controlPortName    	=  null;
       	this.controlPortNumber  	=  null;
       	this.timeStored         	=  null;
       	this.disabled           	=  null;
       	this.circuit           		=  null;
    	this.designatedIpv4		=  null;

    	this.designatedIpv4MaskLength	=  null;

    	this.transportProtocol		=  null;

    	this.uclpProfileId		=  null;

    	this.ipv6ProfileId		=  null;

    	this.remarks			=  null;

    	

   }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterControlPortNewForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterControlPortNewForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterControlPortNewForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterControlPortNewForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterControlPortNewForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterControlPortNewForm error: " + pce);
        }
        return null;
    }
}