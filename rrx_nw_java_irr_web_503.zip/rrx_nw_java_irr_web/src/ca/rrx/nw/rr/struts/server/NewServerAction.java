package ca.rrx.nw.rr.struts.server;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;

public final class NewServerAction extends Action
{

   // --------------------------------------------------------- Public Methods


    public ActionForward perform(ActionMapping mapping,
       ActionForm form,
       HttpServletRequest request,
       HttpServletResponse response)
         throws IOException, ServletException
    {
        
            // Switch for Debug Mode (true/false)
        
        boolean debugMode = false;        
                         
        //init local parameters
        
        Locale           locale           = getLocale(request);
        MessageResources messageResources = getResources();
        HttpSession      session          = request.getSession();
        
        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        String           submitOK           = request.getParameter("submitOK");
        String           submitReset        = request.getParameter("submitReset");
        String           submitCancel       = request.getParameter("submitCancel");
        
        NewServerForm    newServerForm    = (NewServerForm) form;
        ActionForward    actionForward;
        
        //init model getters
        
        String           operatorLoginName;
        ServerWebImpl    serverWebImpl    = new ServerWebImpl();

        //get the operatorLoginName from the session
 
        if ((String)session.getValue("MM_Username") != null) operatorLoginName = (String)session.getValue("MM_Username");

       
if (debugMode)
       
{

       	//Debug.println("NewServerAction - inside class:OperatorLoginName="+ operatorLoginName);

       } 
     
        Object defaultServerProfileId = new Integer(1);
        Object nextServerProfileId    = new Integer(7); 
         
        //get the serverModel with the defaultServerProfileId parameter set
        
        ServerModel serverModel                 = serverWebImpl.getModel(defaultServerProfileId);
        
        
        //pick up basic default IRR server params
               
        Servers servers                         = serverModel.getServers();
        
        //pick up basic working IRR server params
        
      

if (debugMode)
       
{
        	//Debug.println("NewServerAction - inside class:newServerForm="+ newServerForm);

       }     
           
        if  (submitOK != null) 
        {
                            
            //get the model object  - Initialize
            
            Server newServer = new Server();
            
            //copy properties from the form to the initial server
            if (debugMode)
       
    {
         
     //Debug.println("NewServerAction - OK:AddServerForm="+ newServerForm.getServerDnsName());
            }
            newServerForm.setServerProfileId(nextServerProfileId);
            copyObjectProperties(newServer, newServerForm);
            if (debugMode)
       
    {
            	//Debug.println("NewServerAction - OK:newServer="+ newServer.toString());
           
} 
            //update database
            serverWebImpl.add(newServer);
            
            //get new Memory Model
            serverModel = serverWebImpl.getModel(nextServerProfileId);
         
            //return to same page
            return (mapping.findForward("server_new"));

         
        } 
        
        
        if ( submitReset != null)
        {
            if (debugMode)
       
    {
            	//Debug.println("NewServerAction - Reset:AddServerForm="+ newServerForm.getServerProfileName());
            }	
            return (mapping.findForward("server_new"));
        } 
        
        
        
        if (submitCancel != null)
        {
            if (debugMode)
       
    {
            	//Debug.println("NewServerAction - Cancel:newServerForm="+ submitCancel);
            }   	
            return (mapping.findForward("main"));   
        }
           
        if (servlet.getDebug() >= 1)
        {
            servlet.log("NewServerAction: Server '" + defaultServerProfileId +
"' in session " + session.getId());
        }
          
        return (mapping.findForward("server_new"));
  
    }    
     
    
    private void copyObjectProperties(Object toObject, Object fromObject) 
    throws IOException, ServletException 
    {
        try 
        {
            PropertyUtils.copyProperties(toObject, fromObject);
        }
        catch (InvocationTargetException e) 
        {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("NewServerAction:copyObjectProperties ", t);
            throw new ServletException("NewServerAction:copyObjectProperties ", t);
        } 
        catch (Throwable t) 
        {
            servlet.log("NewServerAction:copyObjectProperties ", t);
            throw new ServletException("NewServerAction:copyObjectProperties ", t);
        }
    }
}