package ca.rrx.nw.rr.struts.operator;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;

import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.Address;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;


public final class NewOperatorAction extends Action
{

   
    public ActionForward perform(ActionMapping mapping,
       ActionForm form,
       HttpServletRequest request,
       HttpServletResponse response)
         throws IOException, ServletException
    {
        // Switch for Debug Mode (true/false)
        
        boolean debugMode = false; 
         

       // Variable Declaration

       

       String	operatorLoginName  = null;              
        String  submitSend         = request.getParameter("submitSend");
        String  submitReset        = request.getParameter("submitReset");
        String  submitCancel       = request.getParameter("submitCancel");
        
        NewOperatorForm  newOperatorForm    = (NewOperatorForm) form;
                  
        //init local parameters
        
        Locale           locale               = getLocale(request);
        MessageResources messageResources     = getResources();
        HttpSession      session              = request.getSession();
          
        //init model getters
        
        if ((String)session.getAttribute(Constants.USERNAME_KEY) != null)
        {
           operatorLoginName = (String)session.getAttribute(Constants.USERNAME_KEY);
        }
        else
        {
           return (mapping.findForward("main"));
        }
        OperatorWebImpl    operatorWebImpl    = new OperatorWebImpl();

        //get the operatorLoginName from the session
 
      
        //Debug.println("NewOperatorAction - inside class:=");

     
        Object defaultOperatorProfileId    = new Integer(7); 
             
        
        //pick up basic default IRR Operator params
       
        //Debug.println("NewOperatorAction - inside class:newOperatorForm="+ newOperatorForm);

  
       
        if  (submitSend != null)
        {
             
            //update database
            
            //Debug.println("NewOperatorAction - OK:AddOperatorForm=");
            OperatorModel       newOperatorModel       = new OperatorModel();
            OperatorInformation newOperatorInformation = new OperatorInformation();
            Address             newAddress             = new Address();
            
            //overwrite the fresh ones with the form stuff 
           
            newOperatorForm.setOperatorId(defaultOperatorProfileId); 
            copyNotNullObjectProperties(newOperatorInformation, newOperatorForm);
            copyNotNullObjectProperties(newAddress, newOperatorForm);
            newOperatorInformation.setOperatorId(defaultOperatorProfileId); 
            newOperatorInformation.setAddress(newAddress);
            newOperatorInformation.setRole("Operator");
            newOperatorInformation.setNicHandle("not-set");
            newOperatorInformation.setMaintainerCodes("not-set");
            newOperatorInformation.setLang(request.getParameter("languageSelected"));
             
            //update the database
            operatorWebImpl.add(newOperatorInformation);
             
            //flag beans model to null so reloads the database on findForward
            newOperatorModel = null;
            
          
            //return to the confirmation Page
            return (mapping.findForward("main"));

   
        } 
        
        
        if (submitReset != null)
        {
            ////Debug.println("NewOperatorAction - Reset:AddOperatorForm="+ newOperatorForm.getOperatorProfileName());
            return (mapping.findForward("operator_profile_new"));
        } 
        
        
        
        if (submitCancel != null) 
        {
            //Debug.println("NewOperatorAction - Cancel:newOperatorForm="+ submitCancel);
            return (mapping.findForward("main"));   
        }
        
  
        servlet.log("NewOperatorAction: Operator '" + submitCancel +
"' in session " + session.getId());
        
            
        if (servlet.getDebug() >= 1)
        {
            servlet.log("NewOperatorAction: Operator '" + defaultOperatorProfileId +
"' in session " + session.getId());
        }
          
        return (mapping.findForward("operator_profile_new"));
  
    }    
     
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
        throws IOException, ServletException 
   {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("NewOperatorAction:copyObjectProperties ", t);
            throw new ServletException("NewOperatorAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("NewOperatorAction:copyObjectProperties ", t);
            throw new ServletException("NewOperatorAction:copyObjectProperties ", t);
        }
    }
}