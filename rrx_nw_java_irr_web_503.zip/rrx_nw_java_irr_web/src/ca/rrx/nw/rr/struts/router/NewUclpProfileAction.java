package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.model.router.model.*;
import ca.rrx.nw.rr.control.web.RouterWebImpl;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.*;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

   

public final class NewUclpProfileAction extends Action
{

     public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {


            // Variable Declaration
        
        String                             submit                      = request.getParameter("submit");
        NewRouterTransitPortForm           newRouterTransitPortForm    = (NewRouterTransitPortForm) form;
        ActionForward                      actionForward;
        OperatorWebImpl                    operatorWebImpl;
        String                             operatorLoginName;
        RouterWebImpl                      routerWebImpl;
                              
        // init local parameters
        
        Locale           locale           = getLocale(request);
        MessageResources messageResources = getResources();
        
        // Session Paramaters and Beans
        
        HttpSession session               = request.getSession();

        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        //get the session beans from the session 
        
        if (session.getValue("operatorWebImpl") != null) {
            operatorWebImpl = (OperatorWebImpl) session.getValue("operatorWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getValue("routerWebImpl") != null) {
            routerWebImpl = (RouterWebImpl) session.getValue("routerWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            routerWebImpl = new RouterWebImpl();
        }
          
        //get the operatorLoginName from the session
 
        if ((String)session.getValue("MM_Username") != null) operatorLoginName = (String)session.getValue("MM_Username");
                     

       // Operator related Information

                           
        OperatorModel       operatorModel            = operatorWebImpl.getModel((String)session.getValue("MM_Username"));
        OperatorInformation operatorInformation      = operatorModel.getOperatorInformation();
        OperatorSessions    operatorSessions         = operatorModel.getOperatorSessions();
        String              maintainerCode           = operatorInformation.getMaintainerCodes();

        // Router Information
        
        RouterModel         routerModel              = routerWebImpl.getModel(maintainerCode);
        Routers             routers                  = routerModel.getRouters();
        
        List                rNames                   = routers.getRouterProfileNames();
        // temp
        Object             currentRouterProfileId    = new Integer(1); 
              
        if ((Object)session.getValue("MM_RouterId") != null) currentRouterProfileId = (Object)session.getValue("MM_RouterId");
        //Debug.println("RouterTransitPortProfileAction - MM_RouterId:routerTransitProfileForm:currentProfileId="+ currentRouterProfileId);
  
        //Debug.println("RouterTransitPortProfileAction - Initialization:routerTransitProfileForm:currentProfileId="+ currentRouterProfileId);
        //Debug.println("RouterTransitPortProfileAction - Initialization:routerTrnasitProfileForm:submit= "+ submit);
             
       /*---------------------------------------------------
        *   Action Processiong  - Initialization    
        *---------------------------------------------------*/
  

       if (submit == null)  
            
        {
            //Debug.println("NewTransitPortAction - null:newRouterTransitPortForm="+ newRouterTransitPortForm);
            //for testing 
            return (mapping.findForward("new_router_transit_port_success"));
        }
                   
       /*---------------------------------------------------
        *   Action Processiong  -  Add New Router Transit Port     
        *---------------------------------------------------*/
        
        if  ((submit != null) && submit.equals("OK"))
        {
            //  Construct New Objects
            
            //Debug.println("NewRouterTransitPortAction - OK:AddRouterTransitPortForm=");
          
            TransitPort       newTransitPort       = new TransitPort();    
                      
            //overwrite the fresh ones with the form stuff 
           
            newRouterTransitPortForm.setRouterProfileId(currentRouterProfileId);
            copyNotNullObjectProperties(newTransitPort, newRouterTransitPortForm);
                     
            //Debug.println("NewRouterTransitPortAction - OK:newTransitPort=" + newTransitPort);
                      
            //update the database
            routerWebImpl.add(newTransitPort);
           
            routerModel = null;
                     
            //return to the confirmation Page
            return (mapping.findForward("router_transit_port_profile_new"));
               
        } 

       /*---------------------------------------------------
        *   Action Processiong  -  Reset a Form   
        *---------------------------------------------------*/
        
        if ( submit != null && submit.equals("Reset"))
        {
            ////Debug.println("NewRouterTransitPortAction - Reset:NewRouterTransitPortForm="+ newRouterTransitPortForm.getRouterProfileName());
            return (mapping.findForward("router_transit_port_profile_new"));
        } 
        
      
        
       /*-------------------------------------------------------------------
        *   Action Processiong  -  Cancel na Action and return to Main Menu    
        *-------------------------------------------------------------------*/
        
          if ((submit != null) && submit.equals("Cancel"))
        {
            //Debug.println("NewRouterTransitPortAction - Cancel:newRouterTransitPortForm="+ submit);
            return (mapping.findForward("router_profile_success"));   
        }
  
 
        servlet.log("TransitPortProfileAction: Router Transit Port'" + submit +
"' in session " + session.getId());

        
              
        if (servlet.getDebug() >= 1)
        {
            servlet.log("NewTransitPortAction: Router Transit Port'" + currentRouterProfileId +
 "' in session " + session.getId());
        }

   
        return (mapping.findForward("router_transit_port_profile_new"));
     
    }

    /*---------------------------------------------------
     *   Copy Form Properties to Router Model     
     *---------------------------------------------------*/   
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("NewTransitPortAction: No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("NewTransitPortAction: No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("NewTransitPortAction:copyObjectProperties ", t);
            throw new ServletException("NewTransitPortAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("NewTransitPortAction:copyObjectProperties ", t);
            throw new ServletException("NewTransitPortAction:copyObjectProperties ", t);
        }
    }
    
}