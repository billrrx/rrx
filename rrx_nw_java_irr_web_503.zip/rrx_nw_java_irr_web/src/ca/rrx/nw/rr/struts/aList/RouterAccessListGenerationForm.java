package ca.rrx.nw.rr.struts.aList;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class RouterAccessListGenerationForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    String manuf1;
    String autsystems1;
    String tiermaints1;
    String autsystems2;
    String tiers;
    String tiermaints2;
    String routers1;
    String rsString;
    String routers2;
    String asSetString;

    String results;             // stores results of executed command
    String commandIndex;        // string indicating which command was executed
    String command;             // stores command to be executed

    {
        manuf1          = null;
        autsystems1     = null;
        tiermaints1     = null;
        autsystems2     = null;
        tiers           = null;
        tiermaints2     = null;
        routers1        = null;
        rsString        = null;
        routers2        = null;
        asSetString     = null;

        command         = null;
        commandIndex    = null;
        results         = null;
    }

    // ----------------------------------------------------------- Properties

    public String getManuf1()
    {
        return (this.manuf1);
    }

    public void setManuf1(String m)
    {
        this.manuf1 = m;
    }

    public String getAutsystems1()
    {
        return (this.autsystems1);
    }

    public void setAutsystems1(String a)
    {
        this.autsystems1 = a;
    }

    public String getTiermaints1()
    {
        return (this.tiermaints1);
    }

    public void setTiermaints1(String t)
    {
        this.tiermaints1 = t;
    }

    public String getTiers()
    {
        return (this.tiers);
    }

    public void setTiers(String t)
    {
        this.tiers = t;
    }

    public String getAutsystems2()
    {
        return (this.autsystems2);
    }

    public void setAutsystems2(String a)
    {
        this.autsystems2 = a;
    }

    public String getTiermaints2()
    {
        return (this.tiermaints2);
    }

    public void setTiermaints2(String t)
    {
        this.tiermaints2 = t;
    }


    public String getRouters1()
    {
        return (this.routers1);
    }

    public void setRouters1(String r)
    {
        this.routers1 = r;
    }


    public String getRsString()
    {
        return (this.rsString);
    }

    public void setRsString(String r)
    {
        this.rsString = r;
    }

    public String getRouters2()
    {
        return (this.routers2);
    }

    public void setRouters2(String r)
    {
        this.routers2 = r;
    }

    public String getAsSetString()
    {
        return (this.asSetString);
    }

    public void setAsSetString(String a)
    {
        this.asSetString = a;
    }

    public String getCommand()
    {
        return (this.command);
    }

    public void setCommand(String cmd)
    {
        this.command = cmd;
    }

    public String getCommandIndex()
    {
        return (this.commandIndex);
    }

    public void setCommandIndex(String ci)
    {
        this.commandIndex = ci;
    }

    public String getResults()
    {
        return (this.results);
    }

    public void setResults(String res)
    {
        this.results = res;
    }



    // --------------------------------------------------------- Public Methods

    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.manuf1         = null;
        this.autsystems1    = null;
        this.tiermaints1    = null;
        this.autsystems2    = null;
        this.tiers          = null;
        this.tiermaints2    = null;
        this.routers1       = null;
        this.rsString       = null;
        this.routers2       = null;
        this.asSetString    = null;

        this.command        = null;
        this.commandIndex   = null;
        this.results        = null;
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((tier == null) || (tier.length() < 1))
        {
            errors.add("tier", new ActionError("error.tier.required"));
        }

        if ((tiermaint == null) || (tiermaint.length() < 1))
        {
            errors.add("tiermaint", new ActionError("error.tiermaint.required"));
        }
*/
        return errors;
    }
}
