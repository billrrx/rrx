package ca.rrx.nw.rr.struts.report;


import ca.rrx.nw.rr.Constants;


import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;

import ca.rrx.nw.rr.model.server.model.Server;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.ServerModel;

import ca.rrx.nw.rr.control.web.RouterWebImpl;
import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.control.web.ServerWebImpl;


import ca.rrx.nw.rr.model.rpsl.model.RpslModel;
import ca.rrx.nw.rr.model.rpsl.model.RpslFilters;
import ca.rrx.nw.rr.model.rpsl.model.RpslDefs;

import ca.rrx.nw.rr.control.web.RpslWebImpl;

import java.util.ArrayList;
import java.util.Iterator;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


public final class ReportAction extends Action
{

    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String results;             // results of executed command
        String commandIndex;        // string indicating which command was executed
        String command;             // command to be executed
        String newline;
        String[] sourceStringArray; // results of command in a string array form
        ArrayList matchingObjects;  // array of attribute values of objects that match
                                    //      type selected in object-set drop-down

        String serverProfileName;
        String rpslClassName;
        String rpslInverseAttributeName;
        String rpslFilterExpression;

        Iterator it;
        HttpSession session;

        boolean invalidRpsl;
        int counter;

        OperatorWebImpl operatorWebImpl;
        ServerWebImpl serverWebImpl;
        RouterWebImpl routerWebImpl;

        OperatorModel operatorModel;
        OperatorInformation operatorInformation;
        OperatorSessions operatorSessions;
        OperatorSession currentSession;
        ServerModel serverModel;
        RpslWebImpl rpslWebImpl;
        RpslModel rpslModel;
        RpslFilters rpslFilters;
        RpslDefs rpslDefs;
        String primaryServerProfileId;

        Servers servers;
        Server server;
        ReportForm reportForm;
        ReportEditForm reportEditForm;


        session             = request.getSession();

        operatorWebImpl     = (OperatorWebImpl)session.getAttribute("operatorWebImpl");
        reportForm         = (ReportForm)session.getAttribute("reportForm");
        reportEditForm      = (ReportEditForm)session.getAttribute("reportEditForm");


        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }
        else
        {
            if(session.getAttribute(Constants.USERNAME_KEY).equals("public"))
            {
                serverWebImpl       = new ServerWebImpl();
                rpslWebImpl         = new RpslWebImpl();

                if(reportForm == null)
                {
                    reportForm         = new ReportForm();
                }


                session.setAttribute("serverWebImpl", serverWebImpl);
                session.setAttribute("rpslWebImpl", rpslWebImpl);
            }
            else
            {
                //reportForm         = new ReportForm();
                //serverWebImpl       = (ServerWebImpl)session.getAttribute("serverWebImpl");
                //session.setAttribute("reportForm", reportForm);
            }
        }

/*
        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }
*/
/*
        if(session == null)
        {
            return (mapping.findForward("session_timeout"));
        }
*/


        /*
        if(operatorWebImpl == null)
        {
            operatorWebImpl     = (OperatorWebImpl)request.getAttribute("operatorWebImpl");
        }*/

        serverWebImpl       = (ServerWebImpl)session.getAttribute("serverWebImpl");
        routerWebImpl       = (RouterWebImpl)session.getAttribute("routerWebImpl");

        operatorModel       = operatorWebImpl.getModel((String)session.getValue("MM_Username"));

        if(operatorModel == null)
        {
            operatorModel       = operatorWebImpl.getModel((String)"public");
        }


        rpslWebImpl         = (RpslWebImpl)session.getAttribute("rpslWebImpl");

//        operatorModel       = operatorWebImpl.getModel((String)session.getValue(Constants.USERNAME_KEY));
        operatorInformation = operatorModel.getOperatorInformation();
        operatorSessions    = operatorModel.getOperatorSessions();

        currentSession      = operatorSessions.getOperatorSessionById((Object)session.getValue(Constants.THIS_OPERATOR_SESSION_KEY));

        if(currentSession == null)
        {
            currentSession      = operatorSessions.getOperatorSessionById((Object)operatorInformation.getDefaultSessionId());
        }

//        primaryServerProfileId = (String)currentSession.getPrimaryServerProfileId();

        serverModel         = serverWebImpl.getModel(currentSession.getPrimaryServerProfileId());


        rpslModel           = rpslWebImpl.getModel(operatorInformation.getOperatorId());
        rpslFilters         = rpslModel.getRpslFilters();
        rpslDefs            = rpslModel.getRpslDefs();

        counter             = 0;
        newline             = System.getProperty("line.separator");
        invalidRpsl         = false;
        sourceStringArray   = null;
        results             = null;
        commandIndex        = null;
        command             = null;
        matchingObjects     = new ArrayList();

        // save form to session
        session.setAttribute(Constants.REPORT_KEY, form);

        serverProfileName           = ((ReportForm) form).getServerProfileName();
        rpslClassName               = ((ReportForm) form).getRpslClassName();
        rpslInverseAttributeName    = ((ReportForm) form).getRpslInverseAttributeName();
        rpslFilterExpression        = ((ReportForm) form).getRpslFilterExpression();

        servers             = serverModel.getServers();
        server              = servers.getServerByName(serverProfileName);

        if(request.getParameter("submitEdit") != null)
        {
            commandIndex = "submitEdit";
        }
        else if(request.getParameter("submit1") != null)
        {
            String classParameters;
            commandIndex = "submit1";

            classParameters = "";

            if(rpslClassName.trim().equals("all"))
            {
                classParameters = "";
            }
            else
            {
                classParameters = " -T " + rpslClassName;
            }

            String commandPrefix       =  Constants.WHOIS + server.getServerIpv4() + " -p " + server.getQueryPort();
            
            command = commandPrefix + classParameters + " -i " + rpslInverseAttributeName + " " + rpslFilterExpression;
        }
        /*else if(request.getParameter("submitEdit") != null)
        {
            commandIndex = "submitEdit";
        }*/
        else if(request.getParameter("submitSaveToFile") != null)
        {
            commandIndex = "submitSaveToFile";
        }
        else if((request.getParameter("rpslClassName") != null) 
            && (request.getParameter("submit1") == null))
        {
            commandIndex = "rpslClassName";
        }



        if(commandIndex != null)
        {
            // if as-set drop-down was changed, the updateMembership process occurs
            if(commandIndex.equals("rpslClassName"))
            {
                rpslClassName = ((ReportForm) form).getRpslClassName();
                ((ReportForm)form).setRpslClassName(rpslClassName);

                if(rpslClassName.trim().equals("all"))
                {
                    request.getSession().setAttribute("rpslInverseAttributeNamesBean", 
                        rpslDefs.getInverseAttributeNames());
//                    pageContext.setAttribute("rpslInverseAttributeNamesBean", rpslDefs.getInverseAttributeNames());
                }
                else
                {
                    request.getSession().setAttribute("rpslInverseAttributeNamesBean", 
                        rpslDefs.getInverseAttributeNames(rpslClassName));
                }

//                ((ReportForm)form).setResults(rpslClassName);
            }
            else if(commandIndex.equals("submit1"))
            {

                results = exec(command);

                ((ReportForm)form).setCommand(command);
                ((ReportForm)form).setCommandIndex(commandIndex);
                ((ReportForm)form).setServerProfileName(serverProfileName);
                ((ReportForm)form).setResults(results);

                reportForm.setResults(results);
                reportForm.setCommand(command);
//                ((ReportForm)form).setResults(serverProfileName + " " + server.getServerIpv4() + "\n\r\n\r" + results);
            }
            else if(commandIndex.equals("submitSaveToFile"))
            {
                return (mapping.findForward("report_success"));
            }
            else if(commandIndex.equals("submitEdit"))
            {
                if(reportEditForm != null)
                {
                    reportEditForm.setRpslToSubmit(null);
                }

                return (mapping.findForward("report_edit"));
            }
        }


/*
        if (servlet.getDebug() >= 1)
        {
          servlet.log("ReportAction: Report '" + objectSet + " , " + membership + 
                      "' in session " + session.getId());
        }
*/
        // Forward control to the success URI specified in struts-config.xml
        return (mapping.findForward("report_success"));
    }

    /**
     * Accepts an arraylist containing strings returned from a whois query.
     * Goes through the lines and retireves memberships.
     *
     */
/*
    private String[][] parseMemberships(ArrayList s)
    {
        String[][] membershipChoices;
        Iterator it;
        int counter;

        counter = 0;
        it = s.iterator();
        membershipChoices = null;

        if(s.size() > 0)
        {
            membershipChoices = new String[s.size()][2];

            while(it.hasNext())
            {
                String val;

                val = (String)it.next();
                membershipChoices[counter][0] = val;  // set the display attribute
                membershipChoices[counter][1] = val;  // set the value attribute
                counter++;
            }
        }

        return(membershipChoices);
    }
*/

    private void initMembership(HttpSession session, String[][] membershipChoices)
    {
        session.setAttribute(Constants.REPORT_MEMBERSHIP_KEY, membershipChoices);
    }


    /**
     * Accepts a string that is executed as an external command.
     *
     * @param cmd Command to be executed.
     */
    public String exec(String cmd)
    {
        StringBuffer stringBuffer;
        String newline;

        stringBuffer    = new StringBuffer();
        newline         = System.getProperty("line.separator");

        try
        {
            Process process;
            InputStream in;
            BufferedReader reader;
            String line;
            int c;

            process = Runtime.getRuntime().exec(cmd);
            in      = process.getInputStream();
            reader  = new BufferedReader(new InputStreamReader(in));

            c = 0;

            do
            {
                line = reader.readLine();

                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }

                c++;
            }
            while(line != null);

            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Error in ReportAction.java");
        }

        return(new String(stringBuffer));
    }


    /**
     * Accepts a string with lines separated by '\n' and places each
     * line into a separate element of a string array.
     *
     * @param s String to be split into array elements (lines delimited with '\n').
     * @return String array, each element containing one line text.
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        trimArray(temp);

        return((String[])temp.toArray(new String[]{}));
    }


    /**
     * Removes leading empty Strings from an ArrayList of String
     * objects.
     *
     * @param t 
     *
     */
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;

        idxRemove = new int[100];
        count = 0;

        if(!t.isEmpty())
        {

            for(int i = 0 ; i < t.size() ; i++)
            {
               String s;

               s = t.get(i).toString().trim();

               if(s.length() == 0)
               {
                   idxRemove[count] = i;
                   count++;
               }
               else
               {
                   break;
               }
            }

            for(int i = count ; i > 0 ; i--)
            {
                  t.remove(0);
            }
        }
    }
}