package ca.rrx.nw.rr.struts.aList;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class RouterAccessListProfileForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List routerProfileNames;
    protected List manufacturerNames;
    protected List modelNames;
  
    protected String maintainerCode;
    protected String routerProfileName;
    protected String dnsName;
    protected String locationCode;
    protected String localAs;
    protected String manufacturer;
    protected String model;
    protected String series;
    protected String mainSerialNumber;
    protected String manufacturedDate;
    protected String installationDate;
    protected String osVersion;
    protected String osUpgradeDate;
    protected String osFeatures;
    protected String remarks;
    
    protected String rpslInetRtr;
    

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getManufacturerNames(){
        manufacturerNames = new ArrayList();
        manufacturerNames.add("Cisco Systems");
        manufacturerNames.add("Juniper Systems");
        manufacturerNames.add("Nortel Networks");
        return manufacturerNames;
    }
    
    public void setManufacturerNames(List manufacturerNames) {
        this. manufacturerNames = manufacturerNames;
    }
    
    public List getModelNames(){
      //  modelNames = new ArrayList();
      //  if (manufacturer.equals("Cisco Systems")) 
      //  {
        modelNames = new ArrayList();
        modelNames.add("120XX");
        modelNames.add("110XX");
        modelNames.add("75XX");
        modelNames.add("65XX");
     //   }
        if (manufacturer.equals("Juniper Systems")) {
        modelNames = new ArrayList();
        modelNames.add("M-5");
        modelNames.add("M-20");
        modelNames.add("M-40");
        modelNames.add("M-160");
        }
        if (manufacturer.equals("Nortel Networks")) {
        modelNames = new ArrayList();
        modelNames.add("15000");
        modelNames.add("25000");
        modelNames.add("85XX");
        }
        return modelNames;
    }
    
    public void setModelNames(List modelNames) {
        this. modelNames = modelNames;
    }
    
    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this. maintainerCode = maintainerCode;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public String getDnsName() {
        return dnsName;
    }
    
    public void setDnsName(String dnsName) {
        this. dnsName = dnsName;
    }
    
    public String getLocationCode() {
        return locationCode;
    }
    
    public void setLocationCode(String locationCode) {
        this. locationCode = locationCode;
    }
    
    public String getLocalAs() {
        return localAs;
    }
    
    public void setLocalAs(String localAs) {
        this. localAs = localAs;
    }
    
    public String getManufacturer() {
        return manufacturer;
    }
    
    public void setManufacturer(String manufacturer) {
        this. manufacturer = manufacturer;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this. model = model;
    }
    
    public String getSeries() {
        return series;
    }
    
    public void setSeries(String series) {
        this. series = series;
    }
    
    public String getMainSerialNumber() {
        return mainSerialNumber;
    }
    
    public void setMainSerialNumber(String mainSerialNumber) {
        this. mainSerialNumber = mainSerialNumber;
    }
    
    public String getManufacturedDate() {
        return manufacturedDate;
    }
    
    public void setManufacturedDate(String manufacturedDate) {
        this. manufacturedDate = manufacturedDate;
    }
    
    public String getInstallationDate() {
        return installationDate;
    }
    
    public void setInstallationDate(String installationDate) {
        this. installationDate = installationDate;
    }
    
    public String getOsVersion() {
        return osVersion;
    }
    
    public void setOsVersion(String osVersion) {
        this. osVersion = osVersion;
    }
    
    public String getOsUpgradeDate() {
        return osUpgradeDate;
    }
    
    public void setOsUpgradeDate(String osUpgradeDate) {
        this. osUpgradeDate = osUpgradeDate;
    }
    
    public String getOsFeatures() {
        return osFeatures;
    }
    
    public void setOsFeatures(String osFeatures) {
        this. osFeatures = osFeatures;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this. remarks = remarks;
    }
    
    public String getRpslInetRtr(){
        return rpslInetRtr;
    }
            
    public void setRpslInetRtr(String rpslInetRtr){
        this.rpslInetRtr = rpslInetRtr;
    }   

    
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterForm error: " + pce);
        }
        return null;
    }
}