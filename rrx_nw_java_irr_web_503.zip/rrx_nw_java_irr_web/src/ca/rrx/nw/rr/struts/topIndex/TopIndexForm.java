package ca.rrx.nw.rr.struts.topIndex;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class TopIndexForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables


    protected String languageSelected;
    protected String lang;
    protected List languageNames;

    // ----------------------------------------------------------- Properties

    

        
    public List getLanguageNames(){
        languageNames = new ArrayList();
        languageNames.add("EN");
        languageNames.add("FR");
        return languageNames;
    }
    
    public void setLanguageNames(List languageNames) {
        this. languageNames = languageNames;
    }
    

      
    public String getLang() {
        return lang;
    }
    
    public void setLang(String lang) {
        this.lang = lang;
    }
    
    public String getLanguageSelected() {
        return languageSelected;
    }
    
    public void setLanguageSelected(String languageSelected) {
        this.languageSelected = languageSelected;
    }
    


    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

        this.languageSelected = null;
        this.lang = null;

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*

        
        if ((languageSelected == null) || (languageSelected.length() < 1))
        {
            errors.add("languageSelected", new ActionError("error.languageSelected.required"));
        }
        
        if ((language == null) || (language.length() < 1))
        {
            errors.add("language", new ActionError("error.language.required"));
        }
        
        
      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("OperatorForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("OperatorForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("OperatorForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("OperatorForm error: " + pce);
        }
        return null;
    }
}