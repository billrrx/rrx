package ca.rrx.nw.rr.struts.router;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.NumberFormat;
import java.text.ParseException;


import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.Constants;

import ca.rrx.nw.rr.model.router.model.RouterModel;
import ca.rrx.nw.rr.model.router.model.Routers;
import ca.rrx.nw.rr.model.router.model.Router;
import ca.rrx.nw.rr.model.router.model.RouterInformation;
import ca.rrx.nw.rr.model.router.model.ControlPorts;
import ca.rrx.nw.rr.model.router.model.ControlPort;
import ca.rrx.nw.rr.model.router.model.ControlConnections;
import ca.rrx.nw.rr.model.router.model.ControlConnection;
import ca.rrx.nw.rr.model.router.model.Templates;
import ca.rrx.nw.rr.model.router.model.Template;

import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.server.model.ServerModel;

import ca.rrx.nw.rr.control.web.RouterWebImpl;
import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.control.web.ServerWebImpl;

import ca.rrx.nw.rr.struts.router.RouterConfigurationForm;

import ca.rrx.nw.rr.util.Debug;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.io.PrintStream;
import java.io.File;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import org.netbeans.lib.cvsclient.Client;
import org.netbeans.lib.cvsclient.admin.AdminHandler;
import org.netbeans.lib.cvsclient.admin.StandardAdminHandler;
import org.netbeans.lib.cvsclient.command.GlobalOptions;
import org.netbeans.lib.cvsclient.command.checkout.CheckoutCommand;
import org.netbeans.lib.cvsclient.command.commit.CommitCommand;
import org.netbeans.lib.cvsclient.command.diff.DiffCommand;
import org.netbeans.lib.cvsclient.command.status.StatusCommand;
import org.netbeans.lib.cvsclient.command.update.UpdateCommand;
import org.netbeans.lib.cvsclient.connection.Connection;
import org.netbeans.lib.cvsclient.connection.ServerConnection;
import org.netbeans.lib.cvsclient.event.CVSAdapter;
import org.netbeans.lib.cvsclient.event.MessageEvent;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.model.router.model.Template;
import ca.rrx.nw.rr.model.router.model.Configuration;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

public final class RouterConfigurationProfileAction extends Action
{
    private RouterWebImpl routerWebImpl;

    {
        routerWebImpl = null;
    }

    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
             

      // Switch for Debug Mode (true/false)
        boolean debugMode = false;        
        
        // Variable Declaration and Initalization
        String           commandIndex           = request.getParameter("commandIndex");
        String           submitSaveNew          = request.getParameter("submitSaveNew");
        String           submitHistory          = request.getParameter("submitHistory");
        String           submitRouterProfile    = request.getParameter("submitRouterProfile");
        String           submitDelete           = request.getParameter("submitDelete");
        String           submitSave             = request.getParameter("submitSave");
        String           submitDefault          = request.getParameter("submitDefault");
        String           configurationTimeStamp = request.getParameter("configurationTimeStamp");

        String           remarks                = request.getParameter("remarks");
        String           commandLine            = request.getParameter("commandLine");

    //Debug.println("RouterConfigurationProfileAction - 1");

     
        OperatorWebImpl  		operatorWebImpl;
        String           		operatorLoginName;

     
       // init local parameters
        
        Locale           		locale           		= getLocale(request);
        MessageResources 		messageResources 		= getResources();
        
        // Session Paramaters and Beans
        
        HttpSession 			session               		= request.getSession();

        //set to copy of bean
        RouterConfigurationProfileForm routerConfigurationProfileForm = ((RouterConfigurationProfileForm) form);
        RouterConfigurationProfileForm routerConfigurationProfileFormBean;
        routerConfigurationProfileFormBean = (RouterConfigurationProfileForm)session.getAttribute("routerConfigurationProfileForm");        
        

        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        //get the session beans from the session 
        
        if (session.getValue("operatorWebImpl") != null) 
        {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        } 
        else 
        {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getValue("routerWebImpl") != null) 
        {
            routerWebImpl = (RouterWebImpl) session.getAttribute("routerWebImpl");
        } 
        else 
        {  //diag only - should error out here if there is no bean in the session
            routerWebImpl = new RouterWebImpl();
        }
              
        //  get the operatorLoginName from the session
 
        if ((String)session.getValue("MM_Username") != null) operatorLoginName = (String)session.getAttribute("MM_Username");
     
        //  Get the Operator Model
      
        OperatorModel       operatorModel       = operatorWebImpl.getModel((String)session.getValue("MM_Username"));
        OperatorInformation operatorInformation = operatorModel.getOperatorInformation();
        OperatorSessions    operatorSessions    = operatorModel.getOperatorSessions();
        OperatorSession     currentSession      = operatorSessions.getOperatorSessionById(operatorInformation.getDefaultSessionId());
        String              maintainerCode      = operatorInformation.getMaintainerCodes();

        //  Get the Router Model

        RouterModel         routerModel         = routerWebImpl.getModel(maintainerCode);
        Routers             routers             = routerModel.getRouters();
        List                rNames              = routers.getRouterProfileNames();

        if (rNames.isEmpty())
        {
            return (mapping.findForward("router_profile_new"));
        }   

        // Get Current Profile information - From List of Router Names

        String currentRouterProfileName = null;
        Object currentRouterProfileId = routerModel.getRouters().getRouterByName(rNames.get(0)).getRouterProfileId();
        
         
        if (request.getParameter("routerProfileName") != null) 
        {
            currentRouterProfileName  = request.getParameter("routerProfileName");
            currentRouterProfileId  = routerModel.getRouters().getRouterByName(currentRouterProfileName).getRouterProfileId();
           
        }

        session.putValue(Constants.ROUTER_KEY,currentRouterProfileId);          

        Router             router               = routers.getRouterById((Object)currentRouterProfileId);
        RouterInformation  routerInformation    = router.getRouterInformation();
        String             routerProfileName    = routerInformation.getRouterProfileName();

        // get the Templates

        Templates     templates       = router.getTemplates();
        List               templateTimeStamps               = templates.getTemplateTimeStamps();

        if (templateTimeStamps.isEmpty())
        {
           return (mapping.findForward("router_configuration_profile_new"));     
        }

        Object             objProfileName     = templateTimeStamps.get(0);
        
        Template           template           = templates.getTemplateByTimeStamp((Object)objProfileName);
        Object             currentTemplateId  = template.getRouterConfigurationId();       
 //Debug.println("RouterConfigurationProfileAction - 2");
        if (request.getParameter("configurationTimeStamp") != null) 
        {
           if  (submitRouterProfile != null && submitRouterProfile.equals("Ok"))
           {
               template                       = templates.getTemplateByTimeStamp((Object)objProfileName);
               currentTemplateId              = template.getRouterConfigurationId();
               routerConfigurationProfileFormBean.setCurrentTemplate(template.getConfigurationTemplate());
               routerConfigurationProfileFormBean.setConfigurationTimeStamp(request.getParameter("configurationTimeStamp"));
               session.setAttribute(Constants.TEMPLATE_DEFAULT_CMD_KEY, null);
           }
           else
           {
               template                       = templates.getTemplateByTimeStamp(request.getParameter("configurationTimeStamp"));
               if (template != null)
               {
                  currentTemplateId           = template.getRouterConfigurationId();
                  routerConfigurationProfileFormBean.setCurrentTemplate(template.getConfigurationTemplate());
                  routerConfigurationProfileFormBean.setConfigurationTimeStamp(request.getParameter("configurationTimeStamp"));
                  session.setAttribute(Constants.TEMPLATE_DEFAULT_CMD_KEY, null);
               }
               else
               {
                  template                    = templates.getTemplateByTimeStamp((Object)objProfileName);
                  currentTemplateId           = template.getRouterConfigurationId();
                  routerConfigurationProfileFormBean.setCurrentTemplate(template.getConfigurationTemplate());
                  routerConfigurationProfileFormBean.setConfigurationTimeStamp(request.getParameter("configurationTimeStamp"));
                  session.setAttribute(Constants.TEMPLATE_DEFAULT_CMD_KEY, null);
               }
            } 
        }

       String filePath      = Constants.MAINTAINER_BASE_DIR + "/"  
                                +  maintainerCode + "/" 
                                +  currentRouterProfileName +  "/" 
                                + "templates" +  "/" ;

       String fileName      = Constants.MAINTAINER_BASE_DIR + "/"  
                                +  maintainerCode + "/" 
                                +  currentRouterProfileName + "/" 
                                + "templates" +  "/" 
                                +  template.getTimeStored();

//       routerConfigurationProfileForm.setCurrentTemplate(template.loadFile(fileName,"ASCII"));
//Debug.println("RouterConfigurationProfileAction - 3 " + fileName);

        if (debugMode)
        {
            //Debug.println("RouterConfigurationProfileAction - Initialization:routerConfigurationProfileForm:currentTemplateId="+ currentTemplateId); 
        }
 
       /* ---------------------------------------------------
        *   Action Processiong  -  Refresh Selected Router Profile   
        *---------------------------------------------------*/
        
        if ( submitRouterProfile != null )
        {
            if (debugMode)
            {
                //Debug.println("RouterConfigurationrProfileAction - Router Profile:="); //+ routerConfigurationProfileForm.getRouterProfileName());
            }

            return (mapping.findForward("router_configuration_profile_success"));
       }

       /* ---------------------------------------------------
        *   Action Processiong  -  Refresh Selected TimeStamp    
        *---------------------------------------------------*/
        
        if ( submitHistory != null )
        {
            if (debugMode)
            {
                //Debug.println("RouterConfigurationProfileAction - Configuration Time Stamp:="); //+ routerConfigurationProfileForm.getConfigurationTimeStamp());
            }

            return (mapping.findForward("router_configuration_profile_success"));
        } 

        // --------------------------------------------------
        // Action Processiong  -  Save as a new router configuration profile
        // --------------------------------------------------
        if (submitSaveNew != null)
        {
            //Debug.println("RouterConfigurationProfileAction: Process submitSaveNew");
            String   s;
            String[] results;
            String newline;
            String fileNew = null;
            String timeStored = null;

            timeStored = generateTimestamp();

            Template newTemplate;
            newTemplate = new Template();

            newTemplate.setRouterProfileId(currentRouterProfileId);

            newTemplate.setTimeStored(timeStored);
            newTemplate.setPointerType("template");
            newTemplate.setRemarks(remarks);
            newTemplate.setCommandLine(commandLine);
            newTemplate.setRevision("1");
            newTemplate.setConfigurationTemplate(routerConfigurationProfileForm.getCurrentTemplate());    
            
            routerWebImpl.add(newTemplate);
            routerWebImpl = new RouterWebImpl();
            session.setAttribute("routerWebImpl", routerWebImpl);
        }

        if(submitSave != null)
        {
        //Debug.println("RouterConfigurationProfileAction: Process submitSave");
        //System.out.println("RouterConfigurationProfileAction: Process submitSave");


            String   s;
            String[] results;
            String newline;
            String fileNew = null;
            String timeStored = null;

            template.setRouterProfileId(currentRouterProfileId);

            template.setTimeStored(configurationTimeStamp);
            template.setPointerType("template");
            template.setRemarks(remarks);
            template.setCommandLine(commandLine);
            template.setRevision("1");
            template.setConfigurationTemplate(routerConfigurationProfileForm.getCurrentTemplate());    

            routerWebImpl.update(template);
            routerWebImpl = new RouterWebImpl();
            session.setAttribute("routerWebImpl", routerWebImpl);


            // just to test
//            return (mapping.findForward("router_control_port_profile_success"));
            return (mapping.findForward("router_configuration_profile_success"));
        }

        if(submitDelete != null)
        {
            Template newTemplate = new Template();
            Object routerConfigurationId = null;
            
            // set the mockup to null
            newTemplate.setRouterConfigurationId(routerConfigurationId);
            
            // fill in the values for the mockup
            newTemplate.setTimeStored(configurationTimeStamp);
            newTemplate.setPointerType("template");
            newTemplate.setRemarks(remarks);
            newTemplate.setCommandLine(commandLine);
            newTemplate.setRevision("1");
            Template tmp =     templates.getTemplateByTimeStamp(configurationTimeStamp);
            if (!tmp.equals(null))routerWebImpl.delete(tmp);
            routerWebImpl = new RouterWebImpl();
            session.setAttribute(Constants.TEMPLATE_DEFAULT_CMD_KEY, null);
            session.setAttribute("routerWebImpl", routerWebImpl);
            return (mapping.findForward("router_configuration_profile_success"));
        }

        if(submitDefault != null)
        {
            String routerManufacturer = routerInformation.getManufacturer();
            String routerManufacturerOs = "cisco"; //default for RtConfig
            if(routerManufacturer != null)
            {
                if(routerManufacturer.equals("Cisco Systems"))
                {
                    routerManufacturerOs = "cisco";
                }
                else if(routerManufacturer.equals("Nortel"))
                {
                    routerManufacturerOs = "bcc";
                }
                else if(routerManufacturer.equals("Juniper"))
                {
                    routerManufacturerOs = "junos";
                }
            }
            session.setAttribute(Constants.TEMPLATE_DEFAULT_CMD_KEY, "-h " + Constants.DEFAULT_PRIMARY_IRR_DNS + " -p " + Constants.DEFAULT_PORT + " -protocol ripe -config " + routerManufacturerOs);
            return (mapping.findForward("router_configuration_profile_success"));
        }

        if(servlet.getDebug() >= 1)
        {
            servlet.log("RouterConfigurationProfileAction: TemplateId '" 
                    + currentTemplateId + "' in session " 
                    + session.getId());
        }

        return (mapping.findForward("router_configuration_profile_success"));
    }


    private String generateTimestamp()
    {
        Calendar c;
        String newTimestamp;
        NumberFormat nf;
        String year;
        String month;
        String day;
        String hour;
        String minute;
        String second;

        int yearInt;
        int monthInt;
        int dayInt;
        int hourInt;
        int minuteInt;
        int secondInt;

        nf = NumberFormat.getInstance();
        c = new GregorianCalendar();

        yearInt     = c.get(Calendar.YEAR);
        monthInt    = c.get(Calendar.MONTH) + 1;
        dayInt      = c.get(Calendar.DAY_OF_MONTH);
        hourInt     = c.get(Calendar.HOUR_OF_DAY);
        minuteInt   = c.get(Calendar.MINUTE);
        secondInt   = c.get(Calendar.SECOND);

        nf.setMinimumIntegerDigits(2);
        
        year   = (new Integer(yearInt)).toString();
        month   = nf.format(monthInt);
        day     = nf.format(dayInt);
        hour    = nf.format(hourInt);
        minute  = nf.format(minuteInt);
        second  = nf.format(secondInt);

        newTimestamp = year +  ":" + month +  ":" + day + "-" + hour + ":" + minute + ":" +  second;

        return (newTimestamp);
    }

    /*---------------------------------------------------
     *   Function to Split String     
     *---------------------------------------------------*/
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();


        for(int i = 0 ; i < s.length(); i++)

        {

            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        return((String[])temp.toArray(new String[]{}));
    }
    

    /*---------------------------------------------------
     *   Copy Form Properties to Router Model     
     *---------------------------------------------------*/
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException
    {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("RouterConfigurationProfileAction: No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("RouterConfigurationProfileAction: No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("RouterConfigurationProfileAction:copyObjectProperties ", t);
            throw new ServletException("RouterConfigurationProfileAction:copyObjectProperties ", t);
        } catch (Throwable t) 
        {
            servlet.log("RouterConfigurationProfileAction:copyObjectProperties ", t);
            throw new ServletException("RouterConfigurationProfileAction:copyObjectProperties ", t);
        }
    }
}
