package ca.rrx.nw.rr.struts.aQuery;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**

 */
public final class AdvancedQueryForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    private String key;
    private String type;
    private String inv;
    private String[] source;
    private String template;
    private String serverProfileName;
    private String command;
    private String commandIndex;
    private String results;

    {
        key             = null;
        type            = null;
        inv             = null;
        source          = null;
        template        = null;
        serverProfileName   = null;
        command         = null;
        commandIndex    = null;
        results         = null;
    }

    // ----------------------------------------------------------- Properties

    public String getKey()
    {
        return (this.key);
    }

    public void setKey(String k)
    {
        this.key = k;
    }

    public String getType()
    {
        return (this.type);
    }

    public void setType(String t)
    {
        this.type = t;
    }

    public String getInv()
    {
        return (this.inv);
    }

    public void setInv(String i)
    {
        this.inv = i;
    }

    public String[] getSource()
    {
//            String[] paramValues;
        return (this.source);
    }

    public void setSource(String[] s)
    {
        this.source = s;
    }

    public String getTemplate()
    {
        return (this.template);
    }

    public void setTemplate(String t)
    {
        this.template = t;
    }


    public String getServerProfileName()
    {
        return (this.serverProfileName);
    }

    public void setServerProfileName(String serverProfileName)
    {
        this.serverProfileName = serverProfileName;
    }

    /**
     * Return the generated command.
     */
    public String getCommand()
    {
        return (this.command);
    }

    /**
     * Set the command.
     *
     * @param tm The new comand
     */
    public void setCommand(String cmd)
    {
        this.command = cmd;
    }

    public String getCommandIndex()
    {
        return (this.commandIndex);
    }

    public void setCommandIndex(String ci)
    {
        this.commandIndex = ci;
    }

    /**
     * Return the results.
     */
    public String getResults()
    {
        return (this.results);
    }

    /**
     * Set the results.
     *
     * @param tm The new results
     */
    public void setResults(String res)
    {
        this.results = res;
    }

    // --------------------------------------------------------- Public Methods


    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.key            = "";
        this.type           = null;
        this.inv            = null;
        this.source         = null;
        this.template       = null;
        this.command        = null;
        this.commandIndex   = null;
        this.results        = null;
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((tier == null) || (tier.length() < 1))
        {
            errors.add("tier", new ActionError("error.tier.required"));
        }

        if ((tiermaint == null) || (tiermaint.length() < 1))
        {
            errors.add("tiermaint", new ActionError("error.tiermaint.required"));
        }
*/
        return errors;
    }
}
