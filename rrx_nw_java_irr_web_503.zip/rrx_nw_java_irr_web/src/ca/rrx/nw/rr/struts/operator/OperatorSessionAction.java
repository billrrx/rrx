
package ca.rrx.nw.rr.struts.operator;

import ca.rrx.nw.rr.Constants;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.Iterator;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.*;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.*;

import ca.rrx.nw.rr.control.web.RpslWebImpl;
import ca.rrx.nw.rr.model.rpsl.model.RpslModel;
import ca.rrx.nw.rr.model.rpsl.model.RpslFilters;
import ca.rrx.nw.rr.model.rpsl.model.RpslFilter;
import ca.rrx.nw.rr.model.rpsl.model.RpslDefs;

import ca.rrx.nw.rr.control.web.RouterWebImpl;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

import ca.rrx.nw.rr.util.Debug;



public final class OperatorSessionAction extends Action
{
        OperatorWebImpl operatorWebImpl;
        ServerWebImpl serverWebImpl;
        RpslWebImpl rpslWebImpl;
        RouterWebImpl routerWebImpl;
        
        OperatorModel operatorModel;
        ServerModel serverModel;
        Servers servers;
        RpslModel rpslModel;
        
    public ActionForward perform(ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException
    {
         
        //get the session
        HttpSession session  = request.getSession();


       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        //get the session beans from the session - Bill R
        
        if (session.getAttribute("operatorWebImpl") != null) {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null) {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }
        
        if (session.getAttribute("rpslWebImpl") != null) {
            rpslWebImpl = (RpslWebImpl) session.getAttribute("rpslWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            rpslWebImpl = new RpslWebImpl();
        }
        
        if (session.getAttribute("routerWebImpl") != null) {
            routerWebImpl = (RouterWebImpl) session.getAttribute("routerWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            routerWebImpl = new RouterWebImpl();
        }
        //this is it seems a copy of the bean in the session
        OperatorSessionForm operatorSessionForm = ((OperatorSessionForm) form);
        
        Locale locale        = (Locale)session.getAttribute("language");
        //safety for nulls - temp Bill R
        String operatorLoginName = "operator";
        Object operatorId = new Integer(0);
        Object currentOperatorSessionId = new Integer(0);
        Object defaultOperatorId = new Integer(0);
        Object defaultSessionProfileId = new Integer(0);
        String currentOperatorSessionName = "session";
        
        if ((String)session.getAttribute("MM_Username") != null) operatorLoginName = (String)session.getAttribute("MM_Username");
        operatorModel = operatorWebImpl.getModel(operatorLoginName);
        OperatorInformation operatorInformation = operatorModel.getOperatorInformation();
        
        OperatorSessions operatorSessions = operatorModel.getOperatorSessions();
        operatorId = operatorSessions.getOperatorId();
        //----------
        currentOperatorSessionId = session.getAttribute(Constants.THIS_OPERATOR_SESSION_KEY);
        OperatorSession currentOperatorSession = operatorSessions.getOperatorSessionById(currentOperatorSessionId);
        currentOperatorSessionName = currentOperatorSession.getSessionProfileName();
        //------------
        serverModel = serverWebImpl.getModel(currentOperatorSession.getPrimaryServerProfileId());
        servers = serverModel.getServers();
        
        rpslModel = rpslWebImpl.getModel(operatorInformation.getOperatorId());
        RpslFilters rpslFilters = rpslModel.getRpslFilters();
        RpslFilter rpslFilter = null;
        List existingFilters = null;
        RpslDefs rpslDefs = rpslModel.getRpslDefs();
        
        String submitNew = request.getParameter("submitNew");
        String submitUpdate = request.getParameter("submitUpdate");
        String submitSaveAs= request.getParameter("submitSaveAs");
        String submitDelete = request.getParameter("submitDelete");
        
        String sessionProfileName = request.getParameter("sessionProfileName");
        
        String primaryClassName = request.getParameter("primaryClassName");
        
        String primaryServerProfileName = request.getParameter("primaryServerProfileName");

        String submitPrimaryPopulateFilters = request.getParameter("submitPrimaryPopulateFilters");

        String submitPrimaryRpslAdd = request.getParameter("submitPrimaryRpslAdd");
        String submitPrimaryRpslDelete = request.getParameter("submitPrimaryRpslDelete");
        
        String secondaryClassName = request.getParameter("secondaryClassName");
        
        String secondaryServerProfileName = request.getParameter("secondaryServerProfileName");
        
        String submitSecondaryPopulateFilters = request.getParameter("submitSecondaryPopulateFilters");
        
        String submitSecondaryRpslAdd = request.getParameter("submitSecondaryRpslAdd");
        String submitSecondaryRpslDelete = request.getParameter("submitSecondaryRpslDelete");
        
        OperatorSession modifiedOperatorSession = null;
        OperatorSession selectedOperatorSession = operatorSessions.getOperatorSessionByName(request.getParameter("sessionProfileName"));
        
        //note: event handlers are sequence sensitive... Bill R
        
        if  (submitUpdate != null)
        {   
            System.out.println("OperatorSessionAction: process submitUpdate");

            modifiedOperatorSession = operatorSessions.getOperatorSessionByName(request.getParameter("sessionProfileName"));

            //get ref to bean due to hidden fields
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            //overwrite the fresh ones with the form stuff - Bill R
            copyNotNullObjectProperties(modifiedOperatorSession, operatorSessionForm);
            modifiedOperatorSession.setMaintainerCode(request.getParameter("maintainerCode"));


            modifiedOperatorSession.setRelativeConfigPath(request.getParameter("relativeConfigPath"));
/*
            modifiedOperatorSession.setMaintainerCode(request.getParameter(""));
            modifiedOperatorSession.setNicHandle(request.getParameter(""));
            modifiedOperatorSession.setSessionProfileName(request.getParameter(""));
            modifiedOperatorSession.primaryServerProfileId(request.getParameter(""));
            modifiedOperatorSession.secondaryServerProfileId(request.getParameter(""));
            modifiedOperatorSession.remarks(request.getParameter(""));
*/
            //update the database
            operatorWebImpl.update(modifiedOperatorSession);


            // $ben$ - clear old bean
            serverWebImpl = new ServerWebImpl();
            session.setAttribute("serverWebImpl", serverWebImpl);

            //flag beans model to null so reloads the database on findForward
            // $billr$ - clear old bean
            operatorWebImpl = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            
            routerWebImpl = new RouterWebImpl();
            session.setAttribute("routerWebImpl", routerWebImpl);

            return (mapping.findForward("operator_session_profile_success"));
//            return (mapping.findForward("router_configuration_profile_success"));
        }
        //in progress - Bill R
        if  (submitNew != null) 
        {
         return (mapping.findForward("operator_session_profile_success"));   
        }
        
        if (submitDelete != null)
        {
          //should be modified to go to error page if operator tries to delete a working session either default or current - Bill R
        modifiedOperatorSession = operatorSessions.getOperatorSessionByName(request.getParameter("sessionProfileName"));
        
        operatorWebImpl.delete(modifiedOperatorSession);
        
        //flag beans model to null so reloads the database on findForward
        operatorModel = null;
        
        return (mapping.findForward("operator_session_profile_success"));    
        }
        
        
        //use operator 0 default rpslFilters to populate the filters for this server for this session profile
        if (submitPrimaryPopulateFilters != null)
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            //pick up default filters
            RpslModel defaultRpslModel = rpslWebImpl.getModel(defaultOperatorId);
        
            RpslFilters defaultRpslFilters = defaultRpslModel.getRpslFilters(); 
        
            Collection defaultRpslFiltersCollection =   defaultRpslFilters.getRpslFilters();
            
            Iterator defaultRpslFiltersCollectionIterator = defaultRpslFiltersCollection.iterator();
            
            while (defaultRpslFiltersCollectionIterator.hasNext()) {
            
                RpslFilter currentDefaultRpslFilter = (RpslFilter)defaultRpslFiltersCollectionIterator.next();
                rpslModel = rpslWebImpl.getModel(operatorSessionForm.getOperatorId());
                rpslFilters = rpslModel.getRpslFilters();
                existingFilters = rpslFilters.getFilterExpressions(operatorSessionForm.getOperatorId(), 
                                    operatorSessionForm.getSessionProfileId(), currentDefaultRpslFilter.getRpslObjectType(),
                                    currentDefaultRpslFilter.getRpslAttributeType());
                
                //if the exisitng list doesn't include this filterExpression then add it to the database
                if (!existingFilters.contains(currentDefaultRpslFilter.getFilterExpression())) {
                
                    if (currentDefaultRpslFilter.getServerProfileId().equals(operatorSessionForm.getPrimaryServerProfileId())) {

                    rpslFilter = new RpslFilter();
                    rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
                    rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
                    rpslFilter.setServerProfileId(operatorSessionForm.getPrimaryServerProfileId());
                    rpslFilter.setRpslObjectType(currentDefaultRpslFilter.getRpslObjectType());
                    rpslFilter.setRpslAttributeType(currentDefaultRpslFilter.getRpslAttributeType());
                    rpslFilter.setFilterExpression(currentDefaultRpslFilter.getFilterExpression());
                    ////Debug.println("OperatorSessionAction: submitPrimaryPopulateFilters rpslFilter = " + rpslFilter);


                    rpslWebImpl.add(rpslFilter);
                    }
                }
            }
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
        return (mapping.findForward("operator_session_profile_success")); 
        }
            
        if (submitPrimaryRpslDelete != null)
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            rpslFilter = new RpslFilter();
            Object rpslFilterId = null;
            
            // set the mockup to null
            rpslFilter.setRpslFilterId(rpslFilterId);
            
            // fill in the values for the mockup
            rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
            rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
            rpslFilter.setServerProfileId(operatorSessionForm.getPrimaryServerProfileId());
            rpslFilter.setRpslObjectType(request.getParameter("primaryClassName"));
            rpslFilter.setRpslAttributeType(request.getParameter("primaryInverseAttributeName"));
            rpslFilter.setFilterExpression(request.getParameter("primaryFilterExpression"));
            
            //get the id of the mockup
            rpslFilterId = rpslFilters.getRpslFilterId(rpslFilter);
            //delete the id from the dao - db
            if (!rpslFilterId.equals(null)) rpslWebImpl.delete(rpslFilterId);
            //set the model to null to refresh the jsp
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
            
            return (mapping.findForward("operator_session_profile_success")); 
        }
        
        if (submitPrimaryRpslAdd != null)
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            rpslFilter = new RpslFilter();
            rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
            rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
            rpslFilter.setServerProfileId(operatorSessionForm.getPrimaryServerProfileId());
            rpslFilter.setRpslObjectType(request.getParameter("primaryClassName"));
            rpslFilter.setRpslAttributeType(request.getParameter("primaryInverseAttributeName"));
            rpslFilter.setFilterExpression(request.getParameter("primaryFilterExpressionText"));
            ////Debug.println("OperatorSessionAction: submitPrimaryRpslAdd rpslFilter = " + rpslFilter);
  
            rpslWebImpl.add(rpslFilter);
           
            
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
            
            return (mapping.findForward("operator_session_profile_success")); 
        }
        
        //use operator 0 default rpslFilters to populate the filters for this server for this session profile
        if (submitSecondaryPopulateFilters != null)
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            //pick up default filters
            RpslModel defaultRpslModel = rpslWebImpl.getModel(defaultOperatorId);
        
            RpslFilters defaultRpslFilters = defaultRpslModel.getRpslFilters(); 
        
            Collection defaultRpslFiltersCollection =   defaultRpslFilters.getRpslFilters();
            
            Iterator defaultRpslFiltersCollectionIterator = defaultRpslFiltersCollection.iterator();
            
            while (defaultRpslFiltersCollectionIterator.hasNext()) {
            
                RpslFilter currentDefaultRpslFilter = (RpslFilter)defaultRpslFiltersCollectionIterator.next();
                rpslModel = rpslWebImpl.getModel(operatorSessionForm.getOperatorId());
                rpslFilters = rpslModel.getRpslFilters();
                existingFilters = rpslFilters.getFilterExpressions(operatorSessionForm.getOperatorId(), 
                                    operatorSessionForm.getSessionProfileId(), currentDefaultRpslFilter.getRpslObjectType(),
                                    currentDefaultRpslFilter.getRpslAttributeType());
                
                //if the exisitng list doesn't include this filterExpression then add it to the database
                if (!existingFilters.contains(currentDefaultRpslFilter.getFilterExpression())) {
                
                    if (currentDefaultRpslFilter.getServerProfileId().equals(operatorSessionForm.getPrimaryServerProfileId())) {

                    rpslFilter = new RpslFilter();
                    rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
                    rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
                    rpslFilter.setServerProfileId(operatorSessionForm.getSecondaryServerProfileId());
                    rpslFilter.setRpslObjectType(currentDefaultRpslFilter.getRpslObjectType());
                    rpslFilter.setRpslAttributeType(currentDefaultRpslFilter.getRpslAttributeType());
                    rpslFilter.setFilterExpression(currentDefaultRpslFilter.getFilterExpression());
                    ////Debug.println("OperatorSessionAction: submitPrimaryPopulateFilters rpslFilter = " + rpslFilter);


                    rpslWebImpl.add(rpslFilter);
                    }
                }
            }
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
        return (mapping.findForward("operator_session_profile_success")); 
        }
        
        if (submitSecondaryRpslDelete != null)
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            rpslFilter = new RpslFilter();
            Object rpslFilterId = null;
            
            // set the mockup to null
            rpslFilter.setRpslFilterId(rpslFilterId);
            
            // fill in the values for the mockup
            rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
            rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
            rpslFilter.setServerProfileId(operatorSessionForm.getSecondaryServerProfileId());
            rpslFilter.setRpslObjectType(request.getParameter("secondaryClassName"));
            rpslFilter.setRpslAttributeType(request.getParameter("secondaryInverseAttributeName"));
            rpslFilter.setFilterExpression(request.getParameter("secondaryFilterExpression"));
            
            //get the id of the mockup
            rpslFilterId = rpslFilters.getRpslFilterId(rpslFilter);
            //delete the id from the dao - db
            if (!rpslFilterId.equals(null)) rpslWebImpl.delete(rpslFilterId);
            //set the model to null to refresh the jsp
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
            
            return (mapping.findForward("operator_session_profile_success")); 
        }
        
        if (submitSecondaryRpslAdd != null) 
        {
            //get ref to bean
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            rpslFilter = new RpslFilter();
            rpslFilter.setOperatorId(operatorSessionForm.getOperatorId());
            rpslFilter.setSessionProfileId(operatorSessionForm.getSessionProfileId());
            rpslFilter.setServerProfileId(operatorSessionForm.getSecondaryServerProfileId());
            rpslFilter.setRpslObjectType(request.getParameter("secondaryClassName"));
            rpslFilter.setRpslAttributeType(request.getParameter("secondaryInverseAttributeName"));
            rpslFilter.setFilterExpression(request.getParameter("secondaryFilterExpressionText"));
            rpslWebImpl.add(rpslFilter);
            rpslWebImpl = new RpslWebImpl();
            session.setAttribute("rpslWebImpl",rpslWebImpl);
            return (mapping.findForward("operator_session_profile_success")); 
        }
        
        //--------submitProfile-------- 
        
        if (sessionProfileName != null)
        {
            //change session profile
            
            ////Debug.println("OperatorSessionAction: submitProfile: sessionProfileName = " + request.getParameter("sessionProfileName") + "selectedOperatorSession = " + selectedOperatorSession);
            session.setAttribute(Constants.SELECTED_OPERATOR_SESSION_KEY, selectedOperatorSession.getSessionProfileId());
            //session.putValue("selectedOperatorSession", selectedOperatorSession);
            return (mapping.findForward("operator_session_profile_success")); 
        } 
        
        //--------submitPrimaryIrr-------- 
        if (primaryServerProfileName != null)
        {
            
            //change primary irr for this session
            Object primaryServerProfileId = servers.getServerByName(request.getParameter("primaryServerProfileName")).getServerProfileId();
                        
            selectedOperatorSession.setPrimaryServerProfileId(primaryServerProfileId);
            
            operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
            
            operatorSessionForm.setPrimaryServerProfileId(primaryServerProfileId);
            
            return (mapping.findForward("operator_session_profile_success")); 
        } 
        //--------submitPrimaryRpsl-------- 
       
        //if (submitPrimaryRpslClass != null)
        if (primaryClassName != null)
        {
        ////Debug.println("OperatorSessionAction: submitPrimary == refreshAttributes: primaryClassName = " + request.getParameter("primaryClassName"));
        //this is a reference to the bean in the session
        operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
        operatorSessionForm.setPrimaryClassName(request.getParameter("primaryClassName"));
        operatorSessionForm.setPrimaryInverseAttributeName(request.getParameter("primaryInverseAttributeName"));
        return (mapping.findForward("operator_session_profile_success")); 
        }
        //--------submitSecondaryIrr-------- 
        if (secondaryServerProfileName != null)
        {
            //change secondary irr for this session 

            Object secondaryServerProfileId = servers.getServerByName(request.getParameter("secondaryServerProfileName")).getServerProfileId();
            
            selectedOperatorSession.setSecondaryServerProfileId(secondaryServerProfileId);            
            
            return (mapping.findForward("operator_session_profile_success")); 
        } 
        //--------submitSecondaryRpsl-------- 
        
        
        if (secondaryClassName != null)
        {
        ////Debug.println("OperatorSessionAction: submitSecondary == refreshAttributes: secondaryClassName = " + request.getParameter("secondaryClassName"));
        //this is a reference to the bean in the session
        operatorSessionForm = (OperatorSessionForm) session.getAttribute("operatorSessionForm");
        operatorSessionForm.setSecondaryClassName(request.getParameter("secondaryClassName"));
        operatorSessionForm.setSecondaryInverseAttributeName(request.getParameter("secondaryInverseAttributeName"));
        return (mapping.findForward("operator_session_profile_success")); 
        }
        
     

      //------------------------------------  
        if (servlet.getDebug() >= 1)
        {
            servlet.log("OperatorSesionAction: Operator '" + operatorLoginName +
            "' in session " + session.getId());
        }
        

        return (mapping.findForward("operator_session_profile_success"));
        
        
        
        // Forward control to the success URI specified in struts-config.xml
        //        return (mapping.findForward("report_success"));
        //        return (mapping.findForward("template.jsp"));
        //        mapping.setPath(pageSelect);
        //        return (mapping.findforward(pageSelect));
    }
    //autopopulate the filters from the maintainer objects - not finished - Bill R
   public void populateFilters(OperatorSession operatorSession) {

        String maintainerObjects = executeCommandLine(Constants.WHOIS + serverModel.getServerIpv4() 
        + " -p " + serverModel.getQueryPort() + " -i mnt-by " + operatorSession.getMaintainerCode());
        //Debug.println("OperatorSessionAction: populateFilters: maintainerObjects = " + maintainerObjects);
        
        
    }
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("OperatorSessionAction:copyObjectProperties ", t);
            throw new ServletException("OperatorSessionAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("OperatorSessionAction:copyObjectProperties ", t);
            throw new ServletException("OperatorSessionAction:copyObjectProperties ", t);
        }
    }
    //modified to allow for CRLF on first line of reader- Bill R Jul 27 2001
    public String executeCommandLine(String cmdLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");
        
        try
        {
            
            Process process = Runtime.getRuntime().exec(cmdLine);
            
            
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("OperatorSessionAction: Command Line Exec Error = " + e.getMessage());
        }
        //return("diag cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }

}