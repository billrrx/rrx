package ca.rrx.nw.rr.struts.admin;


import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;


public final class AdminMaintForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables
    
    protected String operatorFullName;
    protected String role;
    
    protected String maintainerCode;
    protected String maintainerCodeText;
    
    protected String operatorLoginName;
    protected Object operatorId;
    protected String maintainerCodes;
    protected String nicHandle;
    protected String streetName1;
    protected String streetName2;
    //protected String streetName3;
    protected String city;
    protected String stateProvince;
    protected String postalCode;
    protected String country;
    protected String telephone;
    protected String email;
    
    
    // ----------------------------------------------------------- Properties
    
    
    public String getOperatorFullName(){
        return operatorFullName;
    }
    
    public void setOperatorFullName(String operatorFullName){
        this.operatorFullName = operatorFullName;
    }    
    
    public String getRole(){
        return role;
    }
    
    public void setRole(String role){
        this.role = role;
    }    
    
    public String getMaintainerCode(){
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode){
        this.maintainerCode = maintainerCode;
    }
    
    public String getMaintainerCodeText(){
        return maintainerCodeText;
    }
    
    public void setMaintainerCodeText(String maintainerCodeText){
        this.maintainerCodeText = maintainerCodeText;
    }
    
    public String getOperatorLoginName() {
        return operatorLoginName;
    }
    
    public void setOperatorLoginName(String operatorLoginName) {
        this.operatorLoginName = operatorLoginName;
    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
    
    public String getMaintainerCodes() {
        return maintainerCodes;
    }
    
    public void setMaintainerCodes(String maintainerCodes) {
        this.maintainerCodes = maintainerCodes;
    }
    
    public String getNicHandle(){
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle){
        this.nicHandle = nicHandle;
    }
    
  
    public String getStreetName1() {
        return streetName1;
    }
    
    public void setStreetName1(String streetName1){
        this.streetName1 = streetName1;
    }
    
    public String getStreetName2() {
        return streetName2;
    }
    
    public void setStreetName2(String streetName2){
        this.streetName2 = streetName2;
    }
/*
    public String getStreetName3() {
        return streetName3;
    }
 
    public void setStreetName3(String streetName3){
        this.streetName3 = streetName3;
    }
 */
    public String getCity() {
        return city;
    }
    
    public void setCity(String city){
        this.city = city;
    }
    
    public String getStateProvince() {
        return stateProvince;
    }
    
    public void setStateProvince(String stateProvince){
        this.stateProvince = stateProvince;
    }
    
    public String getPostalCode() {
        return postalCode;
    }
    
    public void setPostalCode(String postalCode){
        this.postalCode = postalCode;
    }
    
    public String getCountry(){
        return country;
    }
    
    public void setCountry(String country){
        this.country = country;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public String getTelephone(){
        return telephone;
    }
    
    public void setTelephone(String telephone){
        this.telephone = telephone;
    }
    
    
    
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
                
        this.operatorFullName 	= null;
        this.role 	        = null;
        this.maintainerCode 	= null;
        this.maintainerCodeText = null;
        this.nicHandle 		= null;
        this.operatorLoginName
	= null;
        this.streetName1 	= null;
        this.streetName2 	= null;
        //  this.streetName3 	= null;
        this.city 		= null;
        this.stateProvince 	= null;
        this.postalCode 	= null;
        this.country 		= null;
        this.telephone 		= null;
        this.email 		= null;
    }
    
    public ActionErrors validate(ActionMapping mapping,
    HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());
            
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("OperatorForm ** Parsing error" + ", line " +
            //err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("OperatorForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("OperatorForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("OperatorForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("OperatorForm error: " + pce);
        }
        return null;
    }
}