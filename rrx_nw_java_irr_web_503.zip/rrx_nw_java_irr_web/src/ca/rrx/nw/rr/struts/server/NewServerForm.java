package ca.rrx.nw.rr.struts.server;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;
import ca.rrx.nw.rr.control.web.ServerWebImpl;

import java.util.Locale;
import java.util.*;

public final class NewServerForm extends ActionForm
{

    // --------------------------------------------------- Instance Variables
    
    protected List serverProfileNames;
    
    protected Object serverProfileId;
    protected String serverProfileName;
    protected String serverDnsName;
    protected String serverIpv4;
    protected String serverIpv6;
    protected String serverType;
    protected String queryPort;
    protected String updatePort;
    protected String floodPort;
    protected String mirrorPort;
    protected String authoritativeSourceCodes;
    protected String mirroredSourceCodes;
    protected String ftpParameters;
    protected String rpslCode;
    protected String remarks;
    
    
    // ----------------------------------------------------------- Properties
    
    public List getServerProfileNames(){
        return serverProfileNames;
    }
    
    public void setServerProfileNames(List serverProfileNames) {
        this. serverProfileNames = serverProfileNames;
    }
    
    public Object getServerProfileId() {
        return serverProfileId;
    }
    
    public void setServerProfileId(Object serverProfileId) {
        this. serverProfileId = serverProfileId;
    }
    
    public String getServerProfileName() {
        return serverProfileName;
    }
    
    public void setServerProfileName(String serverProfileName) {
        this. serverProfileName = serverProfileName;
    }
    
    public String getServerDnsName() {
        return serverDnsName;
    }
    
    public void setServerDnsName(String serverDnsName) {
        this. serverDnsName = serverDnsName;
    }
    
    public String getServerIpv4() {
        return serverIpv4;
    }
    
    public void setServerIpv4(String serverIpv4) {
        this. serverIpv4 = serverIpv4;
    }
    
    public String getServerIpv6() {
        return serverIpv6;
    }
    
    public void setServerIpv6(String serverIpv6) {
        this. serverIpv6 = serverIpv6;
    }
    
    public String getServerType() {
        return serverType;
    }
    
    public void setServerType(String serverType) {
        this. serverType = serverType;
    }
    
    public String getQueryPort() {
        return queryPort;
    }
    
    public void setQueryPort(String queryPort) {
        this. queryPort = queryPort;
    }
    
    public String getUpdatePort() {
        return updatePort;
    }
    
    public void setUpdatePort(String updatePort) {
        this. updatePort = updatePort;
    }
    
    public String getFloodPort() {
        return floodPort;
    }
    
    public void setFloodPort(String floodPort) {
        this. floodPort = floodPort;
    }
    
    public String getMirrorPort() {
        return mirrorPort;
    }
    
    public void setMirrorPort(String mirrorPort) {
        this. mirrorPort = mirrorPort;
    }
    
    public String getAuthoritativeSourceCodes() {
        return authoritativeSourceCodes;
    }
    
    public void setAuthoritativeSourceCodes(String authoritativeSourceCodes) {
        this. authoritativeSourceCodes = authoritativeSourceCodes;
    }
    
    public String getMirroredSourceCodes() {
        return mirroredSourceCodes;
    }
    
    public void setMirroredSourceCodes(String mirroredSourceCodes) {
        this. mirroredSourceCodes = mirroredSourceCodes;
    }
    
    public String getFtpParameters() {
        return ftpParameters;
    }
    
    public void setFtpParameters(String ftpParameters) {
        this. ftpParameters = ftpParameters;
    }
    
    public String getRpslCode() {
        return rpslCode;
    }
    
    public void setRpslCode(String rpslCode) {
        this. rpslCode = rpslCode;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    // --------------------------------------------------------- Public Methods
    
    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        
        this.serverProfileId = null;
        this.serverProfileName = null;
        this.serverDnsName = null;
        this.serverIpv4 = null;
        this.serverIpv6 = null;
        this.serverType = null;
        this.queryPort = null;
        this.updatePort = null;
        this.floodPort = null;
        this.mirrorPort = null;
        this.authoritativeSourceCodes = null;
        this.mirroredSourceCodes = null;
        this.ftpParameters = null;
        this.rpslCode = null;
        this.remarks = null;
       
    }
    
    
    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
    HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
      /*  
        if ((serverDnsName == null) || (serverDnsName.length() < 1))
        {
            errors.add("serverDnsName", new ActionError("error.serverDnsName.required"));
        }
        
        if ((serverIpv4 == null) || (serverIpv4.length() < 1))
        {
            errors.add("serverIpv4", new ActionError("error.serverIpv4.required"));
        }
        
        
        if ((serverType == null) || (serverType.length() < 1))
        {
            errors.add("serverType", new ActionError("error.serverType.required"));
        }
        
        if ((queryPort == null) || (queryPort.length() < 1))
        {
            errors.add("queryPort", new ActionError("error.queryPort.required"));
        }
        
        
        if ((updatePort == null) || (updatePort.length() < 1))
        {
            errors.add("updatePort", new ActionError("error.updatePort.required"));
        }
        */
        return errors; 
    } 
}