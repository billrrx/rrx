package ca.rrx.nw.rr.struts.sign;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.struts.operator.OperatorForm;

import java.io.IOException;

import java.util.Hashtable;
import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.control.exceptions.GeneralFailureException;

import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorEvent;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.Operators;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

import ca.rrx.nw.rr.util.*;


public final class SignInAction extends Action
{

     
    public ActionForward perform(ActionMapping mapping,
         ActionForm form,
         HttpServletRequest request,
         HttpServletResponse response)
            throws IOException, ServletException
    {
        

       // Switch for Debug Mode (true/false)
        
        boolean debugMode = false; 
         

       // Variable Declaration

       
           
              
        String	submitLogin        	= request.getParameter("submitLogin");
        String	submitNewRegistrant	= request.getParameter("submitNewRegistrant");
        String	submitProgramUtilities  = request.getParameter("submitProgramUtilities");
 
        
        OperatorWebImpl 	operatorWebImpl;
        ServerWebImpl		serverWebImpl;
            
        //get the session
        HttpSession		session  = request.getSession();
        
        /*if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }*/

        //get the session beans from the session
        

/*
        if (session.getAttribute("operatorWebImpl") != null) {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        } else {  //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
*/
            
            operatorWebImpl = new OperatorWebImpl();
            serverWebImpl = new ServerWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            session.setAttribute("serverWebImpl", serverWebImpl);
        
            // Request Paramaters 
        
    
        SignInForm      signInForm       = (SignInForm) form;
 
        String 		username;
        String 		password;
        String 		maintainer;

        username = ((SignInForm) form).getUsername();
        password = ((SignInForm) form).getPassword();
        maintainer = ((SignInForm) form).getMaintainer();

        // Save our logged-in user in the session,
        // because we use it again later.

        session = request.getSession();

        session.setAttribute(Constants.USER_KEY, form);
   
             
       /*---------------------------------------------------
        *   Action Processiong  -  Login Procedure   
        *---------------------------------------------------*/
       
        if  (submitLogin != null)
        {
   
     
           if (username != null && !(username.equals("")))
           {
               // this line causes a crash
              OperatorModel operatorModel;
              OperatorInformation operatorInformation;
              Operators newOperators;
              String maintainerCodes;
              
                try
               {
              operatorModel = operatorWebImpl.getModel(username);
               }
               catch(GeneralFailureException e)
               {
                 return (mapping.findForward("signin_error"));
               }
              
              if (operatorModel !=null)
              {
                operatorInformation = operatorModel.getOperatorInformation();
                newOperators        = operatorModel.getNewOperators();
                maintainerCodes     = operatorInformation.getMaintainerCodes();
                //fix for multiple maintainer codes - RRX NW
                
                if (password !=null &&  password.equals(operatorInformation.getPassword()) &&  maintainer.equals(maintainerCodes))
                {

                    Locale locale;

                    String lang = operatorInformation.getLang();
                    String role = operatorInformation.getRole();
                    
                    

                    locale = null;

                                     
                    OperatorSessions operatorSessions = operatorModel.getOperatorSessions();
                    Object operatorId = operatorSessions.getOperatorId();
                    Object operatorSessionId = operatorInformation.getDefaultSessionId();
                    OperatorSession currentOperatorSession = operatorSessions.getOperatorSessionById(operatorSessionId);
                    String currentOperatorSessionName = currentOperatorSession.getSessionProfileName();
                    
                    ServerModel serverModel = serverWebImpl.getModel(currentOperatorSession.getPrimaryServerProfileId());
                    Servers servers = serverModel.getServers();
                    Server primaryServer = servers.getServerById(currentOperatorSession.getPrimaryServerProfileId());
                    Server secondaryServer = servers.getServerById(currentOperatorSession.getSecondaryServerProfileId());
                    
                    
                    OperatorEvent operatorEvent = new OperatorEvent();
                    
                    operatorEvent.setOperatorId(operatorInformation.getOperatorId());
                    operatorEvent.setSessionProfileId(currentOperatorSession.getSessionProfileId());
                    operatorEvent.setHttpSessionCode(session.getId());
                    operatorEvent.setMaintainerCode(currentOperatorSession.getMaintainerCode());
                    operatorEvent.setFullName(operatorInformation.getFirstName() + " " + operatorInformation.getLastName());
                    operatorEvent.setTelephone(operatorInformation.getTelephone());
                    operatorEvent.setEmail(operatorInformation.getEmail());
                    operatorEvent.setEventCode(Constants.LOGIN_EVENT_CODE);
                    //note this should be converted to another comprehensible date time format
                    Long timeSessionLastAccessed = new Long(session.getLastAccessedTime());
                    
                    operatorEvent.setTimeStored(timeSessionLastAccessed.toString());
                    operatorEvent.setExtendedInformation("Source Ipv4 = " + request.getRemoteAddr());
                    //note need to do this for timeout and logout etc
                    operatorWebImpl.add(operatorEvent);
                    
                    session.setAttribute(Constants.USERNAME_KEY, username);
                    session.setAttribute(Constants.LANGUAGE_KEY, lang);
                    session.setAttribute(Constants.USERROLE_KEY, role);
                    
                    if (newOperators != null) 
                    {
                        if (newOperators.getOperatorFullNames().isEmpty()) 
                        {
                            session.setAttribute(Constants.NEW_OPERATOR_KEY, "false");
                        }
                        else
                        {
                            session.setAttribute(Constants.NEW_OPERATOR_KEY, "true");
                        }
                    }
                    else
                    {
                    session.setAttribute(Constants.NEW_OPERATOR_KEY, "false");    
                    }
                    
                    session.setAttribute(Constants.USERMAINT_KEY, currentOperatorSession.getMaintainerCode());
                    session.setAttribute(Constants.USERSESSION_KEY, currentOperatorSessionName);
                    session.setAttribute(Constants.THIS_OPERATOR_SESSION_KEY, operatorSessionId);
                    session.setAttribute(Constants.DEFAULT_OPERATOR_SESSION_KEY, operatorSessionId);
                    session.setAttribute(Constants.PRIMARY_SERVER, primaryServer.getServerProfileName());

                    if(lang.equals("FR"))
                    {
                        locale = new Locale("fr", "CA");
                    }
                    else if(lang.equals("EN"))
                    {
                        locale = new Locale("en", "CA");
                    }

//                    opForm = (OperatorForm)session.getAttribute(Constants.OPERATOR_PROFILE_KEY);
//                    opForm.setLanguageSelected(lang);

                    session.setAttribute("userLocale",locale);

                    return (mapping.findForward("signin_success"));
                }
                else
                {
                   return (mapping.findForward("signin_error"));
                }
              }      
              else
              {
                 return (mapping.findForward("signin_error"));
              }
           }       
           else
           {
                return (mapping.findForward("signin_error"));
           }     
        }
              

      /*---------------------------------------------------
       *   Action Processiong  -  New User Registration   
       *---------------------------------------------------*/
              
       if (submitNewRegistrant != null) 
       {
            //Debug.println("signInAction - New Registrant:signInForm  ="+ submitNewRegistrant);
            return (mapping.findForward("operator_profile_new"));
       }

       if (submitProgramUtilities != null) 
       {
            //Debug.println("signInAction - Program Utilities:signInForm  ="+ submitProgramUtilities);
            return (mapping.findForward("main"));
       }

        
        // Forward control to the success URI specified in struts-config.xml
        return (mapping.findForward("signin_success"));
    }
}
