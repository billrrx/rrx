package ca.rrx.nw.rr.struts.aQuery;

import ca.rrx.nw.rr.Constants;

import java.util.ArrayList;
import java.util.Iterator;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import ca.rrx.nw.rr.control.web.RpslWebImpl;
import ca.rrx.nw.rr.model.rpsl.model.RpslFilters;
import ca.rrx.nw.rr.model.rpsl.model.RpslModel;
import ca.rrx.nw.rr.model.rpsl.model.RpslDefs;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.server.model.Server;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.ServerModel;

import ca.rrx.nw.rr.control.web.ServerWebImpl;

/**
This action implements the controller for the advancedQuery system
- modified by adding serverQueryPort and commandPrefix code -RRX Network
- cleaned up the source code by eliminating unused factors
* March 31 2015
 */
public final class AdvancedQueryAction extends Action
{
   
    RpslWebImpl rpslWebImpl;
    RpslModel rpslModel;
    
    
    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String key;
        String type;
        String inv;
        String template;
        String sourceFlag;
        String[] source;
        String[] sourceVals;
        String[] sourceStringArray;

        String results;             // stores results of executed command
        String commandIndex;        // string indicating which command was executed
        String command;             // stores command to be executed


        OperatorWebImpl operatorWebImpl;
        OperatorModel operatorModel;
        OperatorInformation operatorInformation;
        OperatorSessions operatorSessions;
        OperatorSession currentSession;
        ServerModel serverModel;
        ServerWebImpl serverWebImpl;
        AdvancedQueryForm aqf;

        Iterator it;
        HttpSession session;
        int counter;
        String serverIp;
        String serverQueryPort;
        String commandPrefix; 

        serverIp = "";


        sourceStringArray = null;
        sourceFlag = null;

        // save form to session
        session = request.getSession();

        System.out.println("abctest: " + session.getAttribute(Constants.USERNAME_KEY));

        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }
        else
        {
            if(session.getAttribute(Constants.USERNAME_KEY).equals("public"))
            {
                serverWebImpl       = new ServerWebImpl();
                session.setAttribute("serverWebImpl", serverWebImpl);
            }
            else
            {
                serverWebImpl       = (ServerWebImpl)session.getAttribute("serverWebImpl");
            }
        }

        key             = ((AdvancedQueryForm) form).getKey();
        type            = ((AdvancedQueryForm) form).getType();
        inv             = ((AdvancedQueryForm) form).getInv();
        source          = ((AdvancedQueryForm) form).getSource();
        template        = ((AdvancedQueryForm) form).getTemplate();
        command         = ((AdvancedQueryForm) form).getCommand();
        commandIndex    = ((AdvancedQueryForm) form).getCommandIndex();
        results         = ((AdvancedQueryForm) form).getResults();


        session.setAttribute(Constants.AQUERY_KEY, form);
        session.setAttribute("advancedQueryForm", form);
//        serverWebImpl       = (ServerWebImpl)session.getAttribute("serverWebImpl");

//      aqf = (AdvancedQueryForm)session.getAttribute("advancedQueryForm");

        //start
        operatorWebImpl     = (OperatorWebImpl)session.getAttribute("operatorWebImpl");
        operatorModel       = operatorWebImpl.getModel((String)session.getValue("MM_Username"));
        operatorInformation = operatorModel.getOperatorInformation();
        operatorSessions    = operatorModel.getOperatorSessions();

        currentSession      = operatorSessions.getOperatorSessionById((Object)session.getValue(Constants.THIS_OPERATOR_SESSION_KEY));

        if(currentSession == null)
        {
            currentSession      = operatorSessions.getOperatorSessionById((Object)operatorInformation.getDefaultSessionId());
        }

        System.out.println("abctest serverWebImpl: " + serverWebImpl);
        System.out.println("abctest currentSession: " + currentSession);

        
        Servers servers;
        Server server;
        String serverProfileName;

        serverProfileName           = ((AdvancedQueryForm) form).getServerProfileName();

        serverModel         = serverWebImpl.getModel(currentSession.getPrimaryServerProfileId());
        servers             = serverModel.getServers();
        server              = servers.getServerByName(serverProfileName);

        serverIp            = server.getServerIpv4();
        serverQueryPort     = server.getQueryPort();
        
        //end



        if (session.getAttribute("rpslWebImpl") != null)
        {
            rpslWebImpl = (RpslWebImpl) session.getAttribute("rpslWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            rpslWebImpl = new RpslWebImpl();
        }

        //this is akluge for now ... need a default id for public user
        Object operatorId = new Integer(1);
        
        rpslModel = rpslWebImpl.getModel(operatorId);
        RpslFilters rpslFilters = rpslModel.getRpslFilters();
        RpslDefs rpslDefs = rpslModel.getRpslDefs();
        
        if(request.getParameter("submit1") != null)
        {
            commandIndex    = "whoisQuery";

            sourceFlag = "";

            // if inverse flag and type are not null
            if((inv != null) && (type != null))
            {
                if((source != null) && (source.length > 0) && (!source[0].equals("all")))
                {
                    sourceFlag = " -s ";

                    for(int i = 0 ; i < source.length ; i++)
                    {
                        sourceFlag = sourceFlag + source[i];

                        if(i != (source.length - 1))
                        {
                            sourceFlag = sourceFlag + ", ";
                        }
                    }
                }

                commandPrefix       =  Constants.WHOIS + serverIp + " -p " + serverQueryPort + sourceFlag;
                
                if(!inv.equals("none"))
                {
                    if(type.equals("all"))
                    {
                        command = commandPrefix + " -i " + inv + " " + key;
                    }
                    else
                    {
                        command = commandPrefix + " -T " + type + " -i " + inv + " " + key;
                    }
                }
                else
                {
                    if(type.equals("all"))
                    {
                        command = commandPrefix + " " + key;
                    }
                    else
                    {
                        command = commandPrefix + " -T " + type + " " + key;
                    }
                }
            }
        }
        else if(request.getParameter("submitEdit") != null)
        {
            commandIndex = "submitEdit";
        }
        else if(request.getParameter("submitSaveToFile") != null)
        {
            commandIndex = "submitSaveToFile";
        }
        else
        {
            commandIndex    = "getTemplate";
        }

        if(commandIndex != null)
        {
            if(commandIndex.equals("getTemplate"))
            {
                results = rpslDefs.getClassTemplate(template);
                sourceStringArray = split(results);
            }
            else if(commandIndex.equals("submitSaveToFile"))
            {
//                aqf.setResults("test");
//                results = "test-results" + " \n\r cool \n\r new\n\r stuff\n\r";
//                command = "test-command";

//                ((AdvancedQueryForm)form).setCommand(command);
//                ((AdvancedQueryForm)form).setCommandIndex(commandIndex);
//                ((AdvancedQueryForm)form).setResults(results);
//                session.setAttribute(Constants.AQUERY_KEY, form);
//                return (mapping.findForward("aquery_success"));
            }
            else if(commandIndex.equals("submitEdit"))
            {
//                results = exec(command);
                return (mapping.findForward("aquery_edit"));
            }
            else if(commandIndex.equals("whoisQuery"))
            {
                results = exec(command);
            }
        }

        ((AdvancedQueryForm)form).setCommand(command);
        ((AdvancedQueryForm)form).setCommandIndex(commandIndex);
        ((AdvancedQueryForm)form).setResults(results);

        // save form to session
        session.setAttribute(Constants.AQUERY_KEY, form);

        // Forward control to the success URI specified in struts-config.xml
        return (mapping.findForward("aquery_success"));
    }

    /**
     * Accepts a string that is executed as an external command.
     *
     */
    public String exec(String cmd)
    {
        StringBuffer stringBuffer;
        String newline;

        stringBuffer    = new StringBuffer();
        newline         = System.getProperty("line.separator");

        try
        {
            Process process;
            InputStream in;
            BufferedReader reader;
            String line;
            int c;

            process = Runtime.getRuntime().exec(cmd);
            in      = process.getInputStream();
            reader  = new BufferedReader(new InputStreamReader(in));
            c       = 0;

            do
            {
                line = reader.readLine();

                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }

                c++;
            }
            while(line != null);

            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Error in ReportAction.java");
        }

        return(new String(stringBuffer));
    }


    /**
     * Accepts a string with lines separated by '\n' and places each
     * line into a separate element of a string array.
     *
     *
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        trimArray(temp);

        return((String[])temp.toArray(new String[]{}));
    }


    /**
     * Accepts an ArrayList of strings and removes empty lines
     * from the start and end of the List.
     *
     */
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;

        idxRemove = new int[100];
        count = 0;

        if(!t.isEmpty())
        {
            for(int i = 0 ; i < t.size() ; i++)
            {
               String s;

               s = t.get(i).toString().trim();

               if(s.length() == 0)
               {  
                   idxRemove[count] = i;
                   count++;
               }
               else
               {
                   break;
               }
            }

            for(int i = count ; i > 0 ; i--)
            {
                  t.remove(0);
            }
        }
    }
}