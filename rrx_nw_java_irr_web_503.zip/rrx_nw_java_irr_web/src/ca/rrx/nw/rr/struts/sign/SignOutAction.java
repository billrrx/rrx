package ca.rrx.nw.rr.struts.sign;

import ca.rrx.nw.rr.Constants;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorEvent;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;


public final class SignOutAction extends Action {


    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
        throws IOException, ServletException
    {
        // Extract attributes we will need
        HttpSession session;
        SignInForm user;


        session = request.getSession();

        try
        {
            user = (SignInForm) session.getAttribute(Constants.USER_KEY);


            // Process this user logoff
            if (user != null)
            {
                if (servlet.getDebug() >= 1)
                {
                    servlet.log("LogoffAction: User '" + user.getUsername() +
                    "' logged off in session " + session.getId());
                }
            }
            else
            {
                if (servlet.getDebug() >= 1)
                {
                    servlet.log("LogoffActon: User logged off in session " +
                    session.getId());
                }
            }
            OperatorWebImpl operatorWebImpl;

            
            if (session.getAttribute("operatorWebImpl") != null) {
                operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
            } else {  //diag only - should error out here if there is no bean in the session
                operatorWebImpl = new OperatorWebImpl();
            }
                  OperatorModel operatorModel = operatorWebImpl.getModel((String)session.getAttribute(Constants.USERNAME_KEY));
                  OperatorInformation operatorInformation = operatorModel.getOperatorInformation();
                  OperatorSessions operatorSessions = operatorModel.getOperatorSessions();
                  Object operatorId = operatorSessions.getOperatorId();
                  Object operatorSessionId = operatorInformation.getDefaultSessionId();
                  OperatorSession currentOperatorSession = operatorSessions.getOperatorSessionById(operatorSessionId);
                  String currentOperatorSessionName = currentOperatorSession.getSessionProfileName();
                  
                        OperatorEvent operatorEvent = new OperatorEvent();
                        
                        operatorEvent.setOperatorId(operatorInformation.getOperatorId());
                        operatorEvent.setSessionProfileId(currentOperatorSession.getSessionProfileId());
                        operatorEvent.setHttpSessionCode(session.getId());
                        operatorEvent.setMaintainerCode(currentOperatorSession.getMaintainerCode());
                        operatorEvent.setFullName(operatorInformation.getFirstName() + " " + operatorInformation.getLastName());
                        operatorEvent.setTelephone(operatorInformation.getTelephone());
                        operatorEvent.setEmail(operatorInformation.getEmail());
                        operatorEvent.setEventCode(Constants.LOGOUT_EVENT_CODE);
                        //note this should be converted to another comprehensible date time format
                        Long timeSessionLastAccessed = new Long(session.getLastAccessedTime());
                        
                        operatorEvent.setTimeStored(timeSessionLastAccessed.toString());
                        operatorEvent.setExtendedInformation("Source Ipv4 = " + request.getRemoteAddr());
                        //note need to do this for timeout and logout etc
                        operatorWebImpl.add(operatorEvent);

    //        session.removeAttribute(Constants.USER_KEY);
                session.removeAttribute(Constants.USERNAME_KEY);
                session.removeAttribute(Constants.USERROLE_KEY);
                session.removeAttribute(Constants.USERSESSION_KEY);

             //session.invalidate();  //Will break JSP that try to check session to see if logged in.

        }
/*
                }
        catch(NullPointerException e)
        {
            return (mapping.findForward("signout_success"));
        }*/
        catch(NullPointerException e)
        {
            return (mapping.findForward("signout_success"));
        }

        // Forward control to the specified success URI
        return (mapping.findForward("signout_success"));
        //return (mapping.findForward("success"));
        //        return (mapping.findForward("logon"));
    }
}
