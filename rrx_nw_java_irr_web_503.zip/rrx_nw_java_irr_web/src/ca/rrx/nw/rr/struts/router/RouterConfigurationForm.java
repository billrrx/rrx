
package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.List;
import java.util.ArrayList;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class RouterConfigurationForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List routerProfileNames;
    
    protected List controlPortNames;
    
    protected List controlConnectionNames;
    
    protected List configurationTimeStamps;
    protected List templateTimeStamps;


    //----
    
    protected String routerProfileName;
    
    private String controlPortName;

    private String controlConnectionName;
    
    protected String configurationTimeStamp;
    protected String configurationTimeStamp2;
    
    protected String currentConfig;
    protected String currentTemplate;
    protected String currentConfigRebuild;

    protected String configTextArea;
    protected String templateTextArea;

    protected String templateTimeStamp;
    protected String commandLine;
    
    protected String remarks;
    protected String message;
    protected String configurationTemplate;
    protected String configurationResult;
    protected String configurationRpslSnap;    

    protected String command;
    protected String commandIndex;
    protected String results;

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getControlPortNames(){
        return controlPortNames;
    }
    
    public void setControlPortNames(List controlPortNames) {
        this. controlPortNames = controlPortNames;
    }
    
    public List getControlConnectionNames(){
        return controlConnectionNames;
    }
    
    public void setControlConnectionNames(List controlConnectionNames) {
        this. controlConnectionNames = controlConnectionNames;
    }    
    
    public List getConfigurationTimeStamps(){
        return configurationTimeStamps;
    }
    
    public void setConfigurationTimeStamps(List configurationTimeStamps) {
        this. configurationTimeStamps = configurationTimeStamps;
    }

    public List getTemplateTimeStamps(){
        return templateTimeStamps;
    }

    public void setTemplateTimeStamps(List templateTimeStamps) {
        this.templateTimeStamps = templateTimeStamps;
    }

    //---------
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public String getControlPortName() {
        return controlPortName;
    }
    
    public void setControlPortName(String controlPortName) {
        this. controlPortName = controlPortName;
    }
    
    public String getControlConnectionName() {
        return controlConnectionName;
    }
    
    public void setControlConnectionName(String controlConnectionName) {
        this. controlConnectionName = controlConnectionName;
    }

    public String getConfigurationTimeStamp() {
        return configurationTimeStamp;
    }
    
    public void setConfigurationTimeStamp(String configurationTimeStamp) {
        this. configurationTimeStamp = configurationTimeStamp;
    }
    
    public String getCommandLine() {
        return commandLine;
    }

    public void setCommandLine(String commandLine) {
        this.commandLine = commandLine;
    }

    public String getConfigurationTimeStamp2() {
        return configurationTimeStamp2;
    }
    
    public void setConfigurationTimeStamp2(String configurationTimeStamp2) {
        this. configurationTimeStamp2 = configurationTimeStamp2;
    }

    public String getConfigTextArea() {
        return configTextArea;
    }
    
    public void setConfigTextArea(String configTextArea) {
        this.configTextArea = configTextArea;
    }

    public String getTemplateTextArea() {
        return templateTextArea;
    }
    
    public void setTemplateTextArea(String templateTextArea) {
        this.templateTextArea = templateTextArea;
    }


    //----------
    
    public String getCurrentConfig(){
        return currentConfig;
    }
            
    public void setCurrentConfig(String currentConfig){
        this.currentConfig = currentConfig;
    }   

    public String getCurrentTemplate(){
        return currentTemplate;
    }
            
    public void setCurrentTemplate(String currentTemplate){
        this.currentTemplate = currentTemplate;
    }   


    public String getTemplateTimeStamp() {
        return templateTimeStamp;
    }
    
    public void setTemplateTimeStamp(String templateTimeStamp) {
        this.templateTimeStamp = templateTimeStamp;
    }

    public String getCurrentConfigRebuild(){
        return currentConfigRebuild;
    }
            
    public void setCurrentConfigRebuild(String currentConfigRebuild){
        this.currentConfigRebuild = currentConfigRebuild;
    }   
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this. remarks = remarks;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }

    public String getConfigurationTemplate() {
        return configurationTemplate;
    }
    
    public void setConfigurationTemplate(String configurationTemplate) {
        this.configurationTemplate = configurationTemplate;
    }    
    
    public String getConfigurationResult() {
        return configurationResult;
    }
    
    public void setConfigurationResult(String configurationResult) {
        this.configurationResult = configurationResult;
    }  
    
    public String getConfigurationRpslSnap() {
        return configurationRpslSnap;
    }
    
    public void setConfigurationRpslSnap(String configurationRpslSnap) {
        this.configurationRpslSnap = configurationRpslSnap;
    }     

    public String getCommand() {
        return command;
    }
    
    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommandIndex() {
        return commandIndex;
    }
    
    public void setCommandIndex(String commandIndex) {
        this.commandIndex = commandIndex;
    }

    public String getResults() {
        return results;
    }
    
    public void setResults(String results) {
        this.results = results;
    }


    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }
*/
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterForm error: " + pce);
        }
        return null;
    }
}