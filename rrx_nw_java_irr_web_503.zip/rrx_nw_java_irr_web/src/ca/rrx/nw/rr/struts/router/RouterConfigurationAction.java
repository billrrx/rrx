
package ca.rrx.nw.rr.struts.router;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.lang.InterruptedException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.Iterator;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.model.router.model.RouterModel;
import ca.rrx.nw.rr.model.router.model.Routers;
import ca.rrx.nw.rr.model.router.model.Router;
import ca.rrx.nw.rr.model.router.model.RouterInformation;
import ca.rrx.nw.rr.model.router.model.ControlPorts;
import ca.rrx.nw.rr.model.router.model.ControlPort;
import ca.rrx.nw.rr.model.router.model.ControlConnections;
import ca.rrx.nw.rr.model.router.model.ControlConnection;
import ca.rrx.nw.rr.model.router.model.Configurations;
import ca.rrx.nw.rr.model.router.model.Configuration;
import ca.rrx.nw.rr.model.router.model.Templates;
import ca.rrx.nw.rr.model.router.model.Template;
import ca.rrx.nw.rr.model.router.dao.RouterDAO;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAOSysException;
import ca.rrx.nw.rr.model.router.exceptions.RouterDAODBUpdateException;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.control.web.RouterWebImpl;
import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.struts.router.RouterConfigurationForm;
import ca.rrx.nw.rr.util.DatabaseNames;
import ca.rrx.nw.rr.util.Debug;
import ca.rrx.nw.rr.util.JNDINames;

import java.beans.PropertyDescriptor;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.io.PrintStream;
import java.io.File;

import java.lang.reflect.InvocationTargetException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

/**
 *
 *
 *
 *
 */
public final class RouterConfigurationAction extends Action
{
    private transient Connection dbConnection = null;
    private OperatorWebImpl operatorWebImpl;
    private ServerWebImpl serverWebImpl;
    private RouterWebImpl routerWebImpl;
    private RouterModel routerModel;
    private HttpSession session;


    {
        operatorWebImpl = null;
        serverWebImpl   = null;
        routerWebImpl   = null;
        routerModel     = null;
        session         = null;
    }

    /**

     */
    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        OperatorModel operatorModel;
        OperatorInformation operatorInformation;
        OperatorSessions operatorSessions;
        OperatorSession currentSession;
        ServerModel serverModel;

        String maintainerCode;
        String configFileContents;
        String templateFileContents;
        String rpslSnapFileContents;
        String routerProfileName;
        String routerRemarks;
        String routerManufacturer;
        String routerManufacturerOs;
        String controlPortName;
        String connectionProfileName;
        String results;             // stores results of executed command
        String commandIndex;        // string indicating which command was executed
        String command;             // stores command to be executed


        Routers routers;
        Router router;
        RouterInformation routerInformation;

        //set to copy of bean
        RouterConfigurationForm routerConfigurationForm = ((RouterConfigurationForm) form);
        RouterConfigurationForm routerConfigurationFormBean;

        ControlPorts controlPorts;
        ControlPort controlPort;
        ControlConnections controlConnections;
        ControlConnection controlConnection;
        Configurations configurations;
        Configuration configuration;
        Templates templates;
        Template template;

        boolean refresh;            // false if any other submit button other than 'refresh' is pressed

        List routerNames;
        Integer routerProfileId;
        String timeStamp;
        String revision;
        String configFilename;
        String relativeConfigPath;
        String templateFilename;
        String rpslSnapFilename;

        String tmpMsg;
        String username;

        relativeConfigPath      = "";
        maintainerCode          = "";
        configFileContents      = "";
        templateFileContents    = "";
        rpslSnapFileContents    = "";

        routerProfileName       = "";
        routerRemarks           = "";
        routerManufacturer      = "";
        routerManufacturerOs    = "";
        controlPortName         = "";
        connectionProfileName   = "";
        results                 = "";
        commandIndex            = "";
        command                 = "";

        routerModel             = null;
        routers                 = null;
        router                  = null;
        routerInformation       = null;
        routerProfileName       = null;
        controlPorts            = null;
        session                 = null;
        configurations          = null;
        configuration           = null;
        templates               = null;
        template                = null;
        controlPortName         = null;
        connectionProfileName   = null;
        controlConnection       = null;
        refresh                 = false;
        routerRemarks           = "";
        
        String currentRouterProfileName = null;
        Object currentRouterProfileId;

        session                 = request.getSession(true);
        
        String           submitSaveNew          = request.getParameter("submitSaveNew");
        String           submitDelete           = request.getParameter("submitDelete");
        String           submitSave             = request.getParameter("submitSave");
        String           configurationTimeStamp = request.getParameter("configurationTimeStamp");
        String           templateTimeStamp      = request.getParameter("templateTimeStamp");
        String           remarks                = request.getParameter("remarks");
        String           commandLine            = request.getParameter("commandLine");


        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        username                = (String)session.getValue("MM_Username");

        // get the beans used by the page
        operatorWebImpl         = (OperatorWebImpl)session.getAttribute("operatorWebImpl");
        serverWebImpl           = (ServerWebImpl)session.getAttribute("serverWebImpl");
        routerWebImpl           = (RouterWebImpl)session.getAttribute("routerWebImpl");
        operatorModel           = operatorWebImpl.getModel((String)session.getValue("MM_Username"));

        routerConfigurationFormBean = (RouterConfigurationForm)session.getAttribute("routerConfigurationForm");
        //routerConfigurationForm = (RouterConfigurationForm)session.getAttribute("routerConfigurationForm");

        operatorInformation     = operatorModel.getOperatorInformation();
        operatorSessions        = operatorModel.getOperatorSessions();
        currentSession          = operatorSessions.getOperatorSessionById(operatorInformation.getDefaultSessionId());
//        serverModel             = serverWebImpl.getModel(new Integer(currentSession.getPrimaryIrrDns()));
        maintainerCode          = currentSession.getMaintainerCode();

        // get the model
        routerModel             = routerWebImpl.getModel(maintainerCode);
        routers                 = routerModel.getRouters();

        session.setAttribute(Constants.RTR_CONFIG_KEY, form);

        routerNames = routers.getRouterProfileNames();

        // get name of selected router profile
        routerProfileName   = request.getParameter("routerProfileName");

        // retrieve the router
        router              = routers.getRouterByName(routerProfileName);

        routerInformation   = router.getRouterInformation();
        routerRemarks       = routerInformation.getRemarks();
        controlPorts        = router.getControlPorts();
        controlConnections  = router.getControlConnections();
        configurations      = router.getConfigurations();
        templates           = router.getTemplates();
        routerProfileId     = (Integer)router.getRouterProfileId();
        
        //set current vars
        currentRouterProfileId = routerProfileId;
        currentRouterProfileName = routerProfileName;


        timeStamp           = null;

        //if a new router selected, and old timestamp in configuration dropdown does not exist in new one, this
        // will cause configuratino to be null
        configuration       = configurations.getConfigurationByTimeStamp((Object)request.getParameter("configurationTimeStamp"));

        if(routerInformation != null)
        {
            String manufacturer;
            manufacturer = routerInformation.getManufacturer();

            if(manufacturer != null)
            {
                if(manufacturer.equals("Cisco Systems"))
                {
                    routerManufacturerOs = "cisco";
                }
                else if(manufacturer.equals("Nortel"))
                {
                    routerManufacturerOs = "nortel";
                }
                else if(manufacturer.equals("Juniper"))
                {
                    routerManufacturerOs = "junos";
                }
            }
        }

        if(configuration != null)
        {
            timeStamp = configuration.getTimeStored();
        }

        else
        {
            Map configs;
            Map configMap;
            Set keys;
            Iterator it;
            Configuration config;

            configMap   = configurations.getConfigurations();
            keys        = configMap.keySet();

            it = keys.iterator();

            config = null;

            // store the last time stamp
            while(it.hasNext())
            {
                config = (Configuration)configMap.get(it.next());
                timeStamp = config.getTimeStored();
            }

            configuration = config;
        }

        template            = templates.getTemplateByTimeStamp((Object)request.getParameter("templateTimeStamp"));

        String tempTest;

        tempTest = "origValue";


        if(currentSession != null)
        {
            relativeConfigPath = currentSession.getRelativeConfigPath();
        }


        /*
         * handle changes in buttons
         */
        // check buttons before drop-downs (order of checking is important)
        
        
        // --------------------------------------------------
        // Action Processiong  -  RRX NW
        // --------------------------------------------------
        if (submitSaveNew != null)
        {
            String timeStored = generateTimestamp();
            Configuration newConfiguration;
            newConfiguration = new Configuration();

            newConfiguration.setRouterProfileId(currentRouterProfileId);

            newConfiguration.setTimeStored(timeStored);
            newConfiguration.setPointerType("config");
            newConfiguration.setRemarks(request.getParameter("remarks"));
            newConfiguration.setCommandLine(request.getParameter("commandLine"));
            newConfiguration.setRevision("1");
            newConfiguration.setConfigurationTemplate(request.getParameter("templateTextArea"));
            newConfiguration.setConfigurationResult(request.getParameter("configTextArea"));

            routerWebImpl.add(newConfiguration);
            routerWebImpl = new RouterWebImpl();
            session.setAttribute("routerWebImpl", routerWebImpl);
        }

        if(submitSave != null)
        {

            configuration.setRouterProfileId(currentRouterProfileId);
            configuration.setTimeStored(configurationTimeStamp);
            configuration.setPointerType("config");
            configuration.setRemarks(request.getParameter("remarks"));
            configuration.setCommandLine(request.getParameter("commandLine"));
            configuration.setRevision("1");
            configuration.setConfigurationTemplate(request.getParameter("templateTextArea"));    
            configuration.setConfigurationResult(request.getParameter("configTextArea"));
            
            routerWebImpl.update(configuration);
            routerWebImpl = new RouterWebImpl();
            session.setAttribute("routerWebImpl", routerWebImpl);

            return (mapping.findForward("router_configuration_success"));
        }

        if(submitDelete != null)
        {

            Configuration tmpConfig =     configurations.getConfigurationByTimeStamp(configurationTimeStamp);

            //Debug.println("RouterConfigurationAction: " + tmp + "||" + tmp.getRouterConfigurationId());
            if (!tmpConfig.equals(null))
            {
             routerWebImpl.delete(tmpConfig);

             routerWebImpl = new RouterWebImpl();
            
             session.setAttribute("routerWebImpl", routerWebImpl);
             
             session.setAttribute(Constants.CONFIGURATION_RESULT_KEY, null);
             session.setAttribute(Constants.CONFIGURATION_TIMESTAMP_KEY, null);
             session.setAttribute(Constants.TEMPLATE_TIMESTAMP_KEY, null);

             return (mapping.findForward("router_configuration_success"));
            }
        }


        if(servlet.getDebug() >= 1)
        {
            servlet.log("RouterConfigurationAction: currentRouterProfileName '" 
                    + currentRouterProfileName + "' in session " 
                    + session.getId());
        }


        // testing to see which command was executed
//        routerConfigurationFormBean.setCurrentConfig(tempTest);
    
        if(request.getParameter("submitUpdate") != null)
        {

            routerProfileName = routerConfigurationFormBean.getRouterProfileName();

            session.setAttribute(Constants.ROUTER_KEY, routers.getRouterByName(routerProfileName).getRouterProfileId());

            session.setAttribute(Constants.CONTROL_PORT_KEY, routerConfigurationFormBean.getControlPortName());
            session.setAttribute(Constants.CONTROL_CONNECTION_KEY, routerConfigurationFormBean.getControlConnectionName());

            
        }

        else if(request.getParameter("submitRebuild") != null)
        {


            if((template != null) || (request.getParameter("templateTextArea").trim().length() > 0))
            {
                if(template != null)
                {

                    String templateFileName = generateFilename(currentRouterProfileName + "-" + configurationTimeStamp + ".template");
                    String shellFileName = generateFilename(currentRouterProfileName + "-" + configurationTimeStamp + ".sh");
                    String configFileName = generateFilename(currentRouterProfileName + "-" + configurationTimeStamp + ".config");
                    
                    String templateFilePath = Constants.TMP_BASE_DIR + "/" + templateFileName;
                    String shellFilePath = Constants.TMP_BASE_DIR + "/" + shellFileName;
                    String configFilePath = Constants.TMP_BASE_DIR + "/" + configFileName;
                    
                    writeFile(templateFilePath, request.getParameter("templateTextArea"));

                    String rebuildCommand = "#!/bin/sh\n" + Constants.RTCONFIG_COMMAND + " " + request.getParameter("commandLine")  + " < " + templateFilePath  + " > " + configFilePath;
                    
                    writeFile(shellFilePath, rebuildCommand);

                    String setExecuteMode = executeCommandLine("chmod +x " + shellFilePath);
                    
                    String rebuiltConfigurationMessage = executeCommandLine("sh -c " + shellFilePath);

                    //Debug.println("ca.rrx.nw.rr.struts.router.RouterConfigurationAction.line 460 - rebuiltConfiguration:" + rebuiltConfiguration);
                    
                    routerConfigurationFormBean.setMessage(rebuiltConfigurationMessage);
                    
                    routerConfigurationFormBean.setConfigurationResult(loadFile(configFilePath, "ASCII"));

                    
                    session.setAttribute(Constants.CONFIGURATION_RESULT_KEY, "rebuilt");
                    
                    return (mapping.findForward("router_configuration_success"));
                }

            }

        }



        //
        // handle changes in drop downs
        //
        if(request.getParameter("commandIndex").equals("routerProfileName"))
        {
            tempTest = "routerProfileName";

            routerProfileName = request.getParameter("routerProfileName");
            //Debug.println("ca.rrx.nw.rr.struts.router.RouterConfigurationAction.line 482 - routerConfigurationFormBean:" + routerConfigurationFormBean);
            //Debug.println("ca.rrx.nw.rr.struts.router.RouterConfigurationAction.line 482 - routerProfileName:" + routerProfileName);
            session.setAttribute(Constants.ROUTER_KEY, routers.getRouterByName(routerProfileName).getRouterProfileId());



        }

        if(request.getParameter("commandIndex").equals("configurationTimeStamp"))
        {
        
            session.setAttribute(Constants.CONFIGURATION_TIMESTAMP_KEY, configurationTimeStamp);
            session.setAttribute(Constants.CONFIGURATION_RESULT_KEY, null);
            session.setAttribute(Constants.TEMPLATE_TIMESTAMP_KEY, null);

        }


        if(request.getParameter("commandIndex").equals("templateTimeStamp"))
        {
            session.setAttribute(Constants.TEMPLATE_TIMESTAMP_KEY, templateTimeStamp);
            session.setAttribute(Constants.CONFIGURATION_TIMESTAMP_KEY, null);
            session.setAttribute(Constants.CONFIGURATION_RESULT_KEY, null);
            routerConfigurationFormBean.setConfigurationResult(" ");
 
        }
        


        return (mapping.findForward("router_configuration_success"));
    }




    private String removeScriptWrapper(String cmd)
    {
        String[] args;
        String actualCmd;
        String wrapperScriptFilename;
        String wrapperScriptContents;

        actualCmd = null;
        args = splitBySpace(cmd);

        actualCmd = cmd + "\n\r";

        for(int i = 0 ; i < args.length ; i++)
        {
            actualCmd = actualCmd + args[i] + "\n\r";
        }

        // read contents of file and replace $1 with arg[1], $2 with arg[2], etc.

        wrapperScriptFilename       = args[0];
        wrapperScriptContents       = loadFile(wrapperScriptFilename, "ASCII");

        wrapperScriptContents = replaceFlags(wrapperScriptContents, args);

        return (/*actualCmd + "\n\r\n\r" + */wrapperScriptContents);
    }



    private String[] splitBySpace(String s)

    {

        StringBuffer sbTemp;

        ArrayList temp;

        Iterator it;

        int c;
        int lastSpaceIndex;


        lastSpaceIndex = 0;
        c = 0;

        temp = new ArrayList();

        sbTemp = new StringBuffer();



        for(int i = 0 ; i < s.length(); i++)

        {

            if((s.charAt(i) != ' '))
            {

                sbTemp.append(s.charAt(i));

            }

            else

            {

                lastSpaceIndex = i;
                temp.add(sbTemp.toString().trim());

                sbTemp.setLength(0);

            }

        }
        
        temp.add(s.substring(lastSpaceIndex, s.length()).trim());


        return((String[])temp.toArray(new String[]{}));

    }

    private String replaceFlags(String contents, String[] args)
    {
        int index;
        index = 0;
        StringBuffer sbTemp;
        String flag;

        sbTemp = new StringBuffer();

        flag = "$" + String.valueOf(1);
        index = contents.indexOf(flag);

        for(int i = 1 ; i < contents.length() ; i++)
        {
            if(contents.charAt(i) != '$')
            {
                sbTemp.append(contents.charAt(i));

            }
            else
            {
                int intArgNum;
                char charArgNum;
                StringBuffer temp;
                String tempString;

                temp = new StringBuffer();

                charArgNum = contents.charAt(i + 1);
                temp.append(charArgNum);

                tempString = new String(temp);

                intArgNum = Integer.parseInt(tempString);

                sbTemp.append(args[intArgNum]);
                sbTemp.append(" ");

                i = i + 1 + tempString.trim().length();



//                sbTemp.append(s.charAt(i));

//                if(contents.charAt(i+1) != '$'
            }
        }
/*
        for(int i = 1 ; i < args.length ; i++)
        {
            String flag;
            flag = "$" + String.valueOf(i);

//            contents = contents.replaceAll(flag, args[i]);

            index = contents.indexOf(flag);


        }
*/
        return(new String(sbTemp));
    }


    // UTILITY METHODS
    
    

    private String generateTimestamp()
    {
        Calendar c;
        String newTimestamp;
        NumberFormat nf;
        String year;
        String month;
        String day;
        String hour;
        String minute;
        String second;

        int yearInt;
        int monthInt;
        int dayInt;
        int hourInt;
        int minuteInt;
        int secondInt;

        nf = NumberFormat.getInstance();
        c = new GregorianCalendar();

        yearInt     = c.get(Calendar.YEAR);
        monthInt    = c.get(Calendar.MONTH) + 1;
        dayInt      = c.get(Calendar.DAY_OF_MONTH);
        hourInt     = c.get(Calendar.HOUR_OF_DAY);
        minuteInt   = c.get(Calendar.MINUTE);
        secondInt   = c.get(Calendar.SECOND);

        nf.setMinimumIntegerDigits(2);

        year   = (new Integer(yearInt)).toString();
        month   = nf.format(monthInt);
        day     = nf.format(dayInt);
        hour    = nf.format(hourInt);
        minute  = nf.format(minuteInt);
        second  = nf.format(secondInt);

        newTimestamp = year +  ":" + month +  ":" + day + "-" + hour + ":" + minute + ":" +  second;

        return (newTimestamp);
    }



	private String generateFilename(String rawFileName)
    {
        String filename;
        StringBuffer newFilename;
        String searchPattern;
        String insideParens;

        int index;
        index = 0;
        insideParens = null;
        newFilename = new StringBuffer();

        filename = rawFileName;

        filename = filename.replace(' ','_');
        filename = filename.replace(':','_');
        filename = filename.replace('/','_');

        // search for characters followed by a '.' (revision)
        searchPattern       = new String("(((\\w)|-)+(\\.)+?)");

        try
        {
            RE regexpr;
            boolean matched;
            String replacement;
            int indexEnd;

            indexEnd        = 0;
            replacement     = null;
            regexpr         = new RE(searchPattern); // look for any word followed by a '.'
            matched         = regexpr.match(filename);

            if(matched)
            {
                String start;
                String end;

                insideParens = regexpr.getParen(1);

                index       = filename.indexOf(insideParens);
                indexEnd    = filename.indexOf(".");

                replacement = "" + insideParens.substring(0, insideParens.length());

                start = filename.substring(0, index);
                end = filename.substring(indexEnd + 1, filename.length());

                filename = start + replacement + end;
                
            }
            else
            {
            }
        }
        catch (RESyntaxException e)
        {
            System.out.println("error");
        }

        return (filename);
    }



    private List appendVersions(Configurations configs)
    {
        List timeStamps;
        List timeAndRevisions;
        Iterator it;
        Set keys;
        Map configMap;

        timeAndRevisions    = new ArrayList();
        timeStamps          = configs.getConfigurationTimeStamps();

        configMap           = (Map)configs.getConfigurations();
        keys                = (configMap).keySet();

        it = keys.iterator();

        while(it.hasNext())
        {
            Configuration config;
            String timeStamp;
            String revision;

            config = (Configuration)configMap.get(it.next());

            timeStamp   = config.getTimeStored();
            revision    = config.getRevision();

            timeAndRevisions.add(timeStamp + " - " + revision);
        }

        return timeAndRevisions;
    }



    private void writeFile(String filename, String templateFileContents)
    {
        try
        {
            File file;
            FileOutputStream fos;
            StringBuffer stringBuffer;
            String temp;

            temp = templateFileContents;
            file = new File(filename);
            fos = new FileOutputStream(file);

            fos.write(temp.getBytes());
            
            fos.close();
            
        }
        catch(IOException e)
        {
            Debug.println("ERROR: routerConfigurationAction:writeFile: " + e.getMessage());
        }
    }



    /**
     * Accepts a string with lines separated by '\n' and places each
     * line into a separate element of a string array.
     *
     * @param
     *
     * @return
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        trimArray(temp);

        return((String[])temp.toArray(new String[]{}));
    }


    private static String loadFile(String filePath, String encoding)
    {
        File inputFile;
        FileInputStream is;
        String returnString;
        ByteArrayOutputStream bos;

        returnString = new String("");
        bos = new ByteArrayOutputStream();

        try
        {
            long total;
            byte [] buffer;

            inputFile   = new File(filePath);
            is          = new FileInputStream(inputFile);
            total       = 0;
            buffer      = new byte[1024];

            while (true)
            {
                int nRead;

                nRead = is.read(buffer,0,buffer.length);

                total += nRead;

                if (nRead <=0)
                {
                    break;
                }

                bos.write(buffer,0, nRead);
            }

            is.close();
            bos.close();
        }
        catch (IOException e)
        {
            //System.out.print ("Error Reading file: " + e + "\n");
            return ("Error Reading file: " + e + "\n");
        }
        catch (Exception e)
        {
            //System.out.print ("Error Reading: " + e + "\n");
            return ("Error Reading: " + e + "\n");
        }

        try
        {
            byte[] bytes = bos.toByteArray();

            if (encoding != null)
            {
                returnString = new String(bytes,0, bytes.length, encoding);
            }
            else
            {
                returnString = new String(bytes);
            }
        }
        catch (UnsupportedEncodingException enex)
        {
            ////Debug.println("Unable to Convert Source File");
            return ("Unable to Convert Source File");
        }

        return (returnString);
    }

     private static void saveFile(ByteArrayInputStream bis, String filePath)
     {
        File outputFile;
        FileOutputStream os;

        try
        {
            int c;

            outputFile = new File(filePath);
            os = new FileOutputStream(outputFile);

            while ((c = bis.read()) != -1)
            {
                os.write(c);
            }

            os.close();
        }
        catch (IOException e)
        {
            System.out.print ("Error Writing file: " + e + "\n");
        }
        catch (Exception e)
        {
            System.out.print ("Error Writing: " + e + "\n");
        }
    }



public static final String[] tokenize(String in)
  {
//    Vector v = new Vector();
    List v = new ArrayList();
    StringBuffer b = new StringBuffer();

    for(int i=0; i < in.length(); i++)
    {
        if(in.charAt(i)==' ')
        {
            if(b.length() != 0)
            {
//                v.addElement(b.toString());
                v.add(b.toString());
                b.setLength(0);
            }
        }
        else if(in.charAt(i)=='\'')
        {
            int next = in.indexOf('\'', i+1);

            if(next != -1)
            {
                b.append(in.substring(i+1, next));
                i = next+1;
            }
        }
        else if(in.charAt(i)=='\"')
        {

            int next = in.indexOf('\"', i+1);

            if(next != -1)
            {
                b.append(in.substring(i+1, next));
                i = next+1;
            }
        }
        else
        {
            b.append(in.charAt(i));
        }
    }

    if(b.length() != 0)
    {
//        v.addElement(b.toString());
        v.add(b.toString());
    }

    String[] result = new String[v.size()];
    Iterator it;
    int i;
    i = 0;
    it = v.iterator();

    while(it.hasNext())
    {
        result[i] = (String)(it.next());
        i++;
    }
    
/*
    for(int i=0; i<v.size(); i++)
    {
        result[i] = (String)(v.elementAt(i));
    }
*/
    return result;
  }


    //modified to allow for command line-  RRX NW
    public String executeCommandLine(String commandLine)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        //stringBuffer.ensureCapacity(4000);
        String newline = System.getProperty("line.separator");

        String[] cmdLineTokens;

        cmdLineTokens = tokenize(commandLine);
        
        try
        {
            
            //Debug.println("ca.rrx.nw.rr.struts.router.RouterConfigurationAction.line 1056 - cmdLineTokens:" + cmdLineTokens);
            Process process = Runtime.getRuntime().exec(cmdLineTokens);
            //Process process = Runtime.getRuntime().exec(commandArray);
//            Process process = Runtime.getRuntime().exec(cmdLine);
            
            //process.waitFor();
            InputStream in = process.getInputStream();
            InputStream er = process.getErrorStream();
           // OutputStream ou = process.getOutputStream();
            
            BufferedReader inReader = new BufferedReader(new InputStreamReader(in));
            BufferedReader erReader = new BufferedReader(new InputStreamReader(er));
            
            String line;
            int c;
            c = 0;
            
            do
            {
               
                line = erReader.readLine();
                
                if(line != null) 
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            erReader.close();
            
            c = 0;
            
            if (stringBuffer.length() > 10) return(new String(stringBuffer));
            
            do
            {
               
                line = inReader.readLine();
                
                if(line != null) 
                {
                    stringBuffer.append(line + newline);
                    
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            inReader.close();
            
        }
        catch(IOException e)
        {
            System.out.println("Command Line Exec Error = " + e.getMessage());
        }
/*        catch(InterruptedException i)
        {
            System.out.println("Command Line Wait Error = " + i.getMessage());
        }
*/
        //return("debug cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }

    
    //modified to allow for command array-  RRX NW
    public String executeCommandArray(String[] commandArray)
    {
        
        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");

        String[] cmdLineTokens;

        //cmdLineTokens = tokenize(commandLine);
        
        try
        {
            
            //Debug.println("ca.rrx.nw.rr.struts.router.RouterConfigurationAction.line 1056 - cmdLineTokens:" + cmdLineTokens);
            Process process = Runtime.getRuntime().exec(commandArray);
            //Process process = Runtime.getRuntime().exec(commandArray);
//            Process process = Runtime.getRuntime().exec(cmdLine);
            
            //process.waitFor();
            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            
            String line;
            int c;
            c = 0;
            
            do
            {
                line = reader.readLine();
                
                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }
                else
                {
                    stringBuffer.append(newline);
                }
                c++;
            }
            
            while(line != null);
            
            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Command Line Exec Error = " + e.getMessage());
        }
/*        catch(InterruptedException i)
        {
            System.out.println("Command Line Wait Error = " + i.getMessage());
        }
*/
        //return("debug cmdLine: " + cmdLine + " >>> cmdResult: \n" + new String(stringBuffer));
        return(new String(stringBuffer));
    }
    
    /**
     * Removes leading empty Strings from an ArrayList of String
     * objects.
     *
     * @param t 
     *
     */
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;

        idxRemove = new int[100];
        count = 0;

        if(!t.isEmpty())
        {

            for(int i = 0 ; i < t.size() ; i++)
            {
               String s;

               s = t.get(i).toString().trim();

               if(s.length() == 0)
               {  
                   idxRemove[count] = i;
                   count++;
               }
               else
               {
                   break;
               }
            }

            for(int i = count ; i > 0 ; i--)
            {
                  t.remove(0);
            }
        }
    }




}