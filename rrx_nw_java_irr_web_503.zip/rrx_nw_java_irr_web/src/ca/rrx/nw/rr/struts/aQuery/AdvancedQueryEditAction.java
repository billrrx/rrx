package ca.rrx.nw.rr.struts.aQuery;

import ca.rrx.nw.rr.Constants;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class AdvancedQueryEditAction extends Action
{
    /**
     * Update command if edits are to be submitted to IRR
     */
    private String command;

    {
        command = null;
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Process the specified HTTP request, and create the corresponding HTTP
     * response (or forward to another web component that will create it).
     * Return an <code>ActionForward</code> instance describing where and how
     * control should be forwarded, or <code>null</code> if the response has
     * already been completed.
     *
     * @param mapping The ActionMapping used to select this instance
     * @param actionForm The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String results;
        String rpslEdit;
        String commandIndex;
        HttpSession session;
        AdvancedQueryEditForm advancedQueryEditForm;

        results         = null;
        commandIndex    = null;
        rpslEdit        = ((AdvancedQueryEditForm) form).getRpslEdit();
        session         = request.getSession();


        if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
        {
            return (mapping.findForward("session_timeout"));
        }

        advancedQueryEditForm         = (AdvancedQueryEditForm)session.getAttribute("advancedQueryEditForm");

        if(request.getParameter("submitIrr") != null)
        {
            commandIndex = "submitIrr";
        }
        else if(request.getParameter("submitSaveToFile") != null)
        {
            commandIndex = "submitSaveToFile";
        }
        else if(request.getParameter("submitLogout") != null)
        {
            commandIndex = "submitLogout";
        }

        // Save form to session
        session.setAttribute(Constants.AQUERY_EDIT_KEY, form);

        if (servlet.getDebug() >= 1)
        {
            servlet.log("AdvancedQueryEditAction: AdvancedQuery '" + commandIndex + 
                      "' in session " + session.getId());
        }

/*
        if(commandIndex.equals("submitIrr"))
        {
            return (mapping.findForward("advancedQuery_submit_confirmation"));
        }
*/

        if(request.getParameter("submitIrr") != null)
        {
//            advancedQueryEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            advancedQueryEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            session.setAttribute("rpslToSubmit", request.getParameter("rpslToSubmit"));
            return (mapping.findForward("irr_submit_confirmation"));
        }

        if(commandIndex.equals("submitSaveToFile"))
        {
            advancedQueryEditForm.setRpslToSubmit(request.getParameter("rpslToSubmit"));
            // write to file
            // redirect to advancedQueryEdit.jsp, w/c opens new window if created?
//            return (mapping.findForward("aquery_edit"));

        }
        else if(commandIndex.equals("submitLogout"))
        {
            return (mapping.findForward("signout_success"));
        }

        // Forward control to URI specified in struts-config.xml
        return (mapping.findForward("aquery_edit"));
    }
}