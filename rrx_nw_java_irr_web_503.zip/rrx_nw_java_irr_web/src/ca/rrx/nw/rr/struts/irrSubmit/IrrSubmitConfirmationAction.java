package ca.rrx.nw.rr.struts.irrSubmit;

import ca.rrx.nw.rr.Constants;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;


import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Iterator;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.Address;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;

// for copy object routine
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

import ca.rrx.nw.rr.util.Debug;

public final class IrrSubmitConfirmationAction extends Action
{

    private String filepath = Constants.FULL_BASE_DIR + "/tmp/";
    private String filename = null;

    // move cmdupdate into irrUpdate later (here for debugging)
    String cmdupdate = null;

    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        OperatorWebImpl operatorWebImpl;
        ServerWebImpl serverWebImpl;
        IrrSubmitConfirmationForm irrSubmitConfirmationForm;
        HttpSession session;



        session  = request.getSession();



       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        irrSubmitConfirmationForm   = (IrrSubmitConfirmationForm)session.getAttribute("irrSubmitConfirmationForm");

        //get the session beans from the session - Bill R
        if (session.getAttribute("operatorWebImpl") != null)
        {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null)
        {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }

        //set to copy of bean
        irrSubmitConfirmationForm = ((IrrSubmitConfirmationForm) form);
        session.setAttribute(Constants.IRR_SUBMIT_CONFIRMATION_KEY, irrSubmitConfirmationForm);

        String operatorLoginName;
        String operatorSessionName;
        Object operatorId;
        Object operatorSessionId;
        OperatorModel operatorModel;
        OperatorInformation operatorInformation;
        OperatorSessions operatorSessions;
        OperatorSession currentOperatorSession;
        String currentOperatorSessionName;
        String currentOperatorSessionMntCode;

        ServerModel serverModel;
        String serverIp;
        String serverUpdatePort;
        OperatorSession currentSession;

        currentOperatorSessionMntCode   = "";
        serverModel = null;
        serverIp = "";
        serverUpdatePort = "";

        operatorLoginName   = "";
        operatorSessionName = "";
        operatorId          = null;
        operatorSessionId   = null;

        if ((String)session.getAttribute("MM_Username") != null) 
        {
            operatorLoginName = (String)session.getAttribute("MM_Username");
        }

        operatorModel               = operatorWebImpl.getModel(operatorLoginName);
        operatorInformation         = operatorModel.getOperatorInformation();
        operatorSessionId           = operatorInformation.getDefaultSessionId();
        operatorSessions            = operatorModel.getOperatorSessions();
        operatorId                  = operatorSessions.getOperatorId();
        currentOperatorSession      = operatorSessions.getOperatorSessionById(operatorSessionId);
        currentOperatorSessionName  = currentOperatorSession.getSessionProfileName();

        operatorSessions    = operatorModel.getOperatorSessions();
        currentSession      = operatorSessions.getOperatorSessionById((Object)session.getValue(Constants.THIS_OPERATOR_SESSION_KEY));

        if(currentSession == null)
        {
            currentSession      = operatorSessions.getOperatorSessionById((Object)operatorInformation.getDefaultSessionId());
        }

        if(currentSession != null)
        {
            currentOperatorSessionMntCode = currentSession.getMaintainerCode();
        }


        serverModel         = serverWebImpl.getModel(currentSession.getPrimaryServerProfileId());
        serverIp            = serverModel.getServerIpv4();
        serverUpdatePort    = serverModel.getUpdatePort();

/*
        if (servlet.getDebug() >= 1)
        {
            servlet.log("OperatorAction: Operator '" + operatorLoginName +
            "' in session " + session.getId());
        }
*/
        // set forward string here

//        getForwardKey()





        String fwdKey;
        String servletInfo;

        servletInfo = "";
        fwdKey      = "";

        // determine which page called this one and then forward
        // back to it if the 'Edit' button is pressed
        servletInfo = irrSubmitConfirmationForm.getResults();

        if((servletInfo != null) && (servletInfo.length() > 0))
        {
            if(servletInfo.equals("/reportEdit.do"))
            {
                fwdKey = "report_edit";
            }
            else if(servletInfo.equals("/operator.do"))
            {
                fwdKey = "operator_profile_success";
            }
            else if(servletInfo.equals("/routerTransitPortProfile.do"))
            {
                fwdKey = "router_transit_port_profile_success";
            }
            else if(servletInfo.equals("/routerProfile.do"))
            {
                fwdKey = "router_profile_success";
            }
            else if(servletInfo.equals("/aQueryEdit.do"))
            {
                fwdKey = "aquery_edit";
            }
        }
        else
        {
            fwdKey = "irr_submit_result";
        }







        if(request.getParameter("submitEdit") != null)
        {
            // reset irr submit message (change this to setMessageId or 
            //  something later so no language-specific code
            irrSubmitConfirmationForm.setIrrSubmitMessage("");
            return (mapping.findForward(fwdKey));
        }
        else if (request.getParameter("submitConfirmed") != null)
        {
            String rpslToSubmit;
            String results;
            String pathInfo;


            pathInfo = request.getContextPath() + "_" + request.getServletPath() + "_" + request.getPathInfo();
            rpslToSubmit = request.getParameter("rpslToSubmit");


            // check if user's maintainer code matches the object's 'mnt-by' attribute, 
            // if even one does not match return an error
            // does not catch it if user changes 'mnt-by' to match their own maintainer
            // code (?)
            if(isMntCodeSame(rpslToSubmit, currentOperatorSessionMntCode))
            {
                results = updateIrr(rpslToSubmit, serverIp, serverUpdatePort);

                irrSubmitConfirmationForm.setResults(results);

//                cmdupdate = removeScriptWrapper(cmdupdate);

                irrSubmitConfirmationForm.setCommand(cmdupdate);
                irrSubmitConfirmationForm.setIrrSubmitMessage("");
                return (mapping.findForward("irr_submit_result"));
            }
            else
            {
//                irrSubmitConfirmationForm.setIrrSubmitMessage("IRR Submission Error: Maintainer codes do not match.");
                irrSubmitConfirmationForm.setIrrSubmitMessage("IRR Submission Error: Maintainer codes do not match.");
                session.setAttribute(Constants.IRR_SUBMIT_CONFIRMATION_KEY, irrSubmitConfirmationForm);

                return (mapping.findForward("irr_submit_confirmation"));
                //return (mapping.findForward(fwdKey));
            }
        }

        return (mapping.findForward("irr_submit_result"));
    }

    private String removeScriptWrapper(String cmd)
    {
        String[] args;
        String actualCmd;
        String wrapperScriptFilename;
        String wrapperScriptContents;

        actualCmd = null;
        args = splitBySpace(cmd);

//        args[0] is the wrapper script
//        args[1] is the first argument after the wrapper script ($1 to the script)
//        args[2] is the first argument after the wrapper script ($2 to the script)
//        args[etc] is the first argument after the wrapper script ($etc to the script)

        actualCmd = cmd + "\n\r";

        for(int i = 0 ; i < args.length ; i++)
        {
            actualCmd = actualCmd + args[i] + "\n\r";
        }

        // read contents of file and replace $1 with arg[1], $2 with arg[2], etc.

        wrapperScriptFilename       = args[0];
        wrapperScriptContents       = loadFile(wrapperScriptFilename, "ASCII");

        wrapperScriptContents = replaceFlags(wrapperScriptContents, args);



//        args = 
//        removeScriptWrapper
//      executed by tomcat
//    "/usr/local/jakarta-tomcat/webapps/irr/bin/update.sh ARDNOC /usr/local/jakarta-tomcat/webapps/irr/tmp/irr70582.txt dooka.canet4.net 3502
//      actual
// /usr/local/bird/bin/update 2>&1 dooka.canet4.net 3502 ARDNOC /usr/local/jakarta-tomcat/webapps/irr/tmp/irr70582.txt

        return (/*actualCmd + "\n\r\n\r" + */wrapperScriptContents);
    }


/*

    private String[] splitBySpace(String s)

    {

        StringBuffer sbTemp;

        ArrayList temp;

        Iterator it;

        int c;
        int lastSpaceIndex;


        lastSpaceIndex = 0;
        c = 0;

        temp = new ArrayList();

        sbTemp = new StringBuffer();



        for(int i = 0 ; i < s.length(); i++)

        {

            if((s.charAt(i) != ' '))
            {

                sbTemp.append(s.charAt(i));

            }

            else

            {

                lastSpaceIndex = i;
                temp.add(sbTemp.toString().trim());

                sbTemp.setLength(0);

            }

        }
        
        temp.add(s.substring(lastSpaceIndex, s.length()).trim());


        return((String[])temp.toArray(new String[]{}));

    }
*/

    String replaceFlags(String contents, String[] args)
    {
        int index;
        index = 0;
        StringBuffer sbTemp;
        String flag;

        sbTemp = new StringBuffer();

        flag = "$" + String.valueOf(1);
        index = contents.indexOf(flag);

        for(int i = 1 ; i < contents.length() ; i++)
        {
            if(contents.charAt(i) != '$')
            {
                sbTemp.append(contents.charAt(i));

            }
            else
            {
                int intArgNum;
                char charArgNum;
                StringBuffer temp;
                String tempString;

                temp = new StringBuffer();

                charArgNum = contents.charAt(i + 1);
                temp.append(charArgNum);

                tempString = new String(temp);

                intArgNum = Integer.parseInt(tempString);

                sbTemp.append(args[intArgNum]);
                sbTemp.append(" ");

                i = i + 1 + tempString.trim().length();



//                sbTemp.append(s.charAt(i));

//                if(contents.charAt(i+1) != '$'
            }
        }
/*
        for(int i = 1 ; i < args.length ; i++)
        {
            String flag;
            flag = "$" + String.valueOf(i);

//            contents = contents.replaceAll(flag, args[i]);

            index = contents.indexOf(flag);


        }
*/
        return(new String(sbTemp));
//        return(contents);
    }

    /**
     * Method for checking if any 'mnt-by' attributes have a maintainer 
     * code that does not match user's maintainer code.
     */
     private boolean isMntCodeSame(String rpsl, String mntCode)
    {
        String[] rpslSplit;

        rpslSplit = split(rpsl);


        for(int i = 0 ; i < rpslSplit.length ; i++)
        {
            String attr;
            int index;
            String rpslMntCode;
            String upperMntCode;

            upperMntCode    = "";
            rpslMntCode     = "";
            upperMntCode    = mntCode.toUpperCase();
            rpslSplit[i]    = rpslSplit[i].trim();

            // check attribute
            index = rpslSplit[i].indexOf(':');

            if(index > -1)
            {
                attr = rpslSplit[i].substring(0, index);

                attr = attr.trim();

                if(attr.equals("mnt-by"))
                {
                    rpslMntCode = rpslSplit[i].substring(index + 1, rpslSplit[i].length()).trim();
                    rpslMntCode = rpslMntCode.toUpperCase();

                    if(!rpslMntCode.equals(upperMntCode))
                    {
                        return(false);
                    }
//                    break;
                }
//                else
//                {
//                }

            }
        }

         return (true);
    }


    /**
     * Generic utility for updating irr. Sends passed-in string to IRR.
     *
     * @param stringToSend rpsl string to be sent to server
     */
    public String updateIrr(String stringToSend, String serverIp, String updatePort)
    {
        String[] stringToSendSplit;
        String execresults;
        String newline;
        int randomNumber;
        Integer randInt;
        StringBuffer stringBuffer;
        String sourceCode;

        sourceCode      = "";
        stringBuffer    = null;
        cmdupdate       = null;

        // create random filename
        randomNumber    = (int)(Math.random() * 100000);
        randInt         = new Integer(randomNumber);
        filename        = "irr" + randInt.toString() + ".txt";

        stringToSendSplit = split(stringToSend);

        // retrieve the 'source:' attribute from rpsl being submitted



        for(int i = 0 ; i < stringToSendSplit.length ; i++)
        {
            String attr;
            int index;
            char testComment;

            stringToSendSplit[i] = stringToSendSplit[i].trim();


            // if not a comment line
//            if(stringToSendSplit[i].charAt(0) != '%')
//            {
                // check attribute
                index = stringToSendSplit[i].indexOf(':');

                if(index > -1)
                {
                    attr = stringToSendSplit[i].substring(0, index);

                    attr = attr.trim();

                    if(attr.equals("source"))
                    {
                        sourceCode = stringToSendSplit[i].substring(index + 1, stringToSendSplit[i].length()).trim();
                        sourceCode = sourceCode.toUpperCase();
                        break;
                    }
                    else
                    {
    //                    sourceCode = "nosource[" + attr + "]";
                    }

                }
  //          }

        }

//        srcDb = sourceCode;


//    currentOperatorSession.getMaint
//    currentOperatorSession.getPrimaryServerProfileId

        // create command to be executed

//serverIp
//updatePort

        newline = System.getProperty("line.separator");

        // get form with component containing string to be sent
//        operatorForm = (OperatorForm) session.getAttribute(Constants.OPERATOR_PROFILE_KEY);


        // get string to be sent from form component
//        rpslToSend = operatorForm.getRpslToSend();

        // parse string to be sent by '\n'. place each line into an element of a string array
//        stringToSendSplit = split(stringToSend);

        try
        {
            File file;
            FileOutputStream fos;

            file = new File(filepath + filename);
            fos = new FileOutputStream(file);

            for(int i = 0 ; i < stringToSendSplit.length ; i++)
            {
                String temp;

                temp = stringToSendSplit[i] + newline;
                fos.write(temp.getBytes());
            }

//Debug.println("ProfileSubmitConfirmationAction: Data written to temporary file");

            stringBuffer = new StringBuffer();


            try

            {
                Process process;
                String srcDb;
                String line;
                int c;
                int exitVal;
                InputStream in;

                InputStream err;
                BufferedReader reader;

                BufferedReader errReader;

                c       = 0;
                srcDb   = "";
                srcDb   = sourceCode;

                cmdupdate = Constants.FULL_BASE_DIR 
                            + Constants.IRRUPDATE_SCRIPT1 + " " 
                            + serverIp + " " 
                            + updatePort + " "
                            + srcDb + " " 
                            + filepath + filename;


                process = Runtime.getRuntime().exec(cmdupdate);

                exitVal = process.waitFor();

                in = process.getInputStream();

                err = process.getErrorStream();
                reader = new BufferedReader(new InputStreamReader(in));

                errReader = new BufferedReader(new InputStreamReader(err));


                if(exitVal == 0)
                {

                        do

                        {

                            line = reader.readLine();


                            if(line != null)

                            {

                                stringBuffer.append(line + newline);

                            }

                            else
                            {
                               stringBuffer.append(newline);
                            }

                            c++;

                        }

                        while(line != null);

                 }
                 else
                 {
//Debug.println("ProfileSubmitConfirmationAction.java: Error executing command-line");
                        do

                        {

                            line = errReader.readLine();


                            if(line != null)

                            {

                                stringBuffer.append(line + newline);

                            }

                            else
                            {
                                stringBuffer.append(newline);
                            }

                            c++;

                        }

                        while(line != null);
                }

                reader.close();


            }

            catch(IOException e)

            {

                System.out.println("Error");

            }
            catch(InterruptedException iex)
            {
                System.out.println("Error");

            }

//Debug.println("ProfileSubmitConfirmationAction (2): " + stringBuffer.toString());

        }
        catch(IOException e)
        {
//Debug.println("ProfileSubmitConfirmationAction (3): Error writing to temporary file");
        }

        return(stringBuffer.toString());
    }


    private String[] split(String s)

    {

        StringBuffer sbTemp;

        ArrayList temp;

        Iterator it;

        int c;



        c = 0;

        temp = new ArrayList();

        sbTemp = new StringBuffer();



        for(int i = 0 ; i < s.length(); i++)

        {

            if(s.charAt(i) != '\n')

            {

                sbTemp.append(s.charAt(i));

            }

            else

            {

                temp.add(sbTemp.toString().trim());

                sbTemp.setLength(0);

            }

        }


        return((String[])temp.toArray(new String[]{}));

    }

    private String[] splitBySpace(String s)

    {

        StringBuffer sbTemp;

        ArrayList temp;

        Iterator it;

        int c;
        int lastSpaceIndex;


        lastSpaceIndex = 0;
        c = 0;

        temp = new ArrayList();

        sbTemp = new StringBuffer();



        for(int i = 0 ; i < s.length(); i++)

        {

            if((s.charAt(i) != ' '))
            {

                sbTemp.append(s.charAt(i));

            }

            else

            {

                lastSpaceIndex = i;
                temp.add(sbTemp.toString().trim());

                sbTemp.setLength(0);

            }

        }
        
        temp.add(s.substring(lastSpaceIndex, s.length()).trim());


        return((String[])temp.toArray(new String[]{}));

    }


    private static String loadFile(String filePath, String encoding)
    {
        File inputFile;
        FileInputStream is;
        String returnString;
        ByteArrayOutputStream bos;

        returnString = new String("");
        bos = new ByteArrayOutputStream();

        try
        {
            long total;
            byte [] buffer;

            inputFile   = new File(filePath);
            is          = new FileInputStream(inputFile);
            total       = 0;
            buffer      = new byte[1024];

            while (true)
            {
                int nRead;

                nRead = is.read(buffer,0,buffer.length);

                total += nRead;

                if (nRead <=0)
                {
                    break;
                }

                bos.write(buffer,0, nRead);
            }

            is.close();
            bos.close();
        }
        catch (IOException e)
        {
            //System.out.print ("Error Reading file: " + e + "\n");
            return ("Error Reading file: " + e + "\n");
        }
        catch (Exception e)
        {
            //System.out.print ("Error Reading: " + e + "\n");
            return ("Error Reading: " + e + "\n");
        }

        try
        {
            byte[] bytes = bos.toByteArray();

            if (encoding != null)
            {
                returnString = new String(bytes,0, bytes.length, encoding);
            }
            else
            {
                returnString = new String(bytes);
            }
        }
        catch (UnsupportedEncodingException enex)
        {
            ////Debug.println("Unable to Convert Source File");
            return ("Unable to Convert Source File");
        }

        return (returnString);
    }
}