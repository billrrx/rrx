package ca.rrx.nw.rr.struts.operator;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.Operators;
import ca.rrx.nw.rr.model.operator.model.Operator;

import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.Address;

import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;


 
public final class AdminOperatorAction extends Action
{

    public ActionForward perform(ActionMapping mapping,
       ActionForm form,
       HttpServletRequest request,
       HttpServletResponse response)
         throws IOException, ServletException
    {
         // Switch for Debug Mode (true/false)
        
        boolean debugMode = false; 
         

       // Variable Declaration

                 
        String       submitApprove		= request.getParameter("submitApprove");
        String       submitReset		= request.getParameter("submitReset");
        String       submitCancel		= request.getParameter("submitCancel");
        String       submitDelete		= request.getParameter("submitDelete");
         
        String       firstName               	= request.getParameter("firstName"); 
        String       newOperatorFullName        = request.getParameter("newOperatorFullName");
                         
        //init local parameters
        
        Locale           	locale               = getLocale(request);
        MessageResources 	messageResources     = getResources();
        HttpSession      	session              = request.getSession();


        
        AdminOperatorForm	adminOperatorForm    = (AdminOperatorForm) form;
        
     
        //init model getters

       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }

        String             	operatorLoginName    = null;
        OperatorWebImpl    	operatorWebImpl      = new OperatorWebImpl();

        //get the operatorLoginName from the session
       
       //Debug.println("AdminOperatorAction - inside class:="+ new Date());

         
       if ((String)session.getAttribute(Constants.USERNAME_KEY) != null)
       {
          operatorLoginName = (String)session.getAttribute(Constants.USERNAME_KEY);
       }
       else
       {
          return (mapping.findForward("main"));
       }

       OperatorModel		operatorModel 		= operatorWebImpl.getModel(operatorLoginName);
       Operators 		operators 		= operatorModel.getOperators();
       Operators 		newOperators 		= operatorModel.getNewOperators();
       Operator                 selectedOperator;


      // selectedOperator  = newOperators.getOperatorByFullName((Object)operatorLoginName);

       if (request.getParameter("newOperatorFullName") != null)
       { 
           selectedOperator  = newOperators.getOperatorByFullName(request.getParameter("newOperatorFullName"));

       }
       else
       {
           adminOperatorForm.setMessage(" "); 
           return (mapping.findForward("operator_profile_admin"));
       }  
 
      
        
        //pick up basic default IRR Operator params
       
        //Debug.println("AdminOperatorAction - inside class:adminOperatorForm="+ adminOperatorForm);

      
   
       
        if  (submitApprove != null)
        {
               
            //update database Insert into OperatorProfie Table
            
             
            
            OperatorModel       newOperatorModel       = new OperatorModel();
            OperatorInformation newOperatorInformation = new OperatorInformation();
            Address             newAddress             = new Address();
            
            adminOperatorForm.setOperatorId("Approved"); 
            copyNotNullObjectProperties(newOperatorInformation, adminOperatorForm);
            copyNotNullObjectProperties(newAddress, adminOperatorForm);
            

            newOperatorInformation.setAddress(newAddress); 
            
            
            if (adminOperatorForm.getMaintainerCodes().equals("not-set"))
            {
            newOperatorInformation.setNicHandle(request.getParameter("nicHandle"));
            newOperatorInformation.setMaintainerCodes(request.getParameter("maintainerCodes"));
             //update the new operator database
            operatorWebImpl.update(newOperatorInformation);
            //flag beans model to null so reloads the database on findForward
            operatorWebImpl      = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            //return to the confirmation Page
            adminOperatorForm.setMessage("Please set the Maintainer ID"); 
            return (mapping.findForward("operator_profile_admin"));                
                
            }
            
            if (adminOperatorForm.getNicHandle().equals("not-set"))
            {
            newOperatorInformation.setNicHandle(request.getParameter("nicHandle"));
            newOperatorInformation.setMaintainerCodes(request.getParameter("maintainerCodes"));
             //update the new operator database
            operatorWebImpl.update(newOperatorInformation);
            //flag beans model to null so reloads the database on findForward
            operatorWebImpl      = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            //return to the confirmation Page
            adminOperatorForm.setMessage("Please set the NIC Handle"); 
            return (mapping.findForward("operator_profile_admin"));                
                
            }
            //overwrite the fresh ones with the form stuff 
           
            
            //update the regular operator database
            operatorWebImpl.add(newOperatorInformation);
            //remove from the new operator database
            //operatorWebImpl.delete(newOperatorInformation);
             
            //flag beans model to null so reloads the database on findForward
            //operatorModel = null;
            operatorWebImpl      = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
          
            //return to the confirmation Page
            adminOperatorForm.setMessage("New operator successfully approved "); 
            return (mapping.findForward("operator_profile_admin"));

   
        } 
             
        if (submitReset != null)
        {
            //Debug.println("AdminOperatorAction - Reset:AddOperatorForm="+ submitReset);
            adminOperatorForm.setMessage(" "); 
            return (mapping.findForward("operator_profile_admin"));
        } 
                  
        if (submitCancel != null) 
        {
            //Debug.println("AdminOperatorAction - Cancel:adminOperatorForm="+ submitCancel);
            adminOperatorForm.setMessage(" "); 
            return (mapping.findForward("administrator_profile_success"));   
        }
   
        if (submitDelete != null) 
        {
            OperatorInformation newOperatorInformation = selectedOperator.getOperatorInformation();
            newOperatorInformation.setOperatorId("Approved");
            
            if (newOperators.getOperators().size() == 1)
            {
            //update the new operator database
            operatorWebImpl.delete(newOperatorInformation);
            //flag beans model to null so reloads the database on findForward
            operatorWebImpl      = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            //Debug.println("AdminOperatorAction - Delete:adminOperatorForm="+ submitDelete);
            adminOperatorForm.setMessage(" ");
            session.setAttribute(Constants.NEW_OPERATOR_KEY, "false");
            return (mapping.findForward("administrator_profile_success"));
            }
            else
            {
            //update the new operator database
            operatorWebImpl.delete(newOperatorInformation);
            //flag beans model to null so reloads the database on findForward
            operatorWebImpl      = new OperatorWebImpl();
            session.setAttribute("operatorWebImpl", operatorWebImpl);
            //Debug.println("AdminOperatorAction - Delete:adminOperatorForm="+ submitDelete);
            adminOperatorForm.setMessage("New operator successfully deleted ");
            return (mapping.findForward("operator_profile_admin"));
            }
               
        }    
   
        if (firstName != null)
        {
            //Debug.println("AdminOperatorAction - First Name:AddOperatorForm="+ firstName);
            adminOperatorForm.setMessage(" "); 
            return (mapping.findForward("operator_profile_admin"));
        } 

        
        if (newOperatorFullName != null)
        {
            //Debug.println("AdminOperatorAction - First Name:AddOperatorForm="+ newOperatorFullName);
            adminOperatorForm.setMessage(" "); 
            return (mapping.findForward("operator_profile_admin"));
        } 

   
  
  
           
        if (servlet.getDebug() >= 1)
        {
            servlet.log("AdminOperatorAction: Operator '" + operatorLoginName +
"' in session " + session.getId());
        }
     
        adminOperatorForm.setMessage(" ");         
        return (mapping.findForward("operator_profile_admin"));
  
    }    
     
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
        throws IOException, ServletException 
   {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {
                String name = fromObjectDescriptors[i].getName();
                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);
                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("AdminOperatorAction:copyObjectProperties ", t);
            throw new ServletException("AdminOperatorAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("AdminOperatorAction:copyObjectProperties ", t);
            throw new ServletException("AdminOperatorAction:copyObjectProperties ", t);
        }
    }
}