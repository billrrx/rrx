package ca.rrx.nw.rr.struts.policy;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class PolicyGenerationForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    private String routerManufacturer;
    private String fromToAutNumSelect;
    private String rtrOneIp;
    private String p_type;
    private String toFromAutNumSelect;
    private String rtrTwoIp;
    private String toFromAutNumTextArea1;
    private String toFromAutNumTextArea2;
    private String autNumChanged;           // name of the autnum drop down that was changed
    private String fromToAutNumResults;
    private String toFromAutNumResults;
    private String autNumSubmitToIrr;       // aut-num object to be submitted to the irr
    private String policyResultsFilename;

    private String command;
    private String commandIndex;
    private String results;


    {
        routerManufacturer      = null;
        fromToAutNumSelect      = null;
        rtrOneIp                = null;
        p_type                  = null;
        toFromAutNumSelect      = null;
        rtrTwoIp                = null;
        toFromAutNumTextArea1   = null;
        toFromAutNumTextArea2   = null;
        autNumChanged           = null;
        toFromAutNumResults     = null;
        fromToAutNumResults     = null;
        autNumSubmitToIrr       = null;
        policyResultsFilename   = null;
    }

    // ----------------------------------------------------------- Properties
    public String getRouterManufacturer()
    {
        return (this.routerManufacturer);
    }

    public void setRouterManufacturer(String r)
    {
        this.routerManufacturer = r;
    }



    public String getFromToAutNumSelect()
    {
        return (this.fromToAutNumSelect);
    }

    public void setFromToAutNumSelect(String f)
    {
        this.fromToAutNumSelect = f;
    }



    public String getRtrOneIp()
    {
        return (this.rtrOneIp);
    }

    public void setRtrOneIp(String r)
    {
        this.rtrOneIp = r;
    }



    public String getP_type()
    {
        return (this.p_type);
    }

    public void setP_type(String p)
    {
        this.p_type = p;
    }



    public String getToFromAutNumSelect()
    {
        return (this.toFromAutNumSelect);
    }

    public void setToFromAutNumSelect(String t)
    {
        this.toFromAutNumSelect = t;
    }



    public String getRtrTwoIp()
    {
        return (this.rtrTwoIp);
    }

    public void setRtrTwoIp(String r)
    {
        this.rtrTwoIp = r;
    }



    public String getToFromAutNumTextArea1()
    {
        return (this.toFromAutNumTextArea1);
    }

    public void setToFromAutNumTextArea1(String t)
    {
        this.toFromAutNumTextArea1 = t;
    }



    public String getToFromAutNumTextArea2()
    {
        return (this.toFromAutNumTextArea2);
    }

    public void setToFromAutNumTextArea2(String t)
    {
        this.toFromAutNumTextArea2 = t;
    }


    public String getAutNumChanged()
    {
        return (this.autNumChanged);
    }

    public void setAutNumChanged(String a)
    {
        this.autNumChanged = a;
    }


    public String getToFromAutNumResults()
    {
        return (this.toFromAutNumResults);
    }

    public void setToFromAutNumResults(String t)
    {
        this.toFromAutNumResults = t;
    }

    public String getFromToAutNumResults()
    {
        return (this.fromToAutNumResults);
    }

    public void setFromToAutNumResults(String f)
    {
        this.fromToAutNumResults = f;
    }


    public String getAutNumSubmitToIrr()
    {
        return (this.autNumSubmitToIrr);
    }

    public void setAutNumSubmitToIrr(String a)
    {
        this.autNumSubmitToIrr = a;
    }

//autNumSubmitToIrr
//policyResultsFilename

    public String getPolicyResultsFilename()
    {
        return (this.policyResultsFilename);
    }

    public void setPolicyResultsFilename(String p)
    {
        this.policyResultsFilename = p;
    }



    /**
     * Return the generated command.
     */
    public String getCommand()
    {
        return (this.command);
    }

    /**
     * Set the command.
     *
     * @param tm The new comand
     */
    public void setCommand(String cmd)
    {
        this.command = cmd;
    }

    public String getCommandIndex()
    {
        return (this.commandIndex);
    }

    public void setCommandIndex(String ci)
    {
        this.commandIndex = ci;
    }

    /**
     * Return the results.
     */
    public String getResults()
    {
        return (this.results);
    }

    /**
     * Set the results.
     *
     * @param tm The new results
     */
    public void setResults(String res)
    {
        this.results = res;
    }

    // --------------------------------------------------------- Public Methods


    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.routerManufacturer   = null;
        this.fromToAutNumSelect  = null;
        this.rtrOneIp            = null;
        this.p_type              = null;
        this.toFromAutNumSelect  = null;
        this.rtrTwoIp            = null;
/*
        this.key            = "";
        this.type           = null;
        this.inv            = null;
        this.source         = null;
        this.template       = null;
        this.command        = null;
        this.commandIndex   = null;
        this.results        = null;
*/
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((tier == null) || (tier.length() < 1))
        {
            errors.add("tier", new ActionError("error.tier.required"));
        }

        if ((tiermaint == null) || (tiermaint.length() < 1))
        {
            errors.add("tiermaint", new ActionError("error.tiermaint.required"));
        }
*/
        return errors;
    }
}
