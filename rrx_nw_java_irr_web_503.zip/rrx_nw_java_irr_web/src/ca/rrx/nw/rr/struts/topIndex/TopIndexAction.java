package ca.rrx.nw.rr.struts.topIndex;

import ca.rrx.nw.rr.Constants;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


import java.lang.reflect.InvocationTargetException;
import org.apache.commons.beanutils.PropertyUtils;
import java.beans.PropertyDescriptor;

import ca.rrx.nw.rr.util.Debug;

public final class TopIndexAction extends Action
{
         
    public ActionForward perform(ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException
    {

        HttpSession session  = request.getSession();
        
        TopIndexForm operatorForm = ((TopIndexForm) form);
        TopIndexForm topIndexForm;
        topIndexForm = (TopIndexForm)session.getAttribute("topIndexForm");
        


        
        Locale locale        = (Locale)session.getAttribute("language");

       
       String languageSelected = request.getParameter("languageSelected");

        
         if  (languageSelected != null)
        {
            if(request.getParameter("languageSelected") != null)
            {
                if(request.getParameter("languageSelected").equals("EN"))
                {
                    locale = new Locale("en", "CA");
                    session.setAttribute("userLocale",locale);
                }
                else if(request.getParameter("languageSelected").equals("FR"))
                {
                    locale = new Locale("fr", "CA");
                    session.setAttribute("userLocale",locale);
                }
                topIndexForm = (TopIndexForm) session.getAttribute("topIndexForm");
                topIndexForm.setLang(request.getParameter("languageSelected"));
            }
             return (mapping.findForward("main"));
        }       
        
        
        
        return (mapping.findForward("main"));
        

    }
    
    private void copyNotNullObjectProperties(Object toObject, Object fromObject)
    throws IOException, ServletException {
        try {
            if (toObject == null)
                throw new IllegalArgumentException
                ("No destination bean specified");
            if (fromObject == null)
                throw new IllegalArgumentException("No origin bean specified");
            
            PropertyDescriptor fromObjectDescriptors[] = PropertyUtils.getPropertyDescriptors(fromObject);
            for (int i = 0; i < fromObjectDescriptors.length; i++) {

                String name = fromObjectDescriptors[i].getName();



                if (PropertyUtils.getPropertyDescriptor(toObject, name) != null) {
                    Object value = PropertyUtils.getSimpleProperty(fromObject, name);

                Debug.print("TopIndexAction: name=" + name);
                //Debug.println(" [" + value + "]");

                    try {
                        if (value != null) PropertyUtils.setSimpleProperty(toObject, name, value);
                    } catch (NoSuchMethodException e) {
                        ;   // Skip non-matching property
                    }
                }
            }
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t == null)
                t = e;
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        } catch (Throwable t) {
            servlet.log("ServerAction:copyObjectProperties ", t);
            throw new ServletException("ServerAction:copyObjectProperties ", t);
        }
    }
}