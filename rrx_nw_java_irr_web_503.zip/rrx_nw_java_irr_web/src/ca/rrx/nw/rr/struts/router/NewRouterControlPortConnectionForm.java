package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class NewRouterControlPortConnectionForm extends ActionForm
{
    
      // --------------------------------------------------- Instance Variables

   
    protected List   routerProfileNames;

   protected String routerProfileName;
    protected List   controlConnectionNames;
  
    private Object controlConnectionId;
    private Object routerProfileId;
    private String controlConnectionName;
    private String controlConnectionNumber;
    private String timeStored;
    private String connectionType;
    private String connectionParameter1;
    private String connectionParameter2;
    private String typeConfigPath;
    private String executablePath;
    private String loginName;
    private String password;
    private String connectionServer;
    private String connectionServerPath;
    private String targetServerPath;
    private String remarks;
    

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public List getControlConnectionNames(){
        return controlConnectionNames;
    }
    
    public void setControlConnectionNames(List controlConnectionNames) {
        this. controlConnectionNames = controlConnectionNames;
    }
    //-----------------
    
    public Object getControlConnectionId() {
        return controlConnectionId;
    }
    
    public void setControlConnectionId(Object controlConnectionId) {
        this. controlConnectionId = controlConnectionId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getControlConnectionName() {
        return controlConnectionName;
    }
    
    public void setControlConnectionName(String controlConnectionName) {
        this. controlConnectionName = controlConnectionName;
    }

    public String getControlConnectionNumber() {
        return controlConnectionNumber;
    }
    
    public void setControlConnectionNumber(String controlConnectionNumber) {
        this.controlConnectionNumber = controlConnectionNumber;
    }

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }

    public String getConnectionType() {
        return connectionType;
    }
    
    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getConnectionParameter1() {
        return connectionParameter1;
    }

    public void setConnectionParameter1(String connectionParameter1) {
        this.connectionParameter1 = connectionParameter1;
    }

    public String getConnectionParameter2() {
        return connectionParameter2;
    }

    public void setConnectionParameter2(String connectionParameter2) {
        this.connectionParameter2 = connectionParameter2;
    }

    public String getTypeConfigPath() {
        return typeConfigPath;
    }

    public void setTypeConfigPath(String typeConfigPath) {
        this.typeConfigPath = typeConfigPath;
    }

    public String getExecutablePath(){
        return executablePath;
    }
    
    public void setExecutablePath(String executablePath) {
        this.executablePath = executablePath;
    }
    
    public String getLoginName(){
        return loginName;
    }
    
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getConnectionServer(){
        return connectionServer;
    }
    
    public void setConnectionServer(String connectionServer) {
        this.connectionServer = connectionServer;
    }
    
    public String getConnectionServerPath(){
        return connectionServerPath;
    }
    
    public void setConnectionServerPath(String connectionServerPath) {
        this.connectionServerPath = connectionServerPath;
    }
    
    public String getTargetServerPath(){
        return targetServerPath;
    }
    
    public void setTargetServerPath(String targetServerPath) {
        this.targetServerPath = targetServerPath;
    }

    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

   

  // --------------------------------------------------------- Public Methods
    
    /**
     * RESET all properties to their default values.
     *

    */

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

      	this.controlConnectionId      	=  null;
	
       	this.routerProfileId    	=  null;
       	this.controlConnectionName    	=  null;
       	this.controlConnectionNumber  	=  null;
       	this.timeStored         	=  null;
       	this.connectionType           	=  null;
       	this.connectionParameter1	=  null;
    	this.connectionParameter2	=  null;

    	this.typeConfigPath		=  null;

    	this.executablePath		=  null;

    	this.loginName			=  null;

    	this.password			=  null;

    	this.connectionServer		=  null;
        this.connectionServerPath	=  null;
        this.targetServerPath		=  null;
    	this.remarks			=  null;
      	

   }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterControlPortConnectionNewForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterControlPortConnectionNewForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterControlPortConnectionNewForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterControlPortConnectionNewForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterControlPortConnectionNewForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterControlPortConnectionNewForm error: " + pce);
        }
        return null;
    }
}