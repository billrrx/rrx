package ca.rrx.nw.rr.struts.aQuery;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class AdvancedQueryEditForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    private String rpslEdit;
    private String rpslToSubmit;
    private String command;
    private String results;

    {
        rpslToSubmit = null;
        rpslEdit = null;
        command = null;
        results = null;
    }

    // ----------------------------------------------------------- Properties

    public String getRpslEdit()
    {
        return (this.rpslEdit);
    }

    public void setRpslEdit(String r)
    {
        this.rpslEdit = r;
    }


    public String getRpslToSubmit()
    {
        return (this.rpslToSubmit);
    }

    public void setRpslToSubmit(String r)
    {
        this.rpslToSubmit = r;
    }

    /**
     * Return the results.
     */
    public String getResults()
    {
        return (this.results);
    }

    /**
     * Set the results.
     *
     * @param tm The new results
     */
    public void setResults(String res)
    {
        this.results = res;
    }

    /**
     * Return the generated command.
     */
    public String getCommand()
    {
        return (this.command);
    }

    /**
     * Set the command.
     *
     * @param tm The new comand
     */
    public void setCommand(String cmd)
    {
        this.command = cmd;
    }


    // --------------------------------------------------------- Public Methods


    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.rpslEdit = null;
        this.results = null;
        this.command  = null;
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */

    /*
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();

        if ((tier == null) || (tier.length() < 1))
        {
            errors.add("tier", new ActionError("error.tier.required"));
        }

        if ((tiermaint == null) || (tiermaint.length() < 1))
        {
            errors.add("tiermaint", new ActionError("error.tiermaint.required"));
        }

        return errors;
    }
    */
}