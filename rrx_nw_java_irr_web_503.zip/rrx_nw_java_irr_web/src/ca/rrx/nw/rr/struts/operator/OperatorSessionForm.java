
package ca.rrx.nw.rr.struts.operator;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;

import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;
import ca.rrx.nw.rr.control.web.ServerWebImpl;

import java.util.Locale;
import java.util.*;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

public final class OperatorSessionForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List sessionProfileNames;
    
    protected List primaryServerProfileNames;
    protected List secondaryServerProfileNames;
   
    protected String primaryClassName;
    protected String primaryInverseAttributeName;
    protected String primaryFilterExpression;
    protected String primaryFilterExpressionText;
    
    protected String secondaryClassName;
    protected String secondaryInverseAttributeName;
    protected String secondaryFilterExpression;
    protected String secondaryFilterExpressionText;
    
    protected Object sessionProfileId;
    protected Object operatorId;
    protected String maintainerCode;
    protected String maintainerCodes;
    protected String nicHandle;
    protected String sessionProfileName;
    protected Object primaryServerProfileId;
    protected Object secondaryServerProfileId;
    protected String relativeConfigPath;
    protected String remarks;
    
    protected String primaryServerProfileName;
    protected String secondaryServerProfileName;

    // ----------------------------------------------------------- Properties

    public List getSessionProfileNames(){
        return sessionProfileNames;
    }
    
    public void setSessionProfileNames(List sessionProfileNames) {
        this. sessionProfileNames = sessionProfileNames;
    }
    
    //-------------
    public List getPrimaryServerProfileNames(){
        return primaryServerProfileNames;
    }
    
  
    public void setPrimaryServerProfileNames(List primaryServerProfileNames) {
        this. primaryServerProfileNames = new ArrayList();
        this. primaryServerProfileNames.addAll(primaryServerProfileNames);
    }
    
    public List getSecondaryServerProfileNames(){
        return secondaryServerProfileNames;
    }
    
    
    public void setSecondaryServerProfileNames(List secondaryServerProfileNames) {
        this. secondaryServerProfileNames = new ArrayList();
        this. secondaryServerProfileNames.addAll(secondaryServerProfileNames);
    }
    

    //-----------------
    public String getPrimaryServerProfileName(){
        return primaryServerProfileName;
    }
    
    public void setPrimaryServerProfileName(String primaryServerProfileName) {
        this. primaryServerProfileName = primaryServerProfileName;
    }
    
    public String getSecondaryServerProfileName(){
        return secondaryServerProfileName;
    }
    
    public void setSecondaryServerProfileName(String secondaryServerProfileName) {
        this. secondaryServerProfileName = secondaryServerProfileName;
    }
    
    //-----------------
    
    public String getPrimaryClassName() {
        if (primaryClassName == null) return("route");
        return primaryClassName;
    }
    
    public void setPrimaryClassName(String primaryClassName) {
        this. primaryClassName = primaryClassName;
    }
    
    public String getPrimaryInverseAttributeName() {
        if (primaryInverseAttributeName == null) return("member-of");
        return primaryInverseAttributeName;
    }
    
    public void setPrimaryInverseAttributeName(String primaryInverseAttributeName) {
        this. primaryInverseAttributeName = primaryInverseAttributeName;
    }
    
    public String getPrimaryFilterExpression() {
        return primaryFilterExpression;
    }
    
    public void setPrimaryFilterExpression(String primaryFilterExpression) {
        this. primaryFilterExpression = primaryFilterExpression;
    }
    
    public String getPrimaryFilterExpressionText() {
        return primaryFilterExpressionText;
    }
    
    public void setPrimaryFilterExpressionText(String primaryFilterExpressionText) {
        this. primaryFilterExpressionText = primaryFilterExpressionText;
    }
    
    //-----------------
    
    public String getSecondaryClassName() {
        if (secondaryClassName == null) return("route");
        return secondaryClassName;
    }
    
    public void setSecondaryClassName(String secondaryClassName) {
        this. secondaryClassName = secondaryClassName;
    }
    
    public String getSecondaryInverseAttributeName() {
        if (secondaryInverseAttributeName == null) return("member-of");
        return secondaryInverseAttributeName;
    }
    
    public void setSecondaryInverseAttributeName(String secondaryInverseAttributeName) {
        this. secondaryInverseAttributeName = secondaryInverseAttributeName;
    }
    
    public String getSecondaryFilterExpression() {
        return secondaryFilterExpression;
    }
    
    public void setSecondaryFilterExpression(String secondaryFilterExpression) {
        this. secondaryFilterExpression = secondaryFilterExpression;
    }
    
    public String getSecondaryFilterExpressionText() {
        return secondaryFilterExpressionText;
    }
    
    public void setSecondaryFilterExpressionText(String secondaryFilterExpressionText) {
        this. secondaryFilterExpressionText = secondaryFilterExpressionText;
    }
    //-----------------
    
    public Object getSessionProfileId() {
        return sessionProfileId;
    }
    
    public void setSessionProfileId(Object sessionProfileId) {
        this. sessionProfileId = sessionProfileId;

    }
    
    public Object getOperatorId() {
        return operatorId;
    }
    
    public void setOperatorId(Object operatorId) {
        this.operatorId = operatorId;
    }
        
    public String getRelativeConfigPath() {
        return relativeConfigPath;
    }
    
    public void setRelativeConfigPath(String relativeConfigPath) {
        this.relativeConfigPath = relativeConfigPath;
    }
    public String getMaintainerCode() {
        return maintainerCode;
    }
    
    public void setMaintainerCode(String maintainerCode) {
        this. maintainerCode = maintainerCode;
    }
    
    public String getMaintainerCodes() {
        return maintainerCodes;
    }
    
    public void setMaintainerCodes(String maintainerCodes) {
        this. maintainerCodes = maintainerCodes;
    }
    
    public String getNicHandle() {
        return nicHandle;
    }
    
    public void setNicHandle(String nicHandle) {
        this. nicHandle = nicHandle;
    }
    
    public String getSessionProfileName() {
        return sessionProfileName;
    }
    
    public void setSessionProfileName(String sessionProfileName) {
        this. sessionProfileName = sessionProfileName;
    }
    
    public Object getPrimaryServerProfileId() {
        return primaryServerProfileId;
    }
    
    public void setPrimaryServerProfileId(Object primaryServerProfileId) {
        this. primaryServerProfileId = primaryServerProfileId;
    }
    
    public Object getSecondaryServerProfileId() {
        return secondaryServerProfileId;
    }
    
    public void setSecondaryServerProfileId(Object secondaryServerProfileId) {
        this. secondaryServerProfileId = secondaryServerProfileId;
    }
    
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((firstName == null) || (firstName.length() < 1))
        {
            errors.add("firstName", new ActionError("error.firstName.required"));
        }

        if ((lastName == null) || (lastName.length() < 1))
        {
            errors.add("lastName", new ActionError("error.lastName.required"));
        }


       if ((streetName1 == null) || (streetName1.length() < 1))
        {
            errors.add("streetName1", new ActionError("error.streetName1.required"));
        }

        if ((city == null) || (city.length() < 1))
        {
            errors.add("city", new ActionError("error.city.required"));
        }

        if ((stateProvince == null) || (stateProvince.length() < 1))
        {
            errors.add("stateProvince", new ActionError("error.stateProvince.required"));
        }

        if ((postalCode == null) || (postalCode.length() < 1))
        {
            errors.add("postalCode", new ActionError("error.postalCode.required"));
        }

        if ((country == null) || (country.length() < 1))
        {
            errors.add("country", new ActionError("error.country.required"));
        }

        if ((telephone == null) || (telephone.length() < 1))
        {
            errors.add("telephone", new ActionError("error.telephone.required"));
        }

        if ((defaultSession == null) || (defaultSession.length() < 1))
        {
            errors.add("defaultSession", new ActionError("error.defaultSession.required"));
        }
        
        if ((thisSession == null) || (thisSession.length() < 1))
        {
            errors.add("thisSession", new ActionError("error.thisSession.required"));
        }

       if ((password == null) || (password.length() < 1))
        {
            errors.add("password", new ActionError("error.password.required"));
        }
        
        if ((email == null) || (email.length() < 1))
        {
            errors.add("email", new ActionError("error.email.required"));
        }
        
        if ((languageSelected == null) || (languageSelected.length() < 1))
        {
            errors.add("languageSelected", new ActionError("error.languageSelected.required"));
        }
        
        if ((language == null) || (language.length() < 1))
        {
            errors.add("language", new ActionError("error.language.required"));
        }
        
        if ((rpslPerson == null) || (rpslPerson.length() < 1))
        {
            errors.add("rpslPerson", new ActionError("error.rpslPerson.required"));
        }
        
      */
        return errors;
    }
}