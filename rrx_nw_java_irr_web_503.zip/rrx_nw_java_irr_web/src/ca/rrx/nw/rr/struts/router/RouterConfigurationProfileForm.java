package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.List;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

public final class RouterConfigurationProfileForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List routerProfileNames;
    protected List configurationTimeStamps;
  
    protected String routerProfileName;
    protected String configurationTimeStamp;
    protected String currentConfigRebuild;
    private   String currentTemplate;    
          
    private Object routerConfigurationId;
    private Object routerProfileId;
    private String timeStored;
    private String revision;
    private String commandLine;
    private String commandIndex;
    private String pointerType;
    private String filePointer;
    private String remarks;

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getConfigurationTimeStamps(){
        return configurationTimeStamps;
    }
    
    public void setConfigurationTimeStamps(List configurationTimeStamps) {
        this. configurationTimeStamps = configurationTimeStamps;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }

    public String getConfigurationTimeStamp() {
        return configurationTimeStamp;
    }
    
    public void setConfigurationTimeStamp(String configurationTimeStamp) {
        this. configurationTimeStamp = configurationTimeStamp;
    }
     
    public String getCurrentTemplate() {
        return currentTemplate;
    }
    
    public void setCurrentTemplate(String currentTemplate) {
        this. currentTemplate = currentTemplate;
    }    
    
    public Object getRouterConfigurationId() {
        return routerConfigurationId;
    }
    
    public void setRouterConfigurationId(Object routerConfigurationId) {
        this. routerConfigurationId = routerConfigurationId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }
    
    public String getRevision() {
        return revision;
    }
    
    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getCommandLine() {
        return commandLine;
    }

    public void setCommandLine(String commandLine) {
        this.commandLine = commandLine;
    }

    public String getCommandIndex() {
        return commandIndex;
    }

    public void setCommandIndex(String commandIndex) {
        this.commandIndex = commandIndex;
    }

    public String getPointerType() {
        return pointerType;
    }
    
    public void setPointerType(String pointerType) {
        this. pointerType = pointerType;
    }
    
    public String getFilePointer() {
        return filePointer;
    }
    
    public void setFilePointer(String filePointer) {
        this.filePointer = filePointer;
    }
    
 
    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }

      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterForm error: " + pce);
        }
        return null;
    }
}