package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;
import ca.rrx.nw.rr.util.Debug;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.List;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;


     
public final class UclpProfileForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List   routerProfileNames;

    protected String routerProfileName;
    protected String transitPortName;
    
    protected List   transitPortNames;
    protected List   controlPortNames;
    protected List   uclpProfileNames;

    private Object uclpProfileId;
    private Object routerProfileId;
    private Object portId;
    private String portType;
    private String uclpProfileName;
    private String uclpConfig;
    private String descr;
    private String memberOf;
    private String remarks;
    private String adminC;
    private String techC;
    private String notify;
    private String mntBy;
    private String changed;
    private String source;
    
   
    protected String rpslToSubmit;

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getTransitPortNames(){
        return transitPortNames;
    }
    
    public void setTransitPortNames(List transitPortNames) {
        this. transitPortNames = transitPortNames;
    }
    
    public List getUclpProfileNames(){
        return uclpProfileNames;
    }
    
    public void setUclpProfileNames(List uclpProfileNames) {
        this. uclpProfileNames = uclpProfileNames;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }

    public String getTransitPortName() {
        return transitPortName;
    }
    
    public void setTransitPortName(String transitPortName) {
        this. transitPortName = transitPortName;
    }
//----------------  
    
    public Object getUclpProfileId() {
        return uclpProfileId;
    }
    
    public void setUclpProfileId(Object uclpProfileId) {
        this. uclpProfileId = uclpProfileId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public Object getPortId() {
        return portId;
    }
    
    public void setPortId(Object portId) {
        this.portId = portId;
    }
    
    public String getPortType() {
        return portType;
    }
    
    public void setPortType(String portType) {
        this. portType = portType;
    }
    
    public String getUclpProfileName() {
        return uclpProfileName;
    }
    
    public void setUclpProfileName(String uclpProfileName) {
        this. uclpProfileName = uclpProfileName;
    }

    public String getUclpConfig() {
        return uclpConfig;
    }
    
    public void setUclpConfig(String uclpConfig) {
        this.uclpConfig = uclpConfig;
    }

    public String getDescr() {
        return descr;
    }
    
    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getMemberOf() {
        return memberOf;
    }
    
    public void setMemberOf(String memberOf) {
        this.memberOf = memberOf;
    }

    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String getAdminC(){
        return adminC;
    }
    
    public void setAdminC(String adminC) {
        this.adminC = adminC;
    }
    
    public String getTechC(){
        return techC;
    }
    
    public void setTechC(String techC) {
        this.techC = techC;
    }
    
    public String getNotify(){
        return notify;
    }
    
    public void setNotify(String notify) {
        this.notify = notify;
    }
    
    public String getMntBy(){
        return mntBy;
    }
    
    public void setMntBy(String mntBy) {
        this.mntBy = mntBy;
    }
    
    public String getChanged(){
        return changed;
    }
    
    public void setChanged(String changed) {
        this.changed = changed;
    }
    
    public String getSource() {
        return source;
    }
    
    public void setSource(String source) {
        this.source = source;
    }

//----------------    
    
    
    public String getRpslToSubmit(){
        return rpslToSubmit;
    }
            
    public void setRpslToSubmit(String rpslToSubmit){
        this.rpslToSubmit = rpslToSubmit;
    }   

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("UclpProfileForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("UclpProfileForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("UclpProfileForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("UclpProfileForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("UclpProfileForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("UclpProfileForm error: " + pce);
        }
        return null;
    }
}