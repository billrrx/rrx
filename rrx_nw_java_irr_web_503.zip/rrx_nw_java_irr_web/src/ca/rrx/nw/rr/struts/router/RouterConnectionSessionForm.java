package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;

public final class RouterConnectionSessionForm extends ActionForm
{
    protected List routerProfileNames;

    protected String routerProfileName;
    
    
    protected List controlPortNames;

  
    private Object controlPortId;
    private Object routerProfileId;
    private String controlPortName;
    private String controlPortNumber;
    private String disabled;
    private String circuit;
    private String designatedIpv4;
    private String designatedIpv4MaskLength;
    private String transportProtocol;
    private Object uclpProfileId;
    private Object ipv6ProfileId;
    private Object connectionProfileId;
      
    protected List controlConnectionNames;
  
    private Object controlConnectionId;
    private String controlConnectionName;
    private String controlConnectionNumber;
    private String connectionType;
    private String connectionParameter1;
    private String connectionParameter2;
    private String typeConfigPath;
    private String executablePath;
    private String loginName;
    private String password;
    private String connectionServer;
    private String connectionServerPath;
    private String targetServerPath;
     
     
    // ----------------------------------------------------------- Properties

 
    
    public List getControlPortNames(){
        return controlPortNames;
    }
    
    public void setControlPortNames(List controlPortNames) {
        this. controlPortNames = controlPortNames;
    }
    
  
//----------------  
    
    public Object getControlPortId() {
        return controlPortId;
    }
    
    public void setControlPortId(Object controlPortId) {
        this. controlPortId = controlPortId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getControlPortName() {
        return controlPortName;
    }
    
    public void setControlPortName(String controlPortName) {
        this. controlPortName = controlPortName;
    }

    public String getControlPortNumber() {
        return controlPortNumber;
    }
    
    public void setControlPortNumber(String controlPortNumber) {
        this.controlPortNumber = controlPortNumber;
    }

    public String getDisabled() {
        return disabled;
    }
    
    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public String getDesignatedIpv4() {
        return designatedIpv4;
    }

    public String getCircuit() {
        return circuit;
    }
    
    public void setCircuit(String circuit) {
        this.circuit = circuit;
    }    
    
    public void setDesignatedIpv4(String designatedIpv4) {
        this.designatedIpv4 = designatedIpv4;
    }

    public String getDesignatedIpv4MaskLength() {
        return designatedIpv4MaskLength;
    }

    public void setDesignatedIpv4MaskLength(String designatedIpv4MaskLength) {
        this.designatedIpv4MaskLength = designatedIpv4MaskLength;
    }

    public String getTransportProtocol(){
        return transportProtocol;
    }
    
    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }
    
 
    public Object getUclpProfileId(){
        return uclpProfileId;
    }
    
    public void setUclpProfileId(Object uclpProfileId) {
        this.uclpProfileId = uclpProfileId;
    }
    
   
    public Object getIpv6ProfileId(){
        return ipv6ProfileId;
    }
    
    public void setIpv6ProfileId(Object ipv6ProfileId) {
        this.ipv6ProfileId = ipv6ProfileId;
    }
    
    public Object getConnectionProfileId() {
        return connectionProfileId;
    }
    
    public void setConnectionProfileId(Object connectionProfileId) {
        this.connectionProfileId = connectionProfileId;
    }
    
 

//----------------    


    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }
    
    public List getControlConnectionNames(){
        return controlConnectionNames;
    }
    
    public void setControlConnectionNames(List controlConnectionNames) {
        this. controlConnectionNames = controlConnectionNames;
    }
    //-----------------
    
    public Object getControlConnectionId() {
        return controlConnectionId;
    }
    
    public void setControlConnectionId(Object controlConnectionId) {
        this. controlConnectionId = controlConnectionId;
    }
       
    public String getControlConnectionName() {
        return controlConnectionName;
    }
    
    public void setControlConnectionName(String controlConnectionName) {
        this. controlConnectionName = controlConnectionName;
    }

    public String getControlConnectionNumber() {
        return controlConnectionNumber;
    }
    
    public void setControlConnectionNumber(String controlConnectionNumber) {
        this.controlConnectionNumber = controlConnectionNumber;
    }


    public String getConnectionType() {
        return connectionType;
    }
    
    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getConnectionParameter1() {
        return connectionParameter1;
    }

    public void setConnectionParameter1(String connectionParameter1) {
        this.connectionParameter1 = connectionParameter1;
    }

    public String getConnectionParameter2() {
        return connectionParameter2;
    }

    public void setConnectionParameter2(String connectionParameter2) {
        this.connectionParameter2 = connectionParameter2;
    }

    public String getTypeConfigPath() {
        return typeConfigPath;
    }

    public void setTypeConfigPath(String typeConfigPath) {
        this.typeConfigPath = typeConfigPath;
    }

    public String getExecutablePath(){
        return executablePath;
    }
    
    public void setExecutablePath(String executablePath) {
        this.executablePath = executablePath;
    }
    
    public String getLoginName(){
        return loginName;
    }
    
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getConnectionServer(){
        return connectionServer;
    }
    
    public void setConnectionServer(String connectionServer) {
        this.connectionServer = connectionServer;
    }
    
    public String getConnectionServerPath(){
        return connectionServerPath;
    }
    
    public void setConnectionServerPath(String connectionServerPath) {
        this.connectionServerPath = connectionServerPath;
    }
    
    public String getTargetServerPath(){
        return targetServerPath;
    }
    
    public void setTargetServerPath(String targetServerPath) {
        this.targetServerPath = targetServerPath;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

    }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterControlPortConnectionProfileForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterControlPortConnectionProfileForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterControlPortConnectionProfileForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterControlPortConnectionProfileForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterControlPortConnectionProfileForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterControlPortConnectionProfileForm error: " + pce);
        }
        return null;
    }
}