package ca.rrx.nw.rr.struts.policy;

import ca.rrx.nw.rr.Constants;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;


import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;



import ca.rrx.nw.rr.control.web.OperatorWebImpl;
import ca.rrx.nw.rr.model.operator.model.OperatorModel;
import ca.rrx.nw.rr.model.operator.model.OperatorSessions;
import ca.rrx.nw.rr.model.operator.model.OperatorSession;
import ca.rrx.nw.rr.model.operator.model.OperatorInformation;
import ca.rrx.nw.rr.control.web.ServerWebImpl;
import ca.rrx.nw.rr.model.server.model.ServerModel;
import ca.rrx.nw.rr.model.server.model.Servers;
import ca.rrx.nw.rr.model.server.model.Server;




public final class PolicySubmitConfirmationAction extends Action
{
    /**
     * Update command if edits are to be submitted to IRR
     */
    private String command;

//    private String filepath = "/usr/local/jakarta-tomcat/webapps/irr1/tmp/";
//    private String relativepath = "/irr1/tmp/";

    private String filepath = Constants.FULL_BASE_DIR + "/tmp/";
    private String filename = null;
    private HttpSession session = null;

    {
        command = null;
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Process the specified HTTP request, and create the corresponding HTTP
     * response (or forward to another web component that will create it).
     * Return an <code>ActionForward</code> instance describing where and how
     * control should be forwarded, or <code>null</code> if the response has
     * already been completed.
     *
     * @param mapping The ActionMapping used to select this instance
     * @param actionForm The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping mapping,
        ActionForm form,
        HttpServletRequest request,
        HttpServletResponse response)
            throws IOException, ServletException
    {
        String results;
        String rpslEdit;
        String commandIndex;













        OperatorWebImpl operatorWebImpl;
        ServerWebImpl serverWebImpl;
        String operatorLoginName;
        String operatorSessionName;
        Object operatorId;
        Object operatorSessionId;
        OperatorModel operatorModel;
        OperatorInformation operatorInformation;
        OperatorSessions operatorSessions;
        OperatorSession currentOperatorSession;
        String currentOperatorSessionName;

        ServerModel serverModel;
        String serverIp;
        String serverUpdatePort;
        OperatorSession currentSession;

        serverModel = null;
        serverIp = "";
        serverUpdatePort = "";

        operatorLoginName   = "";
        operatorSessionName = "";
        operatorId          = null;
        operatorSessionId   = null;

        session    = request.getSession();



       if ((String)session.getAttribute(Constants.USERNAME_KEY) == null)
       {
          return (mapping.findForward("session_timeout"));
       }



        //get the session beans from the session - Bill R
        if (session.getAttribute("operatorWebImpl") != null)
        {
            operatorWebImpl = (OperatorWebImpl) session.getAttribute("operatorWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            operatorWebImpl = new OperatorWebImpl();
        }
        
        if (session.getAttribute("serverWebImpl") != null)
        {
            serverWebImpl = (ServerWebImpl) session.getAttribute("serverWebImpl");
        }
        else
        {
            //diag only - should error out here if there is no bean in the session
            serverWebImpl = new ServerWebImpl();
        }


        if ((String)session.getAttribute("MM_Username") != null) 
        {
            operatorLoginName = (String)session.getAttribute("MM_Username");
        }

        operatorModel               = operatorWebImpl.getModel(operatorLoginName);
        operatorInformation         = operatorModel.getOperatorInformation();
        operatorSessionId           = operatorInformation.getDefaultSessionId();
        operatorSessions            = operatorModel.getOperatorSessions();
        operatorId                  = operatorSessions.getOperatorId();
        currentOperatorSession      = operatorSessions.getOperatorSessionById(operatorSessionId);
        currentOperatorSessionName  = currentOperatorSession.getSessionProfileName();

        operatorSessions    = operatorModel.getOperatorSessions();
        currentSession      = operatorSessions.getOperatorSessionById((Object)session.getValue(Constants.THIS_OPERATOR_SESSION_KEY));

        if(currentSession == null)
        {
            currentSession      = operatorSessions.getOperatorSessionById((Object)operatorInformation.getDefaultSessionId());
        }


        serverModel         = serverWebImpl.getModel(currentSession.getPrimaryServerProfileId());
        serverIp            = serverModel.getServerIpv4();
        serverUpdatePort    = serverModel.getUpdatePort();










        commandIndex    = null;


        session         = request.getSession();

        if(request.getParameter("submitConfirmed") != null)
        {
            commandIndex = "submitConfirmed";
        }
        else if(request.getParameter("submitBack") != null)
        {
            commandIndex = "submitBack";
        }

        // Save form to session
        // session.setAttribute(Constants.REPORT_SUBMIT_CONFIRMATION_KEY, form);
        if (servlet.getDebug() >= 1)
        {
            servlet.log("PolicySubmitConfirmedAction: Policy '" + commandIndex + 
                      "' in session " + session.getId());
        }

        if(commandIndex.equals("submitConfirmed"))
        {
            updateDb();
            return (mapping.findForward("policy_generation_submit_result"));
        }
        else if(commandIndex.equals("submitBack"))
        {
            return (mapping.findForward("policy_generation"));
        }

        // Forward control to URI specified in struts-config.xml
        return (mapping.findForward("policy_generation"));
    }

    public void updateDb()
    {
        String s;
        String cmdupdate;
        String[] results;
        String execresults;
        String newline;
        int randomNumber;
        Integer randInt;
        String cmdIndex;

        PolicyGenerationForm policyGenerationForm;
        PolicySubmitConfirmationForm policySubmitConfirmationForm;

        cmdupdate = null;
        cmdIndex = "";
        s = null;
        randomNumber = (int)(Math.random() * 100000);
        randInt = new Integer(randomNumber);

        filename = "irr" + randInt.toString() + ".txt";

        //$fix this$ - should be from session profile (skip for now, page not currently included)
        /* -- $fix$  (skip for now, page not currently included) *** -- */
        /* -- $fix_hardcoded$ (skip for now, page not currently included) -- */
        cmdupdate = Constants.FULL_BASE_DIR + Constants.IRRUPDATE_SCRIPT1 
                        + " 2>&1 " 
                        + Constants.DEFAULT_SERVER_IP + " " 
                        + Constants.DEFAULT_PORT + " " 
                        + Constants.DEFAULT_SRC_DB + " "
                        + filepath 
                        + filename;

        newline = System.getProperty("line.separator");

        policyGenerationForm = (PolicyGenerationForm) session.getAttribute(Constants.POLICY_GENERATION_KEY);
        policySubmitConfirmationForm = (PolicySubmitConfirmationForm) session.getAttribute(Constants.POLICY_SUBMIT_CONFIRMATION_KEY);

        cmdIndex = policyGenerationForm.getCommandIndex();

        if(cmdIndex.equals("submit2"))
        {
            s = policyGenerationForm.getToFromAutNumTextArea1();
        }
        else if(cmdIndex.equals("submit3"))
        {
            s = policyGenerationForm.getToFromAutNumTextArea2();
        }

        results = split(s);

        try
        {
            File file;
            FileOutputStream fos;
            StringBuffer stringBuffer;

            file = new File(filepath + filename);
            fos = new FileOutputStream(file);

            for(int i = 0 ; i < results.length ; i++)
            {
                String temp = results[i] + newline;
                fos.write(temp.getBytes());
            }

            System.out.print("<br>test data written to temporary file<br> \n");

            stringBuffer = new StringBuffer();


            try

            {
                Process process;
                String srcDb;
                String line;
                int c;
                int exitVal;
                InputStream in;

                InputStream err;
                BufferedReader reader;

                BufferedReader errReader;

                c = 0;
                srcDb = "";

/*
                cmdIndex = ((ReportForm)session.getAttribute("report")).getCommandIndex();

                if(cmdIndex.equals("submit1"))
                {
                    srcDb = Constants.DEFAULT_SRC_DB;
                }
                else if(cmdIndex.equals("submit2"))
                {
                    srcDb = ((ReportForm)session.getAttribute("report")).getMymaints1();
                    srcDb = srcDb.substring(0, srcDb.length() - 4);
                }*/
// search for the following line, use the second column as the source database
//      source:     BCNET-BC

//                srcDb = Constants.DEFAULT_SRC_DB;
//                srcDb = "BCNET-BC-AS";

        /* -- $fix$ (skip for now, page not currently included) *** -- */
        /* -- $fix_hardcoded$ ??? (skip for now, page not currently included)-- */
                // $FIX THIS$ (create a class for parsing through rpsl (skip for now, page not currently included)
                // retrieve the source database
                for(int i = 0; i < results.length;i++)
                {
                    String tempLine;

                    tempLine = results[i];

                    tempLine = tempLine.trim();

                    if(tempLine.length() > 6)
                    {
                        String rpslType = tempLine.substring(0, 7);

                        if(rpslType.equals("source:"))
                        {
                            srcDb = tempLine.substring(8, tempLine.length());
                            srcDb = srcDb.trim();
                        }
                        else
                        {
                            srcDb = "NO_SOURCE_FOUND";
                        }
                    }
                }

        /* -- $fix$ (skip for now, page not currently included) *** -- */
        /* -- $fix_hardcoded$ (skip for now, page not currently included) -- */
                cmdupdate = Constants.FULL_BASE_DIR 
                                + "/bin/update.sh " 
                                + srcDb + " " 
                                + filepath + filename + " " 
                                + Constants.DEFAULT_SERVER_IP + " " 
                                + Constants.DEFAULT_PORT;

                process = Runtime.getRuntime().exec(cmdupdate);

                exitVal = process.waitFor();

                in = process.getInputStream();

                err = process.getErrorStream();
                reader = new BufferedReader(new InputStreamReader(in));

                errReader = new BufferedReader(new InputStreamReader(err));


                if(exitVal == 0)
                {
                    System.out.print("\n RESULTS");

                        do

                        {

                            line = reader.readLine();


                            if(line != null)

                            {

                                stringBuffer.append(line + newline);

                            }

                            else
                            {
                               stringBuffer.append(newline);
                            }

                            c++;

                        }

                        while(line != null);

                 }
                 else
                 {
                    System.out.print("\n ERROR------------------------");

                        do

                        {

                            line = errReader.readLine();


                            if(line != null)

                            {

    //    //                      out.print("\n not-null(" + ((new Integer(exitVal)).toString()) + ")+ \t" + line);
                                stringBuffer.append(line + newline);

                            }

                            else
                            {
    //    //                      out.print("\n null(" + ((new Integer(exitVal)).toString()) + ")" + line);
                                stringBuffer.append(newline);
                            }

                            c++;

                        }

                        while(line != null);
                }

                reader.close();


            }

            catch(IOException e)

            {

                System.out.println("Error");

            }
            catch(InterruptedException iex)
            {
                System.out.println("Error");

            }

            System.out.print("\n\n" + stringBuffer.toString() );

            policyGenerationForm.setCommand(cmdupdate);
            policyGenerationForm.setResults(stringBuffer.toString());
        }
        catch(IOException e)
        {
    //       out.print("<br>error writing to temporary file: " + filepath + filename + "<br>");        
        }
    }


    private String[] split(String s)

    {

        StringBuffer sbTemp;

        ArrayList temp;

        Iterator it;

        int c;



        c = 0;

        temp = new ArrayList();

        sbTemp = new StringBuffer();



        for(int i = 0 ; i < s.length(); i++)

        {

            if(s.charAt(i) != '\n')

            {

                sbTemp.append(s.charAt(i));

            }

            else

            {

                temp.add(sbTemp.toString().trim());

                sbTemp.setLength(0);

            }

        }


        return((String[])temp.toArray(new String[]{}));

    }
}