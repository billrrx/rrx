package ca.rrx.nw.rr.struts.router;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import java.util.Locale;
import java.util.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.net.URL;

import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.InvocationTargetException;

import ca.rrx.nw.rr.util.Debug;


public final class NewRouterTransitPortForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    protected List   routerProfileNames;

   protected String routerProfileName;
    protected List   transitPortNames;

  
    protected Object transitPortId;
    protected Object routerProfileId;
    protected String transitPortName;
    protected String transitPortNumber;
    protected String timeStored;
    protected String disabled;
    protected String circuit;
    protected String designatedIpv4;
    protected String designatedIpv4MaskLength;
    protected String transportProtocol;
    protected String peerRoutingProtocol;
    protected String peerDesignatedIpv4;
    protected String uclpProfileId;
    protected String peerSupportsUclp;
    protected String ipv6ProfileId;
    protected String peerSupportsIpv6;
    protected String remarks;
    
    protected Boolean peerSupportsIpv6CheckBox;
    protected Boolean peerSupports9kMtuCheckBox;
    
    protected String rpslInetRtr;

    // ----------------------------------------------------------- Properties

    public List getRouterProfileNames(){
        return routerProfileNames;
    }
    
    public void setRouterProfileNames(List routerProfileNames) {
        this. routerProfileNames = routerProfileNames;
    }
    
    public List getTransitPortNames(){
        return transitPortNames;
    }
    
    public void setTransitPortNames(List transitPortNames) {
        this. transitPortNames = transitPortNames;
    }
    
    public String getRouterProfileName() {
        return routerProfileName;
    }
    
    public void setRouterProfileName(String routerProfileName) {
        this. routerProfileName = routerProfileName;
    }

//----------------  
    
    public Object getTransitPortId() {
        return transitPortId;
    }
    
    public void setTransitPortId(Object transitPortId) {
        this. transitPortId = transitPortId;
    }
    
    public Object getRouterProfileId() {
        return routerProfileId;
    }
    
    public void setRouterProfileId(Object routerProfileId) {
        this.routerProfileId = routerProfileId;
    }
    
    public String getTransitPortName() {
        return transitPortName;
    }
    
    public void setTransitPortName(String transitPortName) {
        this. transitPortName = transitPortName;
    }

    public String getTransitPortNumber() {
        return transitPortNumber;
    }
    
    public void setTransitPortNumber(String transitPortNumber) {
        this.transitPortNumber = transitPortNumber;
    }

    public String getTimeStored() {
        return timeStored;
    }
    
    public void setTimeStored(String timeStored) {
        this.timeStored = timeStored;
    }

    public String getDisabled() {
        return disabled;
    }
    
    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public String getDesignatedIpv4() {
        return designatedIpv4;
    }

    public String getCircuit() {
        return circuit;
    }
    
    public void setCircuit(String circuit) {
        this.circuit = circuit;
    }    
    
    public void setDesignatedIpv4(String designatedIpv4) {
        this.designatedIpv4 = designatedIpv4;
    }

    public String getDesignatedIpv4MaskLength() {
        return designatedIpv4MaskLength;
    }

    public void setDesignatedIpv4MaskLength(String designatedIpv4MaskLength) {
        this.designatedIpv4MaskLength = designatedIpv4MaskLength;
    }

    public String getTransportProtocol(){
        return transportProtocol;
    }
    
    public void setTransportProtocol(String transportProtocol) {
        this.transportProtocol = transportProtocol;
    }
    
    public String getPeerRoutingProtocol(){
        return peerRoutingProtocol;
    }
    
    public void setPeerRoutingProtocol(String peerRoutingProtocol) {
        this.peerRoutingProtocol = peerRoutingProtocol;
    }
    
    public String getPeerDesignatedIpv4(){
        return peerDesignatedIpv4;
    }
    
    public void setPeerDesignatedIpv4(String peerDesignatedIpv4) {
        this.peerDesignatedIpv4 = peerDesignatedIpv4;
    }
    
    public String getUclpProfileId(){
        return uclpProfileId;
    }
    
    public void setUclpProfileId(String uclpProfileId) {
        this.uclpProfileId = uclpProfileId;
    }
    
    public String getPeerSupportsUclp(){
        return peerSupportsUclp;
    }
    
    public void setPeerSupportsUclp(String peerSupportsUclp) {
        this.peerSupportsUclp = peerSupportsUclp;
    }
    
    public String getIpv6ProfileId(){
        return ipv6ProfileId;
    }
    
    public void setIpv6ProfileId(String ipv6ProfileId) {
        this.ipv6ProfileId = ipv6ProfileId;
    }
    
    public String getPeerSupportsIpv6(){
        return peerSupportsIpv6;
    }
    
    public void setPeerSupportsIpv6(String peerSupportsIpv6) {
        this.peerSupportsIpv6 = peerSupportsIpv6;
    }
    

    public String getRemarks() {
        return remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

//----------------    
    
    public Boolean getPeerSupportsIpv6CheckBox() {
        return peerSupportsIpv6CheckBox;
    }
    
    public void setPeerSupportsIpv6CheckBox(Boolean peerSupportsIpv6CheckBox) {
        this. peerSupportsIpv6CheckBox = peerSupportsIpv6CheckBox;
    }
    
    public Boolean getPeerSupports9kMtuCheckBox(){
        return peerSupports9kMtuCheckBox;
    }
    
    public void setPeerSupports9kMtuCheckBox(Boolean peerSupports9kMtuCheckBox) {
        this.peerSupports9kMtuCheckBox = peerSupports9kMtuCheckBox;
    }
    
    
    public String getRpslInetRtr(){
        return rpslInetRtr;
    }
            
    public void setRpslInetRtr(String rpslInetRtr){
        this.rpslInetRtr = rpslInetRtr;
    }   


   

  // --------------------------------------------------------- Public Methods
    
    /**
     * RESET all properties to their default values.
     *

    */

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {

      	this.transitPortId      	=  null;
	
       	this.routerProfileId    	=  null;
       	this.transitPortName    	=  null;
       	this.transitPortNumber  	=  null;
       	this.timeStored         	=  new Date().toString();
       	this.disabled           	=  null;
       	this.circuit           		=  null;
    	this.designatedIpv4		=  null;

    	this.designatedIpv4MaskLength	=  null;

    	this.transportProtocol		=  null;

    	this.peerRoutingProtocol	=  null;

    	this.peerDesignatedIpv4		=  null;

    	this.uclpProfileId		=  null;

    	this.peerSupportsUclp		=  null;

    	this.ipv6ProfileId		=  null;

    	this.peerSupportsIpv6		=  null;

    	this.remarks			=  null;

    	this.peerSupportsIpv6CheckBox	=  null;

 	this.rpslInetRtr		=  null;

   }

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
/*
        if ((theName == null) || (theName.length() < 1))
        {
            errors.add("theName", new ActionError("error.theName.required"));
        }


      */
        return errors;
    }
    
    public static Element loadDocument(String location) {
        Document doc = null;
        try {
            URL url = new URL(location);
            InputSource xmlInp = new InputSource(url.openStream());

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder parser = docBuilderFactory.newDocumentBuilder();
            doc = parser.parse(xmlInp);
            Element root = doc.getDocumentElement();
            root.normalize();
            return root;
        } catch (SAXParseException err) {
            //Debug.println ("RouterTransitPortNewForm ** Parsing error" + ", line " +
            //            err.getLineNumber () + ", uri " + err.getSystemId ());
            //Debug.println("RouterTransitPortNewForm error: " + err.getMessage ());
        } catch (SAXException e) {
            //Debug.println("RouterTransitPortNewForm error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            //Debug.println("RouterTransitPortNewForm error: " + mfx);
        } catch (java.io.IOException e) {
            //Debug.println("RouterTransitPortNewForm error: " + e);
        } catch (Exception pce) {
            //Debug.println("RouterTransitPortNewForm error: " + pce);
        }
        return null;
    }
}