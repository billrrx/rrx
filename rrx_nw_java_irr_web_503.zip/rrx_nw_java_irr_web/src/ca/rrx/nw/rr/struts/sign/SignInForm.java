package ca.rrx.nw.rr.struts.sign;

import ca.rrx.nw.rr.Constants;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class SignInForm extends ActionForm
{
    // --------------------------------------------------- Instance Variables

    /**
     * The ORAN ID maintainer.
     */
    private String maintainer = null;
    
    /**
     * The password.
     */
    private String password = null;


    /**
     * The username.
     */
    private String username = null;

    // ----------------------------------------------------------- Properties

    public String getMaintainer()
    {
        return (this.maintainer);
    }

 
    public void setMaintainer(String maintainer)
    {
        this.maintainer = maintainer;
    }
    
    public String getPassword()
    {
        return (this.password);
    }

 
    public void setPassword(String password)
    {
        this.password = password;
    }


    public String getUsername()
    {
        return (this.username);
    }



    public void setUsername(String username) {

        this.username = username;

    }


    // --------------------------------------------------------- Public Methods


    /**
     * RESET all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.password = null;
        this.username = null;
        this.maintainer = null;
    }


    /**
     * VALIDATE the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request)
    {

        ActionErrors errors = new ActionErrors();
/*
        if ((username == null) || (username.length() < 1))
        {
            errors.add("username", new ActionError("error.username.required"));
        }

        if ((password == null) || (password.length() < 1))
        {
            errors.add("password", new ActionError("error.password.required"));
        }
*/
        return errors;

    }


}

