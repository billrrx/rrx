package ca.rrx.nw.rr.taglib.util;

import ca.rrx.nw.rr.model.rpsl.model.RpslObject;
import ca.rrx.nw.rr.model.rpsl.model.RpslAttribute;

import java.lang.StringBuffer;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import java.util.Collection;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Enumeration;

import java.io.IOException;

import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;
import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.ServletRequest;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.BodyContent;
import ca.rrx.nw.rr.Constants;
/**
*
* Removes HTML reserved characters and replaces with &amp; &lt; and &gt;
*
*/
public class CleanHtmlReserveTag extends BodyTagSupport
{
    private ArrayList rpslObjects;
    private int numRpslRoute;
    private String sourceString;
    private String searchPattern;
    private String insideParens;
    private String[] sourceStringArray;
    private StringBuffer stringBuffer;
    private boolean invalidRpsl;
    private boolean htmlformat;    


    public CleanHtmlReserveTag()
    {
        htmlformat = false;
    }
    
    public void setHtmlformat(boolean ab_htmlformat)
    {
        this.htmlformat = ab_htmlformat;
    }
  

    public boolean getHtmlformat()
    {
        return (htmlformat);
    }

    public void init(String s)
    {
        String searchPattern;
        String insideParens;
        Iterator it;

        
        sourceStringArray   = null;
        sourceString        = new String();
        stringBuffer        = new StringBuffer();
        rpslObjects         = new ArrayList(1000);
        numRpslRoute        = 0;
        invalidRpsl         = false;
//        htmlformat= false;        

        stringBuffer.append(s);
        sourceString = new String(stringBuffer);
//        System.out.println("BEFORE SPLIT----------------------------------------------------");
        sourceStringArray = split(sourceString);
//        System.out.println("AFTER SPLIT----------------------------------------------------");



try

{
        if(sourceStringArray.length > 0)
        {
            try
            {
               
                
                for(int i = 0 ; i < sourceStringArray.length ; i++)
                {
                    RE regexpr;
                    boolean matched;
                    String tmp;

           
        searchPattern       = new String("(&)");
                    regexpr         = new RE(searchPattern); // look for any word followed by a ':'
                    matched         = regexpr.match(sourceStringArray[i]);
                    
                    tmp = regexpr.subst(sourceStringArray[i], "&amp;");
                    sourceStringArray[i] = tmp;
                                        
           
        searchPattern       = new String("(<)");
                    regexpr         = new RE(searchPattern); // look for any word followed by a ':'
                    matched         = regexpr.match(sourceStringArray[i]);
                    
                    tmp = regexpr.subst(sourceStringArray[i], "&lt;");
                    sourceStringArray[i] = tmp;

           
        searchPattern       = new String("(>)");
                    regexpr         = new RE(searchPattern); // look for any word followed by a ':'
                    matched         = regexpr.match(sourceStringArray[i]);
                    
                    tmp = regexpr.subst(sourceStringArray[i], "&gt;");
                    sourceStringArray[i] = tmp;

                
//                    if(matched)
//                    {
//                        pageContext.getOut().print("* " + sourceStringArray[i] + "<br > "); 
//                    }
//                    else
//                    {
//                        pageContext.getOut().print(sourceStringArray[i] + "<br > ");                     
//                    }
                }

               
            }
            catch (RESyntaxException e)
            {
                System.out.println("error");
            }
        }
        else
        {
            System.out.println("empty string: cannot parse");
            pageContext.getOut().print("empty string: cannot parse");
        }

 }
catch (IOException e)
  {
//       throw new JspTagException ("Error" + e.toString());
   }

        
    }
 
    
    public int doEndTag() throws JspTagException
    {
        String ls_alert;
        String ls_message;
        Iterator it;

        ls_message = null;
        ls_alert = null;

        try
        {
            BodyContent lbc_bodycurrent = getBodyContent();

            if(lbc_bodycurrent != null)
            {
                ls_message = lbc_bodycurrent.getString();
            }

            this.init(ls_message);



            for(int i = 0 ; i < sourceStringArray.length; i++)
            {
            
               if(htmlformat)
               {
                   pageContext.getOut().print(sourceStringArray[i] + "<br>\n");                                    
               }
               else
               {
                    pageContext.getOut().print(sourceStringArray[i] + "\n");                                    
               }
            }
            
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error" + e.toString());
        }

        return EVAL_PAGE;
    }


    /**
     *
     *
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }
 
 	trimArray(temp);       

        return((String[])temp.toArray(new String[]{}));
    }
    
    private void trimArray(ArrayList t)
    {
    	if(!t.isEmpty())
    	{
    	   if((t.get(0).toString().equals("")) || (t.get(0).toString().equals("\n")))
    	   {  
    	       t.remove(0);
    	   }
    	}
    }
}