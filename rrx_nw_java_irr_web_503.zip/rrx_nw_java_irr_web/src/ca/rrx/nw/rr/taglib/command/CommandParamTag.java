package ca.rrx.nw.rr.taglib.command;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;


//import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletRequest;
//import javax.servlet.jsp.tagext.BodyTagSupport;

public class CommandParamTag extends TagSupport
{
    private String name;
    private String flag;
    private String value;    
    private String type;
    private String delim;
    private boolean trim;

    public CommandParamTag()
    {
        name    = new String("");
        flag    = new String("");
        value   = new String("");
        
        type    = new String("");
        delim   = new String("");
        trim    = false;        
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public void setValue(String ab_value)
    {
        this.value = ab_value;
    }
    
    public void setFlag(String ab_flag)
    {
        this.flag = ab_flag;
    }

    public void setType(String ab_type)
    {
        this.type = ab_type;
    }

    public void setDelim(String ab_delim)
    {
        this.delim = ab_delim;
    }
    
    
    public void setTrim(boolean ab_trim)
    {
        this.trim = ab_trim;
        
    }
    

    public String getName()
    {
        return(this.name);
    }

    public String getValue()
    {
        return (this.value);
    }

    public String getFlag()
    {
        return (this.flag);
    }

    public String getType()
    {
        return (this.type);
    }

    public String getDelim()
    {
        return (this.delim);
    }

    public boolean getTrim()
    {
        return (this.trim);
    }
    
    public int doStartTag() throws JspTagException
    {
        CommandInitTag parentTag;
        ServletRequest lparms;
        Enumeration req_data;
        String tempCommand;
        String tempValue;
        String tempValues[];
	String sp;    //holds a space        

        lparms = pageContext.getRequest();
        req_data = lparms.getParameterNames();
        parentTag = (CommandInitTag)this.findAncestorWithClass(this, CommandInitTag.class);

        tempCommand = parentTag.getCommand();
        tempValue = null;
        tempValues = null;
        //sp  = null;
        
        if(trim)
        {
          sp = new String("");
        }
        else
        {
          sp = new String(" ");        
        }        

        // a single flag
        if(this.getType().equals(""))
        {
            tempValue = lparms.getParameter(name);

            if(tempValue != null)
            {
                tempCommand = tempCommand + sp + flag;
            }
            else
            {

            }
        }

        // a text-input field
        if(this.getType().equals("text"))
        {
            tempValue = lparms.getParameter(name);

            if(tempValue != null)
            {
                tempCommand = tempCommand + sp + tempValue;
            }
            else
            {

            }
        }

        // a single flag followed by a value
        if(this.getType().equals("single"))
        {
            tempValue = lparms.getParameter(name);

            if((tempValue == null) || (tempValue.equals("")))
            {
                //do nothing if the value is null or empty
            }
            else
            {
                tempCommand = tempCommand + sp + flag + sp + tempValue;
            }

        }

        // a single flag followed by a value
        if(this.getType().equals("radio"))
        {
            tempValue = lparms.getParameter(name);

            if(tempValue != null)
            {
                tempCommand = tempCommand + sp + tempValue;
            }
        }
        

        if(this.getType().equals("value"))
        {
            //tempValue = lparms.getParameter(name);

            if(this.value != null)
            {
                tempCommand = tempCommand + sp + value;
            }
        }
                

        // a single flag followed by more than one value
        if(this.getType().equals("multi"))
        {
            tempValues         = lparms.getParameterValues(name);
if(tempValues != null) 
{
            if((tempValues.length == 1) && ((tempValues[0] == null) || (tempValues[0].equals(""))))
            {
            }
            else
            {
                //tempCommand = tempCommand + " " + flag + "[" + tempValues.length + "]";
                tempCommand = tempCommand + sp + flag;

                for(int i = 0 ; i < tempValues.length ; i++)
                {
                    tempCommand += this.getDelim() + tempValues[i];
                }
            }
}
        }

//
	this.setTrim(false);
        parentTag.setCommand(tempCommand);


        try
        {
        
//        pageContext.getOut().print("[" + this.trim + "]<br>");
        
//            pageContext.getOut().print("<br><hr><br>");
//            pageContext.getOut().print("[" + this.name + "]<br>");
//            pageContext.getOut().print("[" + tempValue + "]<br>");
//            pageContext.getOut().print("[ " + tempCommand + " ]<br>");
        }
        catch (Exception e)
        {
            throw new JspTagException ("Error in CommandInitTag" + e.toString());
        }
       
        return SKIP_BODY;
    }
}
