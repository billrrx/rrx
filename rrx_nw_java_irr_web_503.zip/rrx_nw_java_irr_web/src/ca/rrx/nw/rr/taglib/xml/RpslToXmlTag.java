package ca.rrx.nw.rr.taglib.xml;

import ca.rrx.nw.rr.model.rpsl.model.RpslObject;
import ca.rrx.nw.rr.model.rpsl.model.RpslAttribute;

import java.lang.StringBuffer;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.BodyContent;
/**
*  Converts body-text in RPSL to XML.
*
*/
public class RpslToXmlTag extends BodyTagSupport
{
    private ArrayList rpslObjects;
    private int numRpslRoute;
    private String sourceString;
    private String searchPattern;
    private String insideParens;
    private String[] sourceStringArray;
    private StringBuffer stringBuffer;
    private boolean invalidRpsl;
 
    /**
     *
     * @param s string returned by whois3 command (in RPSL format)
     */
    public void init(String s)
    {
        String searchPattern;
        String insideParens;
        Iterator it;

        searchPattern       = new String("(^((\\w)|-)+:+?)");
        sourceStringArray   = null;
        sourceString        = new String();
        stringBuffer        = new StringBuffer();
        rpslObjects         = new ArrayList(1000);
        numRpslRoute        = 0;
        invalidRpsl         = false;

        stringBuffer.append(s);
        sourceString = new String(stringBuffer);
//        System.out.println("BEFORE SPLIT----------------------------------------------------");
        sourceStringArray = split(sourceString);
//        System.out.println("AFTER SPLIT----------------------------------------------------");


/*
//
try
//
{

*/
 

        if(sourceStringArray.length > 0)
        {
            try
            {
                RE regexpr;
                boolean matched;

                regexpr         = new RE(searchPattern); // look for any word followed by a ':'
                matched         = regexpr.match(sourceStringArray[0]);

                // if line starts with a word followed by a ':'
                if(matched)
                {
                    insideParens = regexpr.getParen(1);
//                    System.out.println(insideParens);

                    if(insideParens.equals("Usage:"))
                    {
                        invalidRpsl = true;
//                        System.out.println("invalid object: cannot parse");
//                        pageContext.getOut().print("invalid object: cannot parse [" + sourceStringArray[0] + "]");
                    }
                    else
                    {
                        parseRpslObject(sourceStringArray);
                    }
                }
                else
                {
                    invalidRpsl = true;
//                    System.out.println("invalid object: cannot parse");
                   
//                    pageContext.getOut().print("invalid object: cannot parse [" + sourceStringArray[0] + "]");
                    //do nothing (invalid RPSL objects)
                }
            }
            catch (RESyntaxException e)
            {
                System.out.println("error");
            }
        }
        else
        {
            invalidRpsl = true;
        
//            System.out.println("empty string: cannot parse");
//            pageContext.getOut().print("empty string: cannot parse");
        }
/*
// }
//catch (IOException e)
//  {
//       throw new JspTagException ("Error" + e.toString());
//   }

*/
        
    }

    /**
     *
     * @return
     *
     * @throws
     */
    public int doEndTag() throws JspTagException
    {
        String ls_alert;
        String ls_message;
        Iterator it;

        ls_message = null;
        ls_alert = null;

        try
        {
            BodyContent lbc_bodycurrent = getBodyContent();

            if(lbc_bodycurrent != null)
            {
                ls_message = lbc_bodycurrent.getString();
            }

            this.init(ls_message);

            it = ((Collection)this.getRpslObjects()).iterator();

            // only output xml tags if rpsl was correctly formatted
            if(!invalidRpsl)
            {
                pageContext.getOut().print("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?> \n<RPSLObjects>");

                while(it.hasNext())
                {
                    RpslObject r = (RpslObject)it.next();
                    pageContext.getOut().print(r.toXmlString());
                }

                pageContext.getOut().print("\n</RPSLObjects>"); 
            }
            else
            {
                pageContext.getOut().print("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?> \n<RPSLObjects>");

                pageContext.getOut().print("\n<!-- INVALID RPSL OBJECT -->\n"); 
                
                pageContext.getOut().print("\n</RPSLObjects>"); 
            
//                    pageContext.getOut().print("invalid object: cannot parse ****");
            
            }

        }
        catch (IOException e)
        {
            throw new JspTagException ("Error" + e.toString());
        }

        return EVAL_PAGE;
    }

    /**
    * Returns list of RPSL objects.
    *
    * @return collection of RPSL objects
    */
    public List getRpslObjects()
    {
        return(rpslObjects);
    }

    /**
    * Parses RPSL object results and creates RpslObject and RpslAttribute
    * as needed.
    *
    * @ param 
    */
    private void parseRpslObject(String[] s)
    {
        RpslObject rpslObject;
        RpslAttribute ra;
        String sourceString;
        String searchPattern;
        String insideParens;
        int nextRoute = 0;
        boolean nextObject = false;
        boolean lastObject = false;
        int lineAfterEmptyLine = 0;

        searchPattern = new String("(^((\\w)|-)+:+?)");
        rpslObject = null;
        ra = null;
        nextRoute = 0;

/*
scan through RPSL_Classes.xml
    determine classes and their attributes

scan through RPSL objects
    for first object, determine what type of object
        then scan attributes
    
*/

        for(int lineNumber = 0 ; !lastObject; lineNumber++)
        {
            nextObject = false;

            for(int i = lineNumber; !nextObject ; i++)
            {
                if(i == s.length)
                {
                    lastObject = true;
                    break;
                }

                try
                {
                    RE r;
                    boolean matched;

                    r       = new RE(searchPattern); // look for any word followed by a ':'
                    matched = r.match(s[i]);

                    // if line starts with a word followed by a ':'
                    if(matched)
                    {
                        insideParens = r.getParen(1);

                        lineAfterEmptyLine++;

                        // if this is the first line after an empty one, create a new object
                        if(lineAfterEmptyLine == 1)
                        {
    //                        System.out.println("*" + insideParens + (s[i]).substring(insideParens.length()));

                            rpslObject = new RpslObject(insideParens.substring(0, insideParens.length()-1).trim(),
                                                (s[i]).substring(insideParens.length()).trim() );

                            rpslObjects.add(rpslObject);
                        }
                        else
                        {
    //                        System.out.println("\t" + insideParens + (s[i]).substring(insideParens.length()));

                            ra = new RpslAttribute(insideParens.substring(0, insideParens.length()-1).trim(),
                                    (s[i]).substring(insideParens.length()).trim() );

                            rpslObject.addAttribute(ra);
                        }
                    }
                    else
                    {
                        RE rNextLine;
                        boolean hasCharacters;

                        hasCharacters = false;
                        rNextLine = new RE("\\w+");

                        // if text on the next line, append to attribute
                        hasCharacters = rNextLine.match(s[i]);

                        if(hasCharacters)
                        {
                            ra.appendValue(" " + s[i]);
                        }
                        else
                        {
                            nextObject = true;
                            lineAfterEmptyLine = 0;
                            lineNumber = i;
                        }
                    }
                }
                catch (RESyntaxException e)
                {
                    System.out.println("error");
                }
            }
        }
    }

    /**
     *
     * @param s
     * @returns
     *
     */
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        trimArray(temp);       
 
        
       
/*
//       
try
//       
{
    	     trimArray(temp);       
//
       
    pageContext.getOut().print("<br><hr>");



//       
    
for(int i = 0 ; i < temp.size() ; i++)
//       
    
{      
//                 pageContext.getOut().print(temp.get(i).toString() + "<br>");

//             }
//    
//       
     pageContext.getOut().print("<br><hr>");


//       
}
//       
catch (IOException e)
//       
{
//             System.out.println("Error splitting");
//       
}

*/

        return((String[])temp.toArray(new String[]{}));
    }


    /**
     * Removes leading empty Strings from an ArrayList of String
     * objects.
     *
     * @param t 
     *
     */    
    private void trimArray(ArrayList t)
    {
        int[] idxRemove;
        int count;
        
        idxRemove = new int[100];
        count = 0;
    
        if(!t.isEmpty())
        {              
     
            for(int i = 0 ; i < t.size() ; i++)
            {        
               String s;        
              
     
        
              
     
               s = t.get(i).toString().trim();
               
    	       if(s.length() == 0)
    	       {  
    	           idxRemove[count] = i;
      	           count++;
    	       }
               else
               {
                   break;
               }    	       
            }

            for(int i = count ; i > 0 ; i--)
            {
                  t.remove(0);
            }


    	}
    	
    }
}