package ca.rrx.nw.rr.taglib.command;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Enumeration;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletRequest;

public class CommandExecTag extends TagSupport
{
//    private final int EXECUTE_AND_DISPLAY = 0;
//    private final int DISPLAY_ONLY = 1;
    
    private String name = "";
    private String command = "";
    private String results;
    private String display = "";	
    private boolean completed = false;
    


    public CommandExecTag()
    {
        command = null;
        name = null;
        results = null;
        display = "";
    }

    public void setDisplay(String ab_display)
    {
        this.display = ab_display;
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public void setCommand(String ab_command)
    {
        this.command = ab_command;
    }

    public String getCommand()
    {
        return (command);
    }

    public String getName()
    {
        return (name);
    }

    public String getDisplay()
    {
        return (display);
    }

    public String getResults()
    {
        return (results);
    }

    public int doStartTag() throws JspTagException
    {
        String tmpCmd;
        String submitParam;
        String[] paramValues;
        
        ServletRequest lparms;
        Enumeration req_data;       
        int elemCount;
        String ls_alert;
        String ls_message;
        String ls_data;
        
        ls_alert = "";
        ls_message = "";
        ls_data = "";      
                
        lparms = pageContext.getRequest();
        req_data = lparms.getParameterNames();
        elemCount = 0;

        submitParam       = lparms.getParameter(this.getName());
            
        ls_data = this.getName() + ": " + submitParam; 
            
      
      
      
      
        tmpCmd = (String) pageContext.getAttribute(this.getName());
      
        command = tmpCmd; 
        
        if(submitParam != null &&
            (this.getDisplay().equals("execute_and_display") || this.getDisplay().equals("execute_only") &&
            (!this.getDisplay().equals("display_only")))
          )
        {
            results = exec();
         
	}
	else
	{
            results = ""; //set results to empty string
        }
	             
            pageContext.setAttribute(this.getName() + "_results", this.getResults());
   
            pageContext.getSession().setAttribute(this.getName() + "_results", this.getResults());
//            session.setAttribute(this.getName() + "_results", this.getResults());
   



        try
        {
            if((this.getDisplay().equals("execute_and_display") || 
            	this.getDisplay().equals("display_only")) &&
            	(!this.getDisplay().equals("execute_only")
            	&& (submitParam != null)
            	))
            {
                pageContext.getOut().print(tmpCmd);
//                pageContext.getOut().print("[");
                
//                pageContext.getOut().print(ls_data);
//                pageContext.getOut().print("]");
                
            }
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error in CommandExecTag: " + e.toString());
        }
        
//      }  
      
      
      
       return SKIP_BODY;
      
      
    }

 



    // comment back in when using final whois query

    public String exec()
    {

        StringBuffer stringBuffer = new StringBuffer();
        String newline = System.getProperty("line.separator");

        try
        {
                 
            Process process = Runtime.getRuntime().exec(command);


            InputStream in = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String line;
            int c;
            c = 0;

            do
            {
                line = reader.readLine();

                if(line != null)
                {
                    stringBuffer.append(line + newline);
                }

                c++;
            }
            while(line != null);

            reader.close();
        }
        catch(IOException e)
        {
            System.out.println("Error");
        }

        return(new String(stringBuffer));
    }
}


