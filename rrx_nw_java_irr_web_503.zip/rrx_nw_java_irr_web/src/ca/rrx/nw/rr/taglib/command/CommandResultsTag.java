package ca.rrx.nw.rr.taglib.command;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ArrayList;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletRequest;

public class CommandResultsTag extends TagSupport
{
    private String name;
    private String command;
    private String results;

    private boolean display;
    private boolean htmlformat;

    {
        command = null;
        name = null;
        results = null;
        display = false;
        htmlformat= false;
    }

    public CommandResultsTag()
    {
    }

    public void setDisplay(boolean ab_display)
    {
        this.display = ab_display;
    }

    public void setHtmlformat(boolean ab_htmlformat)
    {
        this.htmlformat = ab_htmlformat;
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public void setCommand(String ab_command)
    {
        this.command = ab_command;
    }

    public String getCommand()
    {
        return (command);
    }

    public String getName()
    {
        return (name);
    }

    public boolean getDislay()
    {
        return (display);
    }

    public boolean getHtmlformat()
    {
        return (htmlformat);
    }

    public String getResults()
    {
        return (results);
    }

    public int doStartTag() throws JspTagException
    {
        String tmpCmd;
        String[] resultLines;

        tmpCmd = (String)pageContext.getSession().getAttribute(this.getName() + "_results");
       
        resultLines = split(tmpCmd);

        try
        {
//            pageContext.getOut().print("htmlformat:" + htmlformat);

            if(htmlformat)
            {      
                for(int i = 0; i < resultLines.length ; i++)
                {
                    pageContext.getOut().print(resultLines[i] + "<br />");
                }
            }
            else
            {
                for(int i = 0; i < resultLines.length ; i++)
                {
//                    pageContext.getOut().print(resultLines.length);
//                    pageContext.getOut().print(resultLines[i] + "\r\n");
                    pageContext.getOut().print(resultLines[i] + "\n");
                }
//                pageContext.getOut().print(tmpCmd);
            }
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error in CommandResultsTag: " + e.toString());
        }

        return SKIP_BODY;
    }
    
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        return((String[])temp.toArray(new String[]{}));
    }
    
}