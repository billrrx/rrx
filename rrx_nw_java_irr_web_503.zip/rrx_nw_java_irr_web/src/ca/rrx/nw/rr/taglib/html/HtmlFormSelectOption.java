package ca.rrx.nw.rr.taglib.html;

import ca.rrx.nw.rr.Constants;

public class HtmlFormSelectOption
{
    String value;
    String text;

    public HtmlFormSelectOption()
    {
    }

    public HtmlFormSelectOption(String t, String v)
    {
        this.setText(t);
        this.setValue(v);
    }

    public void setValue(String v)
    {
        value = v;
    }

    public void setText(String t)
    {
        text = t;
    }

    public String getValue()
    {
        return(value);
    }

    public String getText()
    {
        return(text);
    }
}