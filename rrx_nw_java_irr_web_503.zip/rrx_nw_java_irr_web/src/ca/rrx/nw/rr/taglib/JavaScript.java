
package ca.rrx.nw.rr.taglib;

public class JavaScript
{
    private String start_script = "<script language=\"JavaScript\">";
    private String end_script = "</script>";
    private String browser_validation = "";

    public JavaScript()
    {
        browser_validation = 
            "var isIE = (navigator.appName == \"Microsoft Internet Explorer\") ? 1 : 0;";

        browser_validation += 
            "var isNS = (navigator.appName == \"Netscape\") ? 1 : 0;";

        browser_validation += 
            "var isNS4 = (navigator.appName == \"Netscape\" && parseInt(navigator.appVersion)  < 5);";
    }

    public String alert(Object aobj_data)
    {
        return (start_script + " alert(\"" + aobj_data.toString() + "\");"
                + end_script);
    }

    public String alert (Object aobj_data, String as_name, String as_element, String as_event)
    {
        String ls_test = as_event.trim().substring(0, 2).toLowerCase();

        if(ls_test.equals("on"))
        {
            as_event = as_event.substring(2, as_event.length());
        }

        String ls_start_alert = start_script + browser_validation;
        String ls_event_alert = "function " + as_name + "(){ alert(\"" + aobj_data.toString() + "\");}";
        String ls_end_alert = end_script;
        String ls_alert = ls_start_alert;

        ls_alert += "if(isIE) " + as_element + ".on" + as_event + " = " + as_name + "; ";
        ls_alert += "if(isNS && !isNS4) " + as_element + ".addEventListener(\""
                + as_event + "\", " + as_name + ", true); ";
        ls_alert += ls_event_alert;
        ls_alert += ls_end_alert;

        return (ls_alert);
    }
}