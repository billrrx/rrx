package ca.rrx.nw.rr.taglib.html;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import ca.rrx.nw.rr.util.Debug;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ArrayList;

import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletRequest;
import ca.rrx.nw.rr.Constants;

public class HtmlSaveTextAreaTag extends TagSupport
{
    private String name;
    private String filename;  
    private String filepath;    

    public HtmlSaveTextAreaTag()
    {
        name = null;
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public String getName()
    {
        return (name);
    }
  

    public int doStartTag() throws JspTagException
    {
        String tmpResults;
        String[] resultLines;
        StringBuffer sb;
        int randomNumber;
        Integer randInt;
        ServletRequest lparms;

        lparms = pageContext.getRequest();
        sb = null;
        sb = new StringBuffer();

        tmpResults = null;
        
        // PROBLEM - this sets up the tmpResults when the tag is inserted,
        // NOT when the input button is pressed. Therefore the new file is written
        // with OLD data (the data in the box when the button was LAST pressed).
        tmpResults = lparms.getParameter(this.getName());
        
        if(tmpResults == null)
        {
            tmpResults = (String)pageContext.getAttribute(this.getName() + "_textarea");
        }
/*               
        if(tmpResults        == null)
        {              
            tmpResults = "line\n" + "line2\n" + this.name + "\ntest\n";
        }        
*/

        randomNumber = (int)(Math.random() * 100000);
        randInt = new Integer(randomNumber);
        
        filename = "irr" + randInt.toString() + ".txt";
        
        if(tmpResults != null)
        {
            resultLines = split(tmpResults);
 
            String tmpResultsTrim;
        
            tmpResultsTrim = tmpResults.trim();
            
            if(tmpResultsTrim.length() > 0)
            {
                writeToFile(resultLines);
            }
        }

/*        
sb.append("<%@ page language=\"java\" contentType=\"text/html\" %>");
sb.append("<%@ taglib uri=\"/WEB-INF/tlds/CommandTaglib.tld\" prefix=\"cmd\" %>");
sb.append("<%@ taglib uri=\"/WEB-INF/tlds/RpslToXmlTag.tld\" prefix=\"rpsl2xml\" %>");
sb.append("<%@ taglib uri=\"/WEB-INF/tlds/CleanHtmlReserveTag.tld\" prefix=\"cht\" %>");
sb.append("<pre>");
sb.append("<cht:apply>");
sb.append("  <%= request.getParameter(\"htmltextarea2\") %>");
sb.append("</cht:apply>");
sb.append("</pre>");

resultLines = split(sb.toString());
        
writeToFile(resultLines);
*/          
    
        try
        {            
            pageContext.getOut().print("<input onClick=\"saveToFile('tmp/" + filename + "')\" type=\"submit\" name=\"SaveToFile\" value=\"Save To File\">");                
        }
        catch (IOException e)
        {
           throw new JspTagException ("Error in HtmlSaveTextAreaTag: " + e.toString());
        }

        return SKIP_BODY;
    }
    
    private void writeToFile(String[] s)
    {

        filepath = Constants.FULL_BASE_DIR + "/tmp/";
        String newline;
        
        newline = System.getProperty("line.separator");
        
        try
        {
            File file = new File(filepath + filename);
            FileOutputStream fos = new FileOutputStream(file);            
            
            for(int i = 0 ; i < s.length ; i++)
            {
                 String temp = s[i] + newline;
                 fos.write(temp.getBytes());                                 
            }
            
           
        }
        catch(IOException e)
        {

        }
        
        finally
        {

        }
    }
    
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }
 
 
        return((String[])temp.toArray(new String[]{}));
    }
    
}
