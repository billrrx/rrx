package ca.rrx.nw.rr.taglib.command;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import ca.rrx.nw.rr.util.Debug;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ArrayList;

import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.ServletRequest;

import ca.rrx.nw.rr.Constants;

public class CommandSaveResultsTag extends TagSupport
{
    private String name;
    private String command;
    private String results;
    private String filename;

    private boolean display;
    private boolean htmlformat;

    {
        command = null;
        name = null;
        results = null;
        filename = null;
        display = false;
        htmlformat= false;
    }



    public CommandSaveResultsTag()
    {
    }

    public void setDisplay(boolean ab_display)
    {
        this.display = ab_display;
    }

    public void setHtmlformat(boolean ab_htmlformat)
    {
        this.htmlformat = ab_htmlformat;
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public void setCommand(String ab_command)
    {
        this.command = ab_command;
    }

    public String getCommand()
    {
        return (command);
    }

    public String getName()
    {
        return (name);
    }

    public boolean getDislay()
    {
        return (display);
    }

    public boolean getHtmlformat()
    {
        return (htmlformat);
    }

    public String getResults()
    {
        return (results);
    }

    public int doStartTag() throws JspTagException
    {
        String tmpResults;
        String tmpResultsTrim;
        String[] resultLines;

//        tmpResults = (String)pageContext.getAttribute(this.getName() + "_results");
//        tmpCmd = (String)pageContext.getSession().getAttribute(this.getName() + "_results");

//        tmpResults = (String)pageContext.getSession().getAttribute(this.getName() + "_results");
        tmpResults = "";

//        tmpResults = (ReportForm)pageContext.getSession().getAttribute(this.getName()).getValue("results");
        if(pageContext.getSession().getAttribute(this.getName()) != null)
        {
            tmpResults = ((ca.rrx.nw.rr.struts.report.ReportForm)pageContext.getSession().getAttribute(this.getName())).getResults();
        }

        if(tmpResults.length() > 0)
        {

            tmpResultsTrim = "";
            resultLines = split(tmpResults);
            tmpResultsTrim = tmpResults.trim();

//tmpResultsTrim = "test";
            try
            {
                if(tmpResultsTrim.length() > 0)
                {
                    writeToFile(resultLines);

                    pageContext.getOut().print("<input onclick=\"saveToFile('" + Constants.RELATIVE_ROOT_DIR + "/tmp/" + filename + "')\" type=\"submit\" value=\"Save To File\">");

//                    pageContext.getOut().print("<br>eeks<br><br>" + tmpResults + "<br><br>");
                }



    //                pageContext.getOut().print("[[[[" + tmpResultsTrim + "]]]]");
    //                for(int i = 0 ; i < resultLines.length ; i++)
    //                {
    //                    pageContext.getOut().print("|||" + resultLines[i] + "|||\n");
    //                }



    //                writeToFile(resultLines);
    //                pageContext.getOut().print("<form>" + "<input onClick=\"saveToFile('tmp/" + filename + "')\" type=\"submit\" name=\"SaveToFile\" value=\"Save To File\">" + "</form>");
                    
                    //pageContext.getOut().print(tmpResultsTrim.length());            

    //            }
    //            else
    //            {
    //                pageContext.getOut().print("<form>" + "<input type=\"submit\" name=\"SaveToFile\" value=\"Save To File\">" + "</form>");            
    //            }
            }
            catch (IOException e)
            {
                throw new JspTagException ("Error in CommandSaveResultsTag: " + e.toString());
            }

        }

        return SKIP_BODY;
    }
    
    private void writeToFile(String[] s)
    {
        int randomNumber;
        Integer randInt;
        String filepath;
        String newline;


        filepath = Constants.FULL_BASE_DIR + "/tmp/";

        newline = System.getProperty("line.separator");

        randomNumber = (int)(Math.random() * 100000);
        randInt = new Integer(randomNumber);
        
        filename = "irr" + randInt.toString() + ".txt";

        try
        {
            File file = new File(filepath + filename);
            FileOutputStream fos = new FileOutputStream(file);
            
            for(int i = 0 ; i < s.length ; i++)
            {
                 String temp;
                 temp = s[i] + newline;
                 fos.write(temp.getBytes());
            }
            

        }
        catch(IOException e)
        {

        }
        
        finally
        {

        }
    }
    
    private String[] split(String s)
    {
        StringBuffer sbTemp;
        ArrayList temp;
        Iterator it;
        int c;

        c = 0;
        temp = new ArrayList();
        sbTemp = new StringBuffer();

        for(int i = 0 ; i < s.length(); i++)
        {
            if(s.charAt(i) != '\n')
            {
                sbTemp.append(s.charAt(i));
            }
            else
            {
                temp.add(sbTemp.toString().trim());
                sbTemp.setLength(0);
            }
        }

        return((String[])temp.toArray(new String[]{}));
    }
    
}
