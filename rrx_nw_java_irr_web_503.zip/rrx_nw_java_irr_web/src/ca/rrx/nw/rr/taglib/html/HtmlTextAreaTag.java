package ca.rrx.nw.rr.taglib.html;

import ca.rrx.nw.rr.model.rpsl.model.RpslObject;
import ca.rrx.nw.rr.model.rpsl.model.RpslAttribute;

import java.lang.StringBuffer;

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

import java.util.Collection;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Enumeration;

import java.io.IOException;

import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;
import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.ServletRequest;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.tagext.BodyContent;
import ca.rrx.nw.rr.Constants;
/**
*
* Custom tag for creating a text area html tag. Combined
* with HtmlSaveTextAreaTag, this provides functionality
* to save text entered into text area to a file on the server.
*
*/
public class HtmlTextAreaTag extends BodyTagSupport
{
    private String name;
    private int cols;
    private int rows;    

    public HtmlTextAreaTag()
    {
        name = null;
        cols = 0;
        rows = 0;
    }
    
    public void setName(String ab_name)
    {
        name = ab_name;
    }
    
    public void setCols(int ab_cols)
    {
        cols = ab_cols;
    }    
    
    public void setRows(int ab_rows)
    {
        rows = ab_rows;
    } 
        
    public String getName()
    {
        return (this.name);
    }
    
    public int getCols()
    {
        return(this.cols);
    }
    
    public int getRows()
    {
        return(this.rows);
    }    

    public void init(String s)
    {
    }
 
/*
    public int doStartTag() throws JspTagException
    {
        try
        {
             pageContext.getOut().print("<textarea name=\"" + this.getName() + "\" cols=\"50 \" rows=\"25 \">");
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error in HtmlTextAreaTag.doStartTag()" + e.toString());
        }


        return EVAL_BODY_INCLUDE;
    }
*/

    public int doEndTag() throws JspTagException
    {
        String ls_alert;
        String ls_message;
        Iterator it;

        ls_message = null;
        ls_alert = null;
        
        try
        {
       
            BodyContent lbc_bodycurrent = getBodyContent();

            if(lbc_bodycurrent != null)
            {
                ls_message = lbc_bodycurrent.getString();
            }

             pageContext.getOut().print("<textarea name=\"" + this.getName() + "\" cols=\"50 \" rows=\"25 \">");                    
             pageContext.getOut().print(ls_message);
             pageContext.getOut().print("</textarea>");

             pageContext.setAttribute(this.getName() + "_textarea", ls_message);

//             pageContext.getOut().print((String)pageContext.getAttribute(this.getName() + "_textarea"));        
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error in HtmlTextAreaTag.doEndTag()" + e.toString());
        }

        return EVAL_PAGE;
    }
}