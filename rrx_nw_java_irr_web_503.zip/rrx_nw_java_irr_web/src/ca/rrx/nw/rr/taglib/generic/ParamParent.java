package ca.rrx.nw.rr.taglib.generic;


public interface ParamParent {
    /**
     * Adds a parameter name-value pair represented by the
     * embedded ParamTag. The value is URL encoded.
     */
    void setParam(String name, String value);
}