package ca.rrx.nw.rr.taglib.command;

//import com.jspinsider.jspkit.javascript.JavaScriptTag;
//import com.jspinsider.jspkit.javascript.*;

import ca.rrx.nw.rr.taglib.JavaScript;
import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.tagext.*;

public class CommandDebugTag extends BodyTagSupport
{
    private String view = "";
    private boolean display = true;
    private String name = "";

    public void setView(String as_object)
    {
        this.view = as_object.trim().toLowerCase();
    }

    public void setDisplay(boolean ab_display)
    {
        this.display = ab_display;
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public int doEndTag() throws JspTagException
    {
        String results;
        String command;
        String keyParam;
        String resultsParam;
        String typeParam;
        String fastParam;
        String lookupsParam;
        String sourceParam;
        String no_recursiveParam;
        String invParam;
        String no_sugarParam;
        String no_referralParam;
        String template_onlyParam;
        String templateParam;
        String submitParam1;
        
        String submitParam2;
        
        String submitParam3;
                        

        results             = null;
        command             = null; 
        keyParam            = null;
        resultsParam        = null;
        typeParam           = null;
        fastParam           = null;
        lookupsParam        = null;
        sourceParam         = null;
        no_recursiveParam   = null; 
        invParam            = null;
        no_sugarParam       = null;
        no_referralParam    = null;
        template_onlyParam  = null;
        templateParam       = null;
        submitParam1        = null;
        
        submitParam2        = null;
        
        submitParam3        = null;
                        


        if (display == false)
        {
            return EVAL_PAGE;
        }

        String ls_alert = "";
        String ls_message = "";
        String ls_data = "";
        String ls_current = "";
        int li_scope = 0;

        if(view.equals("session"))
        {
            li_scope = PageContext.SESSION_SCOPE;
        }

        if(view.equals("request"))
        {
            li_scope = PageContext.REQUEST_SCOPE;
        }

        if(view.equals("application"))
        {
            li_scope = PageContext.APPLICATION_SCOPE;
        }

        if(view.equals("page"))
        {
            li_scope = PageContext.PAGE_SCOPE;
        }

        if(li_scope > 0)
        {
            Enumeration enum_app = pageContext.getAttributeNamesInScope(li_scope);

            ls_data += " Data stored within " + view;

            while(enum_app.hasMoreElements())
            {
                ls_current = enum_app.nextElement().toString();

                if(ls_current != null)
                {
                    ls_data += "\\n Attribute: " + ls_current + " = ";

                    Object res = pageContext.getAttribute(ls_current, li_scope);

                    if(res != null)
                    {
                        ls_data += res.toString().trim();
                    }
                }
            }
        }


        if(li_scope == PageContext.REQUEST_SCOPE)
        {
            ServletRequest lparms = pageContext.getRequest();
            Enumeration req_data = lparms.getParameterNames();
            String[] paramValues;
            int elemCount = 0;

            // retrieve paramaters from the requesting page
            keyParam            = lparms.getParameter("key");              //input box at top
            resultsParam        = lparms.getParameter("results");          //1 or a (1 or all)
            typeParam           = lparms.getParameter("type");             //if not null, add -T
            fastParam           = lparms.getParameter("fast");             //if checked add -F
            lookupsParam        = lparms.getParameter("lookups");          //append -L -M or -m depending which is selected

            sourceParam         = lparms.getParameter("source");           //if not null, add -s and database ID
            paramValues         = lparms.getParameterValues("source");

            no_recursiveParam   = lparms.getParameter("no_recursive");     //1 or 0 (if 0, append -r)
            invParam            = lparms.getParameter("inv");              //inverse lookup
            no_sugarParam       = lparms.getParameter("no_sugar");         //no syntactic sugar
            no_referralParam    = lparms.getParameter("no_referral");      //CA*net3 objects only
            template_onlyParam  = lparms.getParameter("template_only");    //true if user requests a template
            templateParam       = lparms.getParameter("template");         //template to be retrieved
            submitParam1       = lparms.getParameter("cmd1");             
            submitParam2       = lparms.getParameter("cmd2");                
            submitParam3       = lparms.getParameter("cmd3");  
            
            ls_data += "\\n Parameters within Request ";
            ls_data += "\\n keyParam: " + keyParam;
            ls_data += "\\n resultsParam: " + resultsParam;
            ls_data += "\\n typeParam: " + typeParam;
            ls_data += "\\n fastParam: " + fastParam;
            ls_data += "\\n lookupsParam: " + lookupsParam;

            ls_data += "\\n sourceParam: ";

            if(paramValues != null)
            {
                for(int i = 0 ; i < paramValues.length ; i++)
                {
                    ls_data += "\\n \\t" + paramValues[i];
                }
            }

            ls_data += "\\n no_recursiveParam: " + no_recursiveParam;
            ls_data += "\\n invParam: " + invParam;
            ls_data += "\\n no_sugarParam: " + no_sugarParam;
            ls_data += "\\n no_referralParam: " + no_referralParam;
            ls_data += "\\n template_onlyParam: " + template_onlyParam;
            ls_data += "\\n template: " + template_onlyParam;
            ls_data += "\\n submit1: " + submitParam1;
            ls_data += "\\n submit2: " + submitParam2;
            ls_data += "\\n submit3: " + submitParam3;            
            ls_data += "\\n textarea: " + lparms.getParameter("htmltextarea1");                        

//            GET THIS TO PRINT ALL PARAMETERS!!!!!!!!!!!!!!!! EVEN ONES WHERE NOTHING IS SELECTED
//
//            while(req_data.hasMoreElements())
//            {
//                ls_current = req_data.nextElement().toString();
//                System.out.println("****" + ls_current);
//
//                if(ls_current != null)
//                {
//                    ls_data += "\\n " + (elemCount++) + ") " + "element: " + ls_current + " = ";
//                    Object results = lparms.getParameter(ls_current);
//                    if(results != null)
//                    {
//                        ls_data += results.toString().trim();
//                    }
//                }
//            }
        }

        try
        {
            BodyContent lbc_bodycurrent = getBodyContent();
            JavaScript JS = new JavaScript();

            if(lbc_bodycurrent != null)
            {
                ls_message = lbc_bodycurrent.getString().trim();
            }

            ls_alert = JS.alert(ls_message + "\\n" + ls_data);
            pageContext.getOut().write(ls_alert);
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error" + e.toString());
        }

        return EVAL_PAGE;
    }
}