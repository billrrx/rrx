package ca.rrx.nw.rr.taglib.html;

import ca.rrx.nw.rr.Constants;
/**
 * Custom-tag for creating HTML FORM Select tags with options loaded from
 * a data-structure.
 *
 */
public class HtmlFormSelect extends java.lang.Object
    implements java.io.Serializable
{
    private HtmlFormSelectOption[] options;     //store value and test displayed
    private int selected;
    private int size;
    private boolean multipleSelect;
    private String start_select;
    private String end_select;
    private String name;


    /**

     * Constructor. Initializes the available options and which

     * option is selected.

     *

     * @param aobj_data the name of the select componet

     *

     */
    
    public HtmlFormSelect(Object aobj_data)
    {
        String multi;

        name = new String("sources");
        selected = 0;
        size = 6;
        multipleSelect = true;

        options = new HtmlFormSelectOption[16];

        options[0] = new HtmlFormSelectOption("all sources", ""); //text, value
        options[1] = new HtmlFormSelectOption("ARDNOC", "ARDNOC");
        options[2] = new HtmlFormSelectOption("BC-NET", "BC-NET");
        options[3] = new HtmlFormSelectOption("CRC-ON", "CRC-ON");
        options[4] = new HtmlFormSelectOption("DAL-NS", "DAL-NS");
        options[5] = new HtmlFormSelectOption("MRNET-MB", "MRNET-MB");
        options[6] = new HtmlFormSelectOption("NETERA_AB", "NETERA_AB");
        options[7] = new HtmlFormSelectOption("NFLD-NF", "NFLD-NF");
        options[8] = new HtmlFormSelectOption("ONET-OTT-ON", "ONET-OTT-ON");
        options[9] = new HtmlFormSelectOption("ONET-TOR-ON", "ONET-TOR-ON");
        options[10] = new HtmlFormSelectOption("RISQ-QC", "RISQ-QC");
        options[11] = new HtmlFormSelectOption("SRNET-SK", "SRNET-SK");
        options[12] = new HtmlFormSelectOption("TELEGLOBE-NS", "TELEGLOBE-NS");
        options[13] = new HtmlFormSelectOption("UNB-NB", "UNB-NB");
        options[14] = new HtmlFormSelectOption("UPEI-PEI", "UPEI-PEI");
        options[15] = new HtmlFormSelectOption("WEDNET-ON", "WEDNET-ON");

        if(multipleSelect)
        {
            multi = new String("multiple");
        }
        else
        {
            multi = new String("");
        }

        start_select = new String("<select name =\"" + aobj_data.toString() + "\"" + " size=\"" + size + "\" " + multi + ">\n");
        end_select = new String("</select>");
    }



   /**
    * Generates the actual text for the Html Select component.
    *
    * @return contains HTML tags for rendering select component
    *
    */   
    public String formSelect()
    {
        StringBuffer sb;
        sb = new StringBuffer();

        sb.append(start_select);

        for(int i = 0 ; i < options.length ; i++)
        {
            String soption;
            String select;

            if(i == selected)
            {
                select = new String(" selected ");
            }
            else
            {
                select = new String("");
            }

            soption = new String("    <option " + "value=\"" + options[i].getValue() + "\"" 
                + select + " > " + options[i].getText() + " " + "</option>\n");
            sb.append(soption);
        }

        sb.append(end_select);

        return(sb.toString());
    }
}