package ca.rrx.nw.rr.taglib.html;

import java.io.IOException;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.*;
import ca.rrx.nw.rr.Constants;

public class HtmlFormSelectTag extends BodyTagSupport
{
    public int doEndTag() throws JspTagException
    {
        String ls_alert = "";

        try
        {
            BodyContent lbc_bodycurrent = getBodyContent();

            if(lbc_bodycurrent != null)
            {
                String ls_message = lbc_bodycurrent.getString();
                HtmlFormSelect JS = new HtmlFormSelect(ls_message.trim());

                ls_alert = JS.formSelect();
            }

            pageContext.getOut().write(ls_alert);
        }
        catch (IOException e)
        {
            throw new JspTagException ("Error" + e.toString());
        }

        return EVAL_PAGE;
    }
}