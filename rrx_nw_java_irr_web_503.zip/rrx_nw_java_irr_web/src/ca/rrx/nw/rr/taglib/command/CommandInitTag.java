package ca.rrx.nw.rr.taglib.command;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.jsp.HttpJspPage;
import javax.servlet.jsp.JspPage;

import javax.servlet.jsp.JspEngineInfo;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;

//import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.TagSupport;

import javax.servlet.ServletRequest;


//import javax.servlet.jsp.tagext.BodyTagSupport;

public class CommandInitTag extends TagSupport
{
    private String name;
    private String command;
    private boolean debug;

    public CommandInitTag()
    {
        debug = false;
        name        = new String("");
        command     = new String("");
    }

    public void setName(String ab_name)
    {
        this.name = ab_name;
    }

    public void setCommand(String ab_command)
    {
        this.command = ab_command;
    }


   public void setDebug(boolean ab_debug)
    {
        this.debug = ab_debug;
    }


    public String getCommand()
    {
        return (command);
    }
    
    public boolean getDebug()
    {
        return (debug);
    }
    

    public String getName()
    {
        return (name);
    }

    public void addParam()
    {
    }

    public int doStartTag() throws JspTagException
    {
        pageContext.setAttribute(this.getName(), this.getCommand());

        return EVAL_BODY_INCLUDE;
    }

    public int doEndTag() throws JspException
    {
/*    
        String submitValue;
        ServletRequest lparms;
        Enumeration req_data;
        Object res;
        
        lparms = pageContext.getRequest();
        req_data = lparms.getParameterNames();

        res = pageContext.getAttribute(".submit", PageContext.REQUEST_SCOPE);
        submitValue = res.toString().trim();
        
*/
                
        pageContext.setAttribute(this.getName(), this.getCommand());

	try
	{
	     if(debug)
	     {
	         pageContext.getOut().print(this.getCommand());
                 pageContext.getOut().print("[");
                
                 pageContext.getOut().print(pageContext.getAttribute("submit"));
                 pageContext.getOut().print("]");
                	         
	     }
        }
        catch(IOException e)
        {
            System.out.println("Error in CommandInitTag");
        }


        return EVAL_PAGE;
    }
}