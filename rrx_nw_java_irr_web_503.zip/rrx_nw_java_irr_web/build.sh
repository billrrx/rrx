#!/bin/sh
# build -- Linux Build Script for the "RRX IRR Interface" Application
# $Id: build.sh,v 1.1.1.1 2004/02/07 04:52:45 root Exp $
LOCAL=`pwd`
CP=$ANT_HOME/lib/ant.jar
CP=$CP:$JAVA_HOME/lib/tools.jar
CP=$CP:$LOCAL/lib/commons-beanutils.jar:$LOCAL/lib/commons-logging.jar:$LOCAL/lib/cvsclient.jar:$LOCAL/lib/parser.jar:$LOCAL/lib/servlet.jar
CP=$CP:$LOCAL/lib/axis.jar:$LOCAL/lib/saaj.jar:$LOCAL/lib/axis-ant.jar:$LOCAL/lib/jaxrpc.jar:$LOCAL/lib/wsdl4j.jar:$LOCAL/lib/xmlsec.jar
# Execute ANT to perform the requested build target

java -classpath $CP:$CLASSPATH org.apache.tools.ant.Main -Dtomcat.home=$TOMCAT_HOME "$@"