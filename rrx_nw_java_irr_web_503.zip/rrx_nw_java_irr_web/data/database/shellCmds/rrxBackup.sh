#!/bin/sh
# this needs to be updated for each site before using - billr 2015
# rrxBackup -- Hot Backup Script for the "RRX IRR Interface" Application
# $Id: rrxBackup.sh,v 1.1.1.1 2004/02/07 04:52:45 root Exp $
# remove file replicas of db tables in backupData directory
rm /usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/*.*
# create new table file replicas
# mysqlhotcopy IRRWEB /home/tomcat/webapps/irr/data/database/backupData
mysql -u tomcat < /usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/sqlCmds/IRRWEB_backupDB.sql

