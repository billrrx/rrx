#!/bin/sh

echo "Loading IRRWEB database with Default Profiles "

$MYSQL -h$HOST -u$USER -p$PASSWORD ${DB} <IRRWEB_loadDB.sql

