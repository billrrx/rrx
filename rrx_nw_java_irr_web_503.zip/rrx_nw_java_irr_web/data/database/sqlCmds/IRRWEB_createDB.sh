#!/bin/sh

echo "Creating IRRWEB database"
$MYSQL -h$HOST -u$USER -p$PASSWORD <<EOM

DROP DATABASE IF EXISTS ${DB};
CREATE DATABASE ${DB};
USE ${DB};
EOM

$MYSQL -h$HOST -u$USER -p$PASSWORD ${DB} <IRRWEB_createDB.sql

