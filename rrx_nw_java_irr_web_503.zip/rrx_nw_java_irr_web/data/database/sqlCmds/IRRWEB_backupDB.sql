USE IRRWEB;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/IRRServers.txt" FROM IRRServers;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RouterProfile.txt" FROM RouterProfile;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RouterTransitPort.txt" FROM RouterTransitPort;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RouterControlPort.txt" FROM RouterControlPort;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RouterConnectionProfile.txt" FROM RouterConnectionProfile;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RouterConfiguration.txt" FROM RouterConfiguration;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/OperatorProfile.txt" FROM OperatorProfile;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/OperatorProfileNew.txt" FROM OperatorProfileNew;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/OperatorSessionProfile.txt" FROM OperatorSessionProfile;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/UclpProfile.txt" FROM UclpProfile;
SELECT * INTO OUTFILE "/usr/jakarta/jakarta-tomcat-5.0.27/webapps/rr/data/database/backupData/RpslFilter.txt" FROM RpslFilter;

