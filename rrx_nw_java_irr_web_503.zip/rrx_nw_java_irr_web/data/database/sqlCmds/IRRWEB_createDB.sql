#=====================================================================
#  issue as root: GRANT ALL PRIVILEGES ON *.* TO tomcat@localhost;
#=====================================================================

DROP DATABASE IF EXISTS IRRWEB;

CREATE DATABASE IRRWEB;

USE IRRWEB;

#--------------------------------------------------------------------
# Table structure for table 'OperatorProfile'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS OperatorProfile;

CREATE TABLE OperatorProfile 
(
      OperatorLoginName 	VARCHAR(20) 	not null,
	OperatorId 		INTEGER		not null,
	DefaultSessionId 	INTEGER		null,
	MaintainerCodes 	VARCHAR(255) 	null,
	Password 		VARCHAR(20) 	not null,
	NicHandle 		VARCHAR(15) 	not null,
	FirstName 		VARCHAR(40) 	not null,
	LastName 		VARCHAR(40) 	not null,
	StreetName1 		VARCHAR(60) 	not null,
	StreetName2 		VARCHAR(60) 	null,
	StreetName3 		VARCHAR(60) 	null,
	City 			VARCHAR(40) 	not null,
	StateProvince 		VARCHAR(40) 	null,
	Country 		VARCHAR(40) 	null,
	PostalCode 		VARCHAR(40) 	null,
	Telephone 		VARCHAR(15) 	null,
	Email 			VARCHAR(40) 	not null,
	Lang 			VARCHAR(20) 	not null,
	Role 			VARCHAR(40) 	not null,
	Remarks 		VARCHAR(255) 	null,
  CONSTRAINT PrimaryKey 
	PRIMARY KEY (OperatorLoginName)  
);

#--------------------------------------------------------------------
# Table structure for table 'OperatorSessionProfile'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS OperatorSessionProfile;

CREATE TABLE OperatorSessionProfile 
( 
	SessionProfileId	INTEGER		not null,
	OperatorId 		INTEGER		null,
	RelativeConfigPath 	VARCHAR(50) 	null,
	MaintainerCode 		VARCHAR(40) 	not null,
	NicHandle 		VARCHAR(20) 	null,
	SessionProfileName 	VARCHAR(40) 	not null,
	PrimaryServerProfileId 	INTEGER		not null,
	SecondaryServerProfileId INTEGER	not null,
	Remarks 		VARCHAR(255) 	null,
  CONSTRAINT PrimaryKey 
	PRIMARY KEY (SessionProfileId)
);  

#--------------------------------------------------------------------
# Table structure for table 'OperatorSessionLog'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS OperatorSessionLog;

CREATE TABLE OperatorSessionLog 
( 
	OperatorEventId 	INTEGER 	not null,
	OperatorId 		INTEGER 	null,
	SessionProfileId 	INTEGER 	null,
	HttpSessionCode 	VARCHAR(50) 	null,
	MaintainerCode 		VARCHAR(40) 	null,
	FullName 		VARCHAR(50) 	null,
	Telephone 		VARCHAR(50) 	null,
	Email 			VARCHAR(50) 	null,
	EventCode 		VARCHAR(50) 	null,
	TimeStored 		VARCHAR(50) 	null,
	ExtendedInformation 	VARCHAR(255) 	null,
  CONSTRAINT PrimaryKey 
	PRIMARY KEY (OperatorEventId)   
);  

#--------------------------------------------------------------------
# Table structure for table 'OperatorProfileNew'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS OperatorProfileNew;

CREATE TABLE OperatorProfileNew 
(
      OperatorLoginName 	VARCHAR(20) 	not null,
	OperatorId 		INTEGER		not null,
	DefaultSessionId 	INTEGER		null,
	MaintainerCodes 	VARCHAR(255) 	null,
	Password 		VARCHAR(20) 	not null,
	NicHandle 		VARCHAR(15) 	not null,
	FirstName 		VARCHAR(40) 	not null,
	LastName 		VARCHAR(40) 	not null,
	StreetName1 		VARCHAR(60) 	not null,
	StreetName2 		VARCHAR(60) 	null,
	StreetName3 		VARCHAR(60) 	null,
	City 			VARCHAR(40) 	not null,
	StateProvince 		VARCHAR(40) 	null,
	Country 		VARCHAR(40) 	null,
	PostalCode 		VARCHAR(40) 	null,
	Telephone 		VARCHAR(15) 	null,
	Email 			VARCHAR(40) 	not null,
	Lang 			VARCHAR(20) 	not null,
	Role 			VARCHAR(40) 	not null,
	Remarks 		VARCHAR(255) 	null,
  CONSTRAINT PrimaryKey 
	PRIMARY KEY (OperatorLoginName)  
);

#--------------------------------------------------------------------
# Table structure for table 'IRRServers'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS IRRServers;

CREATE TABLE IRRServers
( 
	ServerProfileId 	INTEGER		not null,
	ServerProfileName 	VARCHAR(50) 	null,
	ServerDnsName 		VARCHAR(40) 	not null,
	ServerIpv4 		VARCHAR(50) 	null,
	ServerIpv6 		VARCHAR(50) 	null,
	ServerType 		VARCHAR(40) 	not null,
	QueryPort 		VARCHAR(10) 	not null,
	UpdatePort 		VARCHAR(10) 	null,
	FloodPort 		VARCHAR(10) 	null,
	MirrorPort 		VARCHAR(10) 	null,
	AuthoritativeSourceCodes VARCHAR(255) 	null,
	MirroredSourceCodes 	VARCHAR(255) 	null,
	FtpServer 		VARCHAR(255) 	null,
	FtpPath 		VARCHAR(50) 	null,
	FtpDataFile 		VARCHAR(50) 	null,
	FtpSerialFile 		VARCHAR(50) 	null,
	RpslCode 		VARCHAR(50) 	null,
	Remarks 		VARCHAR(255) 	null,
 CONSTRAINT PrimaryKey 
	PRIMARY KEY (ServerProfileId)
); 

#--------------------------------------------------------------------
# Table structure for table 'RpslFilter'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RpslFilter;

CREATE TABLE RpslFilter 
( 
	RpslFilterId 		INTEGER 	not null,
	OperatorId 		INTEGER 	null,
	SessionProfileId 	INTEGER 	null,
	ServerProfileId 	INTEGER 	null,
	RpslObjectType 		VARCHAR(40) 	null,
	RpslAttributeType 	VARCHAR(40) 	not null,
	FilterExpression 	VARCHAR(50) 	null,
 CONSTRAINT PrimaryKey 
	PRIMARY KEY (RpslFilterId)
);

#--------------------------------------------------------------------
# Table structure for table 'UclpProfile'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS UclpProfile;

CREATE TABLE UclpProfile 
( 
	UclpProfileId 		INTEGER 	not null,
	RouterProfileId 	INTEGER 	not null,
	PortId 			INTEGER 	null,
	PortType 		VARCHAR(50) 	null,
	UclpProfileName 	VARCHAR(50) 	null,
	UclpConfig 		VARCHAR(50) 	null,
	Descr 			VARCHAR(50) 	null,
	MemberOf 		VARCHAR(50) 	not null,
	Remarks 		VARCHAR(255) 	not null,
	AdminC 			VARCHAR(255) 	null,
	TechC 			VARCHAR(255) 	null,
	Notify 			VARCHAR(50) 	null,
	MntBy 			VARCHAR(50) 	null,
	Changed 		VARCHAR(50) 	null,
	Source 			VARCHAR(50) 	null, 

 CONSTRAINT PrimaryKey 
	PRIMARY KEY (UclpProfileId)
);


#--------------------------------------------------------------------
# Table structure for table 'RouterProfile'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RouterProfile;

CREATE TABLE RouterProfile
( 
	RouterProfileId 	INTEGER 	not null,
	SessionProfileId 	INTEGER 	not null,
	MaintainerCode 		VARCHAR(40) 	not null,
	RouterProfileName 	VARCHAR(40) 	not null,
	DnsName 		VARCHAR(40) 	not null,
	LocationCode 		VARCHAR(40) 	not null,
	LocalAs 		VARCHAR(20) 	not null,
	Manufacturer 		VARCHAR(40) 	not null,
	Model 			VARCHAR(40) 	null,
	Series 			VARCHAR(40) 	not null,
	MainSerialNumber 	VARCHAR(60) 	null,
	ManufacturedDate 	VARCHAR(50) 	null,
	InstallationDate 	VARCHAR(50) 	null,
	OsVersion 		VARCHAR(40) 	null,
	OsUpgradeDate 		VARCHAR(50) 	null,
	OsFeatures 		VARCHAR(255) 	null,
	Remarks 		VARCHAR(255) 	null,
  CONSTRAINT PrimaryKey
 	PRIMARY KEY (RouterProfileId) 
);

#--------------------------------------------------------------------
# Table structure for table 'RouterControlPort'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RouterControlPort;

CREATE TABLE RouterControlPort 
( 
	ControlPortId 		INTEGER 	not null,
	RouterProfileId 	INTEGER 	not null,
	ControlPortName 	VARCHAR(50) 	null,
	ControlPortNumber 	VARCHAR(50) 	null,
	TimeStored 		VARCHAR(50) 	not null,
	Disabled 		VARCHAR(255) 	not null,
	Circuit 		VARCHAR(255) 	null,
	DesignatedIpv4 		VARCHAR(255) 	null,
	DesignatedIpv4MaskLength VARCHAR(50) 	null,
	TransportProtocol 	VARCHAR(50) 	null,
	UclpProfileId 		INTEGER 	null,
	Ipv6ProfileId 		INTEGER 	null,
	ConnectionProfileId 	INTEGER 	not null,
	Remarks 		VARCHAR(255) 	null,
 CONSTRAINT PrimaryKey 
	PRIMARY KEY (ControlPortId) 
);  
   
#--------------------------------------------------------------------
# Table structure for table 'RouterTransitPort'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RouterTransitPort;

CREATE TABLE RouterTransitPort
( 
	TransitPortId 			INTEGER 	not null,
	RouterProfileId 		INTEGER     	not null,
	TransitPortName 		VARCHAR(50) 	null,
	TransitPortNumber 		VARCHAR(50) 	null,
	TimeStored 			VARCHAR(50) 	not null,
	Disabled 			VARCHAR(255) 	not null,
	Circuit 			VARCHAR(255) 	null,
	DesignatedIpv4 			VARCHAR(255) 	null,
	DesignatedIpv4MaskLength 	VARCHAR(50) 	null,
	TransportProtocol 		VARCHAR(50) 	null,
	PeerRoutingProtocol 		VARCHAR(50) 	null,
	PeerDesignatedIpv4 		VARCHAR(50) 	null,
	UclpProfileId 			INTEGER 	null,
	PeerSupportsUclp 		VARCHAR(50) 	null,
	Ipv6ProfileId 			INTEGER 	null,
	PeerSupportsIpv6 		VARCHAR(50) 	null,
	Remarks 			VARCHAR(255) 	null, 
  CONSTRAINT PrimaryKey 
      PRIMARY KEY (TransitPortId)
);  

#--------------------------------------------------------------------
# Table structure for table 'RouterConnectionProfile'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RouterConnectionProfile;

CREATE TABLE RouterConnectionProfile
( 
	ControlConnectionId 		INTEGER 	not null,
	RouterProfileId 		INTEGER 	not null,
	ControlConnectionName 		VARCHAR(50) 	null,
	ControlConnectionNumber 	VARCHAR(50) 	null,
	TimeStored 			VARCHAR(50) 	not null,
	ConnectionType 			VARCHAR(255) 	not null,
	ConnectionParameter1 		VARCHAR(255) 	null,
	ConnectionParameter2 		VARCHAR(255) 	null,
	TypeConfigPath 			VARCHAR(255) 	null,
	ExecutablePath 			VARCHAR(255) 	null,
	LoginName 			VARCHAR(50) 	null,
	Password 			VARCHAR(50) 	null,
	ConnectionServer 		VARCHAR(50) 	null,
	ConnectionServerPath 		VARCHAR(50) 	null,
	TargetServerPath 		VARCHAR(50) 	null,
	Remarks 			VARCHAR(255) 	null,
 CONSTRAINT PrimaryKey 
	PRIMARY KEY (ControlConnectionId) 
);  

#--------------------------------------------------------------------
# Table structure for table 'RouterConfiguration'
#--------------------------------------------------------------------

DROP TABLE IF EXISTS RouterConfiguration;

CREATE TABLE RouterConfiguration 
( 
	RouterConfigurationId 		INTEGER 	not null,
	RouterProfileId 		INTEGER 	not null,
	TimeStored 			VARCHAR(50) 	not null,
	Revision 			VARCHAR(50) 	null,
	CommandLine 			VARCHAR(255) 	null,
	PointerType 			VARCHAR(255) 	not null,
	Remarks 			VARCHAR(255) 	null,
        ConfigurationTemplate           TEXT            null,
        ConfigurationResult             TEXT            null,
        ConfigurationRpslSnap           TEXT            null,
 CONSTRAINT PrimaryKey 
 	PRIMARY KEY (RouterConfigurationId) 
);  


#====================================================================

#--------------------------------------------------------------------
#  Constraints, and indexes for table 'OperatorProfile'
#--------------------------------------------------------------------

#CREATE INDEX DefaultSessionID on OperatorProfile (
#	DefaultSessionId ASCENDING);  

#CREATE INDEX OperatorProfileOperatorID on OperatorProfile (
#	OperatorId ASCENDING);  

#CREATE INDEX PostalCode on OperatorProfile (
#	PostalCode ASCENDING); 

#--------------------------------------------------------------------
#  Constraints, and indexes for table 'OperatorSessionProfile'
#--------------------------------------------------------------------

#CREATE INDEX OperatorID ON OperatorSessionProfile (
#	NicHandle ASCENDING);  

#CREATE INDEX OperatorID1 ON OperatorSessionProfile (
#	OperatorId ASCENDING);  

#CREATE INDEX OperatorSessionProfileMaintainerID ON OperatorSessionProfile (
#	MaintainerCode ASCENDING); 
 
#--------------------------------------------------------------------
#  Constraints, and indexes for table 'OperatorSessionLog'
#--------------------------------------------------------------------

#CREATE INDEX ActiveSessionsSessionProfileID ON OperatorSessionLog (
#	SessionProfileId ASCENDING);  

#CREATE INDEX EventCode ON OperatorSessionLog (
#	EventCode ASCENDING);  

#CREATE INDEX HttpSessionCode ON OperatorSessionLog (
#	HttpSessionCode ASCENDING);  

#--------------------------------------------------------------------
#  Constraints, and indexes for table 'OperatorProfileNew'
#--------------------------------------------------------------------

#CREATE INDEX DefaultSessionID ON OperatorProfileNew (
#	DefaultSessionId ASCENDING);  

#CREATE INDEX OperatorProfileOperatorID ON OperatorProfileNew (
#	OperatorId ASCENDING);  

#CREATE INDEX PostalCode ON OperatorProfileNew (
#	PostalCode ASCENDING);  

#--------------------------------------------------------------------
#  Constraints, and indexes for table 'IRRServers'
#--------------------------------------------------------------------

#CREATE INDEX RpslCode ON IRRServers (
#	RpslCode ASCENDING);  


